package com.olcudefteri.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline-first local LLM layer.
 *
 * The model is downloaded once into app-private storage. After the download is
 * verified, inference does not use the network. The model/runtime versions and
 * SHA-256 are intentionally pinned so a future upstream update cannot silently
 * replace the model used by the app.
 */
class LocalAIEngine(private val context: Context) {
    interface Callback { fun success(text: String); fun error(message: String) }
    interface StatusCallback { fun progress(percent: Int, downloaded: Long, total: Long); fun done(ok: Boolean, message: String) }

    companion object {
        private const val MODEL_FILE = "gemma-4-E2B-it.litertlm"
        private const val MODEL_SIZE = 2588147712L
        private const val MODEL_SHA256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c"
        // Pinned model revision used by Google AI Edge Gallery's Android Gemma 4 E2B entry.
        private const val MODEL_URL = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/6e5c4f1e395deb959c494953478fa5cec4b8008f/gemma-4-E2B-it.litertlm?download=true"
        private const val SYSTEM_INSTRUCTION = """
Sen Ölçü Defteri'nin yerel yapay zekâ motorusun. Türkçe konuş ve kısa, net cevap ver.
Sen internete erişemezsin ve dış bilgi uyduramazsın. Sana verilen proje verisini esas al.
Kullanıcının isteğini anlamlandır ve SADECE aşağıdaki JSON biçiminde cevap ver:
{"reply":"kullanıcıya verilecek kısa cevap","actions":[...]}

İzin verilen action türleri:
- add_measure: {type,category,workItem,area,floor,facade,a,b,c,unit,note,price,projectName}
- add_note: {type,text,qty,unit,projectName}
- add_task: {type,text,projectName}
- create_project: {type,name}
- open_project: {type,projectName}
- open_screen: {type,screen}
- delete_measure: {type,record_id,projectName}
- update_measure: {type,record_id,value,projectName}
- query_measurements: {type,projectName,category,workItem,area,floor,facade}
- calculate: {type,numbers,operator}

Ölçü birimleri yalnızca m2, m3, mtul, metre veya adet olabilir.
Dış cephe ölçüsünde facade alanı gerçek cephe adı olmalıdır.
12 x 10 = 120 m2 gibi hesaplarda hesap sonucu yerine add_measure ile a=12,b=10,unit=m2 gönder.
Silme/güncelleme işlemlerinde yalnızca verilen gerçek record_id değerlerini kullan.
Kritik bilgi eksikse işlem uydurma; reply içinde eksik bilgiyi sor ve actions boş bırak.
JSON dışında markdown, açıklama veya kod bloğu yazma.
"""
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)
    private var engine: Engine? = null
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null

    private fun modelFile(): File = File(File(context.filesDir, "local-ai/models"), MODEL_FILE)
    private fun partFile(): File = File(modelFile().absolutePath + ".part")

    fun statusJson(): String {
        val f = modelFile()
        val ready = f.isFile && f.length() == MODEL_SIZE
        return "{\"ready\":$ready,\"size\":${f.length()},\"expected\":$MODEL_SIZE,\"model\":\"Gemma 4 E2B\"}"
    }

    fun shutdown() {
        executor.execute {
            try { conversation?.close() } catch (_: Exception) {}
            try { engine?.close() } catch (_: Exception) {}
            conversation = null
            engine = null
        }
    }

    fun downloadModel(cb: StatusCallback) {
        executor.execute {
            try {
                val target = modelFile()
                target.parentFile?.mkdirs()
                if (target.isFile && target.length() == MODEL_SIZE) {
                    main.post { cb.progress(100, MODEL_SIZE, MODEL_SIZE); cb.done(true, "Yerel AI modeli hazır.") }
                    return@execute
                }
                val part = partFile()
                var downloaded = if (part.isFile) part.length() else 0L
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 30000
                        readTimeout = 120000
                        instanceFollowRedirects = true
                        if (downloaded > 0) setRequestProperty("Range", "bytes=$downloaded-")
                        connect()
                    }
                    val code = conn.responseCode
                    if (downloaded > 0 && code == HttpURLConnection.HTTP_OK) {
                        // Server ignored Range; restart safely rather than corrupting the file.
                        downloaded = 0L
                        part.delete()
                    } else if (code != HttpURLConnection.HTTP_PARTIAL && code !in 200..299) {
                        throw Exception("Model sunucusu HTTP $code döndürdü.")
                    }
                    val contentLength = conn.contentLengthLong
                    val total = if (code == HttpURLConnection.HTTP_PARTIAL && contentLength > 0) downloaded + contentLength else if (contentLength > 0) contentLength else MODEL_SIZE
                    conn.inputStream.use { input ->
                        RandomAccessFile(part, "rw").use { out ->
                            out.seek(downloaded)
                            val buf = ByteArray(1024 * 1024)
                            var lastReport = System.currentTimeMillis()
                            var n: Int
                            while (input.read(buf).also { n = it } != -1) {
                                if (n > 0) {
                                    out.write(buf, 0, n)
                                    downloaded += n
                                    val now = System.currentTimeMillis()
                                    if (now - lastReport >= 500) {
                                        val pct = ((downloaded * 100L) / MODEL_SIZE).coerceIn(0, 99).toInt()
                                        main.post { cb.progress(pct, downloaded, MODEL_SIZE) }
                                        lastReport = now
                                    }
                                }
                            }
                        }
                    }
                } finally { conn?.disconnect() }

                if (part.length() != MODEL_SIZE) throw Exception("Model eksik indi: ${part.length()} / $MODEL_SIZE byte.")
                if (MODEL_SHA256.isNotEmpty()) {
                    val digest = sha256(part)
                    if (!digest.equals(MODEL_SHA256, ignoreCase = true)) throw Exception("Model doğrulaması başarısız (SHA-256).")
                }
                if (!part.renameTo(target)) {
                    part.copyTo(target, overwrite = true)
                    part.delete()
                }
                main.post { cb.progress(100, MODEL_SIZE, MODEL_SIZE); cb.done(true, "Yerel AI modeli hazır. İnternetsiz kullanılabilir.") }
            } catch (e: Exception) {
                main.post { cb.done(false, e.message ?: "Model indirilemedi.") }
            }
        }
    }

    fun ask(prompt: String, cb: Callback) {
        if (!busy.compareAndSet(false, true)) {
            main.post { cb.error("Yerel AI şu anda başka bir isteği işliyor.") }
            return
        }
        executor.execute {
            try {
                val model = modelFile()
                if (!model.isFile || model.length() != MODEL_SIZE) throw Exception("Yerel AI modeli hazır değil. Önce modeli hazırlayın.")
                if (engine == null) {
                    val config = EngineConfig(
                        modelPath = model.absolutePath,
                        backend = Backend.CPU(threadCount = 4),
                        cacheDir = File(context.cacheDir, "litertlm-gemma4-e2b").absolutePath,
                        maxNumTokens = 1024,
                    )
                    engine = Engine(config)
                    engine!!.initialize()
                    val conversationConfig = ConversationConfig(
                        systemInstruction = Contents.of(SYSTEM_INSTRUCTION),
                        samplerConfig = SamplerConfig(topK = 64, topP = 0.95, temperature = 0.3),
                        maxOutputToken = 512,
                        thinkingConfig = com.google.ai.edge.litertlm.ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0),
                    )
                    conversation = engine!!.createConversation(conversationConfig)
                }
                val response = StringBuilder()
                val latch = java.util.concurrent.CountDownLatch(1)
                val callback = object : MessageCallback {
                    override fun onMessage(message: com.google.ai.edge.litertlm.Message) {
                        response.append(message.toString())
                    }
                    override fun onDone() { latch.countDown() }
                    override fun onError(throwable: Throwable) {
                        response.append("__LITERT_ERROR__:").append(throwable.message ?: "Yerel AI yanıt hatası")
                        latch.countDown()
                    }
                }
                conversation!!.sendMessageAsync(prompt, callback)
                if (!latch.await(90, java.util.concurrent.TimeUnit.SECONDS)) {
                    throw Exception("Yerel AI yanıt zaman aşımına uğradı.")
                }
                val answer = response.toString().trim()
                if (answer.startsWith("__LITERT_ERROR__:")) throw Exception(answer.removePrefix("__LITERT_ERROR__:").trim())
                if (answer.isEmpty()) throw Exception("Yerel AI boş yanıt verdi.")
                main.post { cb.success(answer) }
            } catch (e: Exception) {
                main.post { cb.error(e.message ?: "Yerel AI çalıştırılamadı.") }
            } finally { busy.set(false) }
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(1024 * 1024)
            var n: Int
            while (input.read(buf).also { n = it } != -1) if (n > 0) md.update(buf, 0, n)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

}
