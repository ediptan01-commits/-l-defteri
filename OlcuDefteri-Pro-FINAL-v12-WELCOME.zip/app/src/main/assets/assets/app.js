const $=id=>document.getElementById(id);
const areas={"Dış Cephe":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],"Alçıpan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Işık Bandı","Soffit","Kolon","Kiriş","Diğer"],"Duvar":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],"İç Sıva":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],"Alçı Sıva":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Duvar","Tavan","Kolon","Kiriş","Diğer"],"Saten Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Tavan","Kapılar","Diğer"],"Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Tavan","Kapılar","Diğer"],"Dekoratif Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","TV Ünitesi","Niş","Sütun / Kolon","Tavan","Duvar","Dış Cephe","Diğer"],"Laminat Parke":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Koridor","Antre","Ofis","Mağaza","Merdiven","Diğer"],"Tavan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Diğer"],"Mantolama":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],"Seramik":["Banyo Zemin","Banyo Duvar","WC Zemin","WC Duvar","Mutfak","Balkon","Teras","Diğer"],"Şap":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","Koridor","Balkon","Teras","Diğer"],"Işık Bandı":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Koridor","Merdiven","Diğer"],"Fuga / Söve":["Ön Cephe","Arka Cephe","Sağ Cephe","Sol Cephe","Kör Cephe","Pencere Çevresi","Kapı Çevresi","Diğer"],"Süpürgelik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Koridor","Antre","Diğer"],"Kapı / Pencere":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Balkon","Diğer"],"Elektrik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Dış Cephe","Pano","Diğer"],"Sıhhi Tesisat":["Banyo","WC","Mutfak","Çamaşır Alanı","Bahçe","Diğer"],"Çatı":["Ana Çatı","Teras Çatı","Saçak","Oluk","Dere","Diğer"]};
function loadData(){try{let raw=JSON.parse(localStorage.getItem('od5'));if(raw?.projects?.length){raw.projects.forEach(p=>{p.records??=[];p.notes??=[];p.tasks??=[];p.photos??=[]});raw.activeId??=raw.projects[0].id;return raw}if(raw?.records){let p={id:'p_'+Date.now(),name:raw.project||'A İnşaat',records:raw.records,notes:[],tasks:[],photos:[]};return{activeId:p.id,projects:[p]}}}catch(e){}let p={id:'p_'+Date.now(),name:'A İnşaat',records:[],notes:[],tasks:[],photos:[]};return{activeId:p.id,projects:[p]}}
let data=loadData(),cat='',area='';
const floors=Array.from({length:30},(_,i)=>`${i+1}. Kat`);
const activeProject=()=>data.projects.find(p=>p.id===data.activeId)||data.projects[0];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){localStorage.setItem('od5',JSON.stringify(data));renderHome();renderProjects()}
function show(id){['home','projects','categories','areas','entry','ai','book','notes','tasks','calculator','pro','auth','welcome'].forEach(x=>{let el=$(x);if(el)el.classList.toggle('hide',x!==id)});document.body.classList.toggle('welcome-mode',id==='welcome');if(id==='book')renderBook();if(id==='notes')renderNotes();if(id==='tasks')renderTasks();if(id==='projects')renderProjects();if(id==='home')renderHome()}
function tile(t,s,fn){let b=document.createElement('button');b.className='tile';b.innerHTML=`${esc(t)}<small>${s}</small>`;b.onclick=fn;return b}
function renderCats(){let g=$('cats');g.innerHTML='';Object.keys(areas).forEach(k=>g.append(tile(k,'Seç',()=>{cat=k;$('catName').textContent=k;let ag=$('areasGrid');ag.innerHTML='';areas[k].forEach(a=>ag.append(tile(a,'Ölçü gir',()=>{area=a;$('entryCat').textContent=cat;$('entryArea').textContent=area;clearEntry();show('entry')})));show('areas')})))}
function clearEntry(){$('a').value='';$('b').value='';$('c').value='';if($('floor'))$('floor').value='';$('note').value='';$('price').value='';updateCalc()}
function parseNum(v){return parseFloat(String(v??'').replace(',','.'))||0}
function updateCalc(){
  let a=parseNum($('a').value),b=parseNum($('b').value),c=parseNum($('c').value),u=$('unit').value;
  $('cWrap').classList.toggle('hide',u!=='m3');
  $('b').classList.toggle('hide',u==='mtul'||u==='metre'||u==='adet');
  const bLabel=document.querySelector('#entry .measure b'); if(bLabel) bLabel.classList.toggle('hide',u==='mtul'||u==='metre'||u==='adet');
  let v=u==='m2'?a*b:u==='m3'?a*b*c:(u==='mtul'||u==='metre'||u==='adet')?a:a;
  let label=fmtUnit(u);
  $('calc').textContent=u==='m3'?`${a} × ${b} × ${c} = ${Number(v.toFixed(2))} ${label}`:u==='m2'?`${a} × ${b} = ${Number(v.toFixed(2))} ${label}`:`${a} = ${Number(v.toFixed(2))} ${label}`;
}
['a','b','c'].forEach(id=>$(id)?.addEventListener('input',updateCalc));
$('unit').addEventListener('change',updateCalc);
function clearEntry(){$('a').value='';$('b').value='';$('c').value='';$('floor').value='';$('note').value='';$('price').value='';$('unit').value='m2';updateCalc()}
$('save').onclick=()=>{
  let p=activeProject(),a=parseNum($('a').value),b=parseNum($('b').value),c=parseNum($('c').value),u=$('unit').value;
  if(a<=0)return alert('Ölçü gir.');
  if((u==='m2'&&b<=0)||(u==='m3'&&(b<=0||c<=0)))return alert(u==='m3'?'Metreküp için 3 ölçüyü de gir.':'İkinci ölçüyü gir.');
  let v=u==='m2'?a*b:u==='m3'?a*b*c:(u==='mtul'||u==='metre'||u==='adet')?a:a;
  let rec={id:'r_'+Date.now()+'_'+Math.random().toString(36).slice(2),cat,area,floor:$('floor').value||'',a,b,c,unit:u,value:+v.toFixed(2),note:$('note').value.trim(),price:parseNum($('price').value),createdAt:new Date().toISOString()};
  if(window.editingRecordId){let ix=p.records.findIndex(x=>x.id===window.editingRecordId);if(ix>=0)rec.id=p.records[ix].id,p.records[ix]=rec;window.editingRecordId=null}else p.records.push(rec);
  save();show('book')
};
function renderHome(){let p=activeProject();$('projectName').textContent=p.name;$('recent').innerHTML=p.records.length?p.records.slice(-6).reverse().map(r=>`<div class="line"><b>${esc(r.cat)} / ${esc(r.area)}${r.floor?` • ${esc(r.floor)}`:''}</b><span>${r.a} × ${r.b}${r.unit==='m3'?` × ${r.c||0}`:''} = ${r.value} ${r.unit==='m2'?'m²':r.unit==='m3'?'m³':r.unit==='mtul'?'mt':r.unit==='metre'?'m':esc(r.unit)}</span></div>`).join(''):'Henüz kayıt yok.';let m=p.records.filter(r=>r.unit==='m2').reduce((s,r)=>s+r.value,0),mt=p.records.filter(r=>r.unit==='mtul').reduce((s,r)=>s+r.value,0),m3=p.records.filter(r=>r.unit==='m3').reduce((s,r)=>s+r.value,0),cost=p.records.reduce((s,r)=>s+(r.price||0)*r.value,0),open=(p.tasks||[]).filter(t=>!t.done).length;$('homeSummary').innerHTML=`<div class="summaryGrid"><div><b>${m.toFixed(2)}</b><small>m² toplam</small></div><div><b>${mt.toFixed(2)}</b><small>mt toplam</small></div><div><b>${m3.toFixed(2)}</b><small>m³ toplam</small></div><div><b>${open}</b><small>Açık iş</small></div><div><b>${cost.toFixed(2)} ₺</b><small>Tahmini tutar</small></div></div>`}
function renderProjects(){let g=$('projectList');if(!g)return;let q=($('projectSearch')?.value||'').toLowerCase();g.innerHTML='';data.projects.filter(p=>p.name.toLowerCase().includes(q)).forEach(p=>{let row=document.createElement('div');row.className='projectRow';row.innerHTML=`<div class="projectInfo"><b>${esc(p.name)}</b><small>${p.records.length} ölçü • ${(p.tasks||[]).filter(t=>!t.done).length} açık iş${p.id===data.activeId?' • AKTİF':''}</small></div><div class="projectActions"><button class="openProject">Aç</button><button class="renameProject">Düzenle</button>${data.projects.length>1?'<button class="deleteProject">Sil</button>':''}</div>`;row.querySelector('.openProject').onclick=()=>{data.activeId=p.id;save();show('home')};row.querySelector('.renameProject').onclick=()=>{let n=prompt('Proje adı:',p.name);if(n?.trim()){p.name=n.trim();save();renderProjects()}};let d=row.querySelector('.deleteProject');if(d)d.onclick=()=>{if(confirm(`“${p.name}” silinsin mi?`)){data.projects=data.projects.filter(x=>x.id!==p.id);data.activeId=data.projects[0].id;save();renderProjects()}};g.append(row)})}
$('projectSearch').oninput=renderProjects;
$('addProject').onclick=()=>{let n=$('newProjectName').value.trim();if(!n)return alert('Proje adı yaz.');let p={id:'p_'+Date.now()+'_'+Math.random().toString(36).slice(2),name:n,records:[],notes:[],tasks:[],photos:[]};data.projects.push(p);data.activeId=p.id;$('newProjectName').value='';save();show('home')};
function fmtUnit(u){return u==='m2'?'m²':u==='m3'?'m³':u==='mtul'?'mt':u==='metre'?'m':'adet'}
function sumUnits(rs){return ['m2','mtul','metre','m3','adet'].map(u=>({u,v:rs.filter(r=>r.unit===u).reduce((s,r)=>s+(Number(r.value)||0),0)})).filter(x=>x.v)}
function totalsHtml(rs,label='Toplam'){let parts=sumUnits(rs).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`);return parts.length?`<div class="total"><span>${esc(label)}</span><span>${parts.join(' • ')}</span></div>`:''}
function renderBook(){
 let p=activeProject(),q=($('bookSearch')?.value||'').trim().toLowerCase(),floorFilter=$('bookFloor')?.value||'',catFilter=$('bookCat')?.value||'';
 let rs=p.records.filter(r=>{
   let text=`${r.cat} ${r.area} ${r.floor||''} ${r.note||''}`.toLowerCase();
   return (!q||text.includes(q))&&(!floorFilter||r.floor===floorFilter)&&(!catFilter||r.cat===catFilter);
 });
 let h=`<div class="bookToolbar"><div class="bookSearch"><span>⌕</span><input id="bookSearch" value="${esc(q)}" placeholder="Defterde ara..." autocomplete="off"></div><div class="bookFilters"><select id="bookFloor"><option value="">Tüm katlar</option>${floors.map(f=>`<option ${floorFilter===f?'selected':''}>${esc(f)}</option>`).join('')}</select><select id="bookCat"><option value="">Tüm kalemler</option>${Object.keys(areas).map(c=>`<option ${catFilter===c?'selected':''}>${esc(c)}</option>`).join('')}</select></div></div>`;
 h+=`<div class="bookQuick"><button id="bookQuickMeasure">＋ Ölçü</button><button id="bookQuickNote">＋ Not</button><button id="bookQuickTask">＋ İş</button></div>`;
 h+=`<div class="bookStats">${totalsHtml(p.records,'Proje toplamı')}</div>`;
 if(!rs.length) h+=`<div class="emptyBook"><b>${p.records.length?'Aradığın kayıt bulunamadı':'Defter boş'}</b><small>${p.records.length?'Filtreyi değiştir veya aramayı temizle.':'İlk ölçünü ekleyerek defteri oluşturmaya başla.'}</small></div>`;
 else {
   const cats=[...new Set(rs.map(r=>r.cat))];
   cats.forEach(c=>{
     h+=`<div class="bookGroupTitle">${esc(c)} <span>${rs.filter(x=>x.cat===c).length} kayıt</span></div>`;
     const floorsIn=[...new Set(rs.filter(r=>r.cat===c).map(r=>r.floor||'Kat belirtilmedi'))];
     floorsIn.forEach(f=>{
       const fr=rs.filter(r=>r.cat===c&&(r.floor||'Kat belirtilmedi')===f);
       h+=`<div class="floorGroup"><div class="floorTitle">${esc(f)} ${totalsHtml(fr,'')}</div>`;
       fr.slice().reverse().forEach(r=>{
         const realIndex=p.records.indexOf(r),unit=fmtUnit(r.unit);
         const dims=r.unit==='m3'?`${r.a} × ${r.b} × ${r.c}`:r.unit==='m2'?`${r.a} × ${r.b}`:`${r.a}`;
         const amount=r.price?`${(Number(r.value)*Number(r.price)).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})} ₺`:'';
         h+=`<article class="recordCard"><div class="recordTop"><div><b>${esc(r.area||r.cat)}</b><small>${esc(r.floor||'Kat belirtilmedi')} · ${esc(r.cat)}</small></div><strong>${Number(r.value).toLocaleString('tr-TR',{maximumFractionDigits:2})} ${unit}</strong></div><div class="recordDetail"><span>${esc(dims)} ${unit}</span>${amount?`<span>${amount}</span>`:''}</div>${r.note?`<div class="recordNote">${esc(r.note)}</div>`:''}<div class="recordActions"><button data-editrec="${realIndex}">Düzenle</button><button data-delrec="${realIndex}">Sil</button></div></article>`;
       });
       h+=`</div>`;
     });
   });
 }
 $('bookProject').textContent=p.name;$('bookContent').innerHTML=h;
 const bs=$('bookSearch');if(bs)bs.oninput=renderBook;
 const bf=$('bookFloor');if(bf)bf.onchange=renderBook;
 const bc=$('bookCat');if(bc)bc.onchange=renderBook;
 document.querySelectorAll('[data-delrec]').forEach(b=>b.onclick=()=>{let i=+b.dataset.delrec;if(confirm('Bu ölçü silinsin mi?')){p.records.splice(i,1);save();renderBook()}});
 document.querySelectorAll('[data-editrec]').forEach(b=>b.onclick=()=>{let r=p.records[+b.dataset.editrec];cat=r.cat;area=r.area;$('entryCat').textContent=cat;$('entryArea').textContent=area;$('a').value=r.a||'';$('b').value=r.b||'';$('c').value=r.c||'';$('floor').value=r.floor||'';$('unit').value=r.unit||'m2';$('note').value=r.note||'';$('price').value=r.price||'';window.editingRecordId=r.id;updateCalc();show('entry')});
 $('bookQuickMeasure')?.addEventListener('click',()=>{$('new').click()});
 $('bookQuickNote')?.addEventListener('click',()=>show('notes'));
 $('bookQuickTask')?.addEventListener('click',()=>show('tasks'));
}

function renderNotes(){let p=activeProject();$('notesProject').textContent=p.name;$('notesList').innerHTML=p.notes.length?p.notes.map((n,i)=>`<div class="noteItem"><b>${esc(n.text).replace(/\n/g,'<br>')}</b>${n.qty?`<div class="noteMeta">${esc(n.qty)} ${esc(n.unit||'')}</div>`:''}<div class="noteMeta">${esc(n.date||'')}</div><button data-dn="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz not veya malzeme yok.</div>';document.querySelectorAll('[data-dn]').forEach(b=>b.onclick=()=>{p.notes.splice(+b.dataset.dn,1);save();renderNotes();renderBook()});renderPhotos()}
function addNote(text,qty,unit){let p=activeProject(),clean=String(text||'').trim();if(!clean)return false;p.notes.push({text:clean,qty:qty?+qty:null,unit:unit||'',date:new Date().toLocaleString('tr-TR')});save();return true}
$('addNote').onclick=()=>{if(!addNote($('noteText').value,$('noteQty').value,$('noteUnit').value))return alert('Not veya malzeme yaz.');$('noteText').value='';$('noteQty').value='';$('noteUnit').value='';renderNotes();renderBook()};$('addBookNote').onclick=()=>{if(!addNote($('bookNote').value,'',''))return alert('Yazı gir.');$('bookNote').value='';renderBook()};
function renderTasks(){let p=activeProject();$('tasksProject').textContent=p.name;$('taskList').innerHTML=p.tasks.length?p.tasks.map((t,i)=>`<div class="taskItem ${t.done?'done':''}"><label><input type="checkbox" data-task="${i}" ${t.done?'checked':''}> ${esc(t.text)}</label><button data-deltask="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz yapılacak iş yok.</div>';document.querySelectorAll('[data-task]').forEach(x=>x.onchange=()=>{p.tasks[+x.dataset.task].done=x.checked;save();renderTasks()});document.querySelectorAll('[data-deltask]').forEach(x=>x.onclick=()=>{p.tasks.splice(+x.dataset.deltask,1);save();renderTasks()})}
$('addTask').onclick=()=>{let t=$('taskText').value.trim();if(!t)return alert('İş yaz.');activeProject().tasks.push({text:t,done:false,date:new Date().toLocaleString('tr-TR')});$('taskText').value='';save();renderTasks()};
function compressImage(file){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=()=>{let im=new Image();im.onload=()=>{let max=900,sc=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.62))};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
$('photoInput').onchange=async e=>{let f=e.target.files?.[0];if(!f)return;try{let src=await compressImage(f);let p=activeProject();p.photos??=[];p.photos.push({src,date:new Date().toLocaleString('tr-TR')});try{save();renderPhotos();e.target.value=''}catch(err){p.photos.pop();alert('Fotoğraf kaydedilemedi. Depolama alanı dolmuş olabilir.')} }catch(_){alert('Fotoğraf işlenemedi. Lütfen JPG/PNG bir fotoğraf seç.')}};
function renderPhotos(){let p=activeProject(),g=$('photoList');if(!g)return;g.innerHTML=p.photos.length?p.photos.map((x,i)=>`<div class="photo"><img src="${x.src}"><small>${esc(x.date)}</small><button data-dp="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz fotoğraf yok.</div>';g.querySelectorAll('[data-dp]').forEach(b=>b.onclick=()=>{p.photos.splice(+b.dataset.dp,1);save();renderPhotos()})}
const TR_NUMBERS={"sıfır":0,"bir":1,"iki":2,"üç":3,"dört":4,"beş":5,"altı":6,"yedi":7,"sekiz":8,"dokuz":9,"on":10,"yirmi":20,"otuz":30,"kırk":40,"elli":50,"altmış":60,"yetmiş":70,"seksen":80,"doksan":90,"yüz":100,"bin":1000};
function turkishNumberValue(s){
 s=String(s).toLowerCase().trim().replace(/\s+/g,' ');
 if(/^\d+(?:[.,]\d+)?$/.test(s))return parseFloat(s.replace(',','.'));
 let parts=s.split(' '),total=0,current=0,decimal=null;
 for(let x of parts){
   if(x==='buçuk'){decimal=.5;continue}
   let n=TR_NUMBERS[x]; if(n==null)return NaN;
   if(n===100||n===1000){current=(current||1)*n;total+=current;current=0}else current+=n;
 }
 return total+current+(decimal??0);
}
function numberTokens(text){
 let cleaned=normalizeText(text).replace(/['’]/g,' ').replace(/-/g,' ');
 let pattern=/\b\d+(?:[.,]\d+)?\b|\b(?:sıfır|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|otuz|kırk|elli|altmış|yetmiş|seksen|doksan|yüz|bin)(?:\s+(?:buçuk|sıfır|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|otuz|kırk|elli|altmış|yetmiş|seksen|doksan|yüz|bin))*\b/g;
 return [...cleaned.matchAll(pattern)].map(m=>turkishNumberValue(m[0])).filter(Number.isFinite);
}
function normalizeText(t){
 return String(t||'').toLowerCase().replace(/’/g,"'").replace(/×/g,' x ').replace(/m²/g,'m2').replace(/metrekare/g,'m2').replace(/metre kare/g,'m2').replace(/metreküp/g,'m3').replace(/metre küp/g,'m3').replace(/metretül/g,'mt').replace(/metre tül/g,'mt');
}
function findOne(t,list){let l=t.toLowerCase();return list.find(x=>l.includes(x.toLowerCase()))}
function floorFromText(t){let m=t.match(/(?:kat\s*)?(\d{1,2})\s*\.?\s*kat\b/i);if(m){let n=+m[1];if(n>=1&&n<=30)return `${n}. Kat`}let words={"birinci":1,"ikinci":2,"üçüncü":3,"dördüncü":4,"beşinci":5,"altıncı":6,"yedinci":7,"sekizinci":8,"dokuzuncu":9,"onuncu":10};for(let [w,n] of Object.entries(words))if(t.includes(w))return `${n}. Kat`;return ''}
function unitFromText(t){if(/\bm3\b|metreküp|metre küp/.test(t))return'm3';if(/\bmt\b|metretül|metre tül/.test(t))return'mtul';if(/\bmetre\b|\bm\b/.test(t))return'metre';if(/\badet\b/.test(t))return'adet';return'm2'}
function aiParse(){
 let p=activeProject(),t=normalizeText($('aiText').value),found=[],addedNotes=[],addedTasks=[];
 let currentCat=findOne(t,Object.keys(areas))||'Dış Cephe',currentFloor=floorFromText(t);
 let chunks=t.split(/\s*(?:,|;|\.|\bve\b|\bsonra\b)\s*/i).map(x=>x.trim()).filter(Boolean);
 chunks.forEach(ch=>{
   let c=findOne(ch,Object.keys(areas));if(c)currentCat=c;
   let a=findOne(ch,areas[currentCat]),nums=numberTokens(ch),unit=unitFromText(ch),floor=floorFromText(ch)||currentFloor;
   if(a&&nums.length>=2){
     let v=unit==='m3'&&nums.length>=3?nums[0]*nums[1]*nums[2]:unit==='mtul'||unit==='metre'||unit==='adet'?nums[0]:nums[0]*nums[1];
     if(unit==='m3'&&nums.length<3) return;
     found.push({id:'r_'+Date.now()+Math.random(),cat:currentCat,area:a,floor,a:nums[0],b:nums[1]||1,c:nums[2]||0,unit,value:+v.toFixed(2),note:'Sesli/AI girişi',price:0,createdAt:new Date().toISOString()});
   }
   let m=ch.match(/(\d+(?:[.,]\d+)?)\s*(torba|paket|adet|kg|kutu|kova|litre|metre|m2|m³)\s+(.+)/i);
   if(m)addedNotes.push({text:m[3].trim(),qty:+m[1].replace(',','.'),unit:m[2],date:new Date().toLocaleString('tr-TR')});
   if(/\b(yapılacak|yapılmalı|eksik|alınacak|alınmalı|tamamlanacak)\b/i.test(ch)&&!m)addedTasks.push({text:ch,done:false,date:new Date().toLocaleString('tr-TR')});
 });
 p.records.push(...found);p.notes.push(...addedNotes);p.tasks.push(...addedTasks);
 if(found.length||addedNotes.length||addedTasks.length){save();$('aiResult').innerHTML=[...found.map(r=>`✓ ${esc(r.floor?r.floor+' · ':'')}${esc(r.cat)} / ${esc(r.area)}: ${r.unit==='m3'?`${r.a} × ${r.b} × ${r.c}`:r.unit==='m2'?`${r.a} × ${r.b}`:r.a} = <b>${r.value} ${fmtUnit(r.unit)}</b>`),...addedNotes.map(n=>`✓ Malzeme: ${esc(n.qty+' '+n.unit+' '+n.text)}`),...addedTasks.map(n=>`✓ İş: ${esc(n.text)}`)].join('<br>');return}
 $('aiResult').innerHTML='<b>Komutu anlayamadım.</b><br>Örnek: “3. kat alçı sıva salon 35 e 2,80. 20 torba alçı ekle. Salon yapılacak.”';
}

function handleNativeVoice(text){$('aiText').value=text;$('aiResult').innerHTML=`<small>Duydum: “${esc(text)}”</small>`;aiParse()}function voiceError(msg){$('aiResult').innerHTML=`<b>Sesli giriş hatası:</b> ${esc(msg)}`}
$('aiParse').onclick=aiParse;$('voice').onclick=()=>{ $('aiResult').innerHTML='<b>Dinliyorum...</b> Ölçü, malzeme veya yapılacak işi söyle.';if(window.AndroidVoice){AndroidVoice.startVoice();return}let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return voiceError('Bu cihazda ses tanıma desteklenmiyor.');let r=new SR();r.lang='tr-TR';r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>handleNativeVoice(e.results[0][0].transcript);r.onerror=e=>voiceError(e.error||'Ses tanınamadı.');try{r.start()}catch(e){voiceError('Sesli giriş başlatılamadı.')}};
const calcField=$('calcInput'); const calcNormalize=()=>calcField.value.replace(/,/g,'.').replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-'); const runCalc=()=>{let x=calcNormalize().replace(/[^0-9+\-*/().\s]/g,'');if(!x.trim())return;try{let v=Function('\"use strict\";return ('+x+')')();if(!Number.isFinite(v))throw 0;$('calcResult').textContent=Number(v.toFixed(4));}catch(_){$('calcResult').textContent='Hatalı işlem';}}; $('doCalc').onclick=runCalc; document.querySelectorAll('#calcKeys [data-key]').forEach(btn=>btn.onclick=()=>{let k=btn.dataset.key;if(k==='=')return runCalc();if(k==='clear'){calcField.value='';$('calcResult').textContent='0';return;}if(k==='back'){calcField.value=calcField.value.slice(0,-1);return;}calcField.value+=k==='.'?',':k;calcField.focus();}); calcField.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runCalc();}});
function reportText(){let p=activeProject(),s=`${p.name}\n\nÖLÇÜLER\n`;p.records.forEach(r=>s+=`${r.cat} / ${r.area}${r.floor?' / '+r.floor:''}: ${r.unit==='m3'?r.a+' x '+r.b+' x '+r.c:r.unit==='m2'?r.a+' x '+r.b:r.a} = ${r.value} ${fmtUnit(r.unit)}${r.price?' • '+r.price+' ₺/birim':''}\n`);s+='\nNOT / MALZEMELER\n';p.notes.forEach(n=>s+=`${n.qty?n.qty+' '+n.unit+' ':''}${n.text}\n`);s+='\nYAPILACAKLAR / EKSİKLER\n';p.tasks.forEach(t=>s+=`${t.done?'[x]':'[ ]'} ${t.text}\n`);return s}
$('copy').onclick=()=>{let s=reportText();if(navigator.share)navigator.share({title:activeProject().name,text:s}).catch(()=>{});else navigator.clipboard?.writeText(s).then(()=>alert('Defter kopyalandı.')).catch(()=>alert(s))};$('pdf').onclick=()=>{let s=reportText();if(window.AndroidPrint&&AndroidPrint.printReport){AndroidPrint.printReport(s);return;}let w=window.open('','_blank');if(!w)return alert('Yazdırma penceresi açılamadı.');w.document.write('<pre style="font:14px Arial;white-space:pre-wrap">'+esc(s)+'</pre>');w.document.close();w.focus();setTimeout(()=>w.print(),300)};
$('new').onclick=()=>{renderCats();show('categories')};$('openAI').onclick=()=>show('ai');$('bookBtn').onclick=()=>show('book');$('noteBtn').onclick=()=>show('notes');$('taskBtn').onclick=()=>show('tasks');$('calcBtn').onclick=()=>show('calculator');$('project').onclick=()=>show('projects');$('clear').onclick=()=>{if(confirm('Bu projenin tüm ölçüleri silinsin mi?')){activeProject().records=[];save();renderBook()}};
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{if(b.dataset.go==='categories')renderCats();show(b.dataset.go)});document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>show(b.dataset.back));
// PRO
function renderPro(){let p=activeProject();
 $('custName').value=p.customer?.name||'';$('custPhone').value=p.customer?.phone||'';$('custAddress').value=p.customer?.address||'';$('projectDesc').value=p.customer?.desc||'';
 let groups={};p.records.forEach(r=>{let k=`${r.cat}||${r.floor||'Kat belirtilmedi'}`;(groups[k]??=[]).push(r)});
 let rows='';Object.entries(groups).forEach(([k,rs])=>{let [cat,floor]=k.split('||'),parts=sumUnits(rs).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`).join(' • '),amount=rs.reduce((s,r)=>s+(r.price||0)*r.value,0);rows+=`<div class="line"><b>${esc(cat)} · ${esc(floor)}</b><span>${parts||'-'}${amount?` • ${amount.toLocaleString('tr-TR',{minimumFractionDigits:2})} ₺`:''}</span></div>`});
 $('proTotals').innerHTML=rows||'<div class="muted">Henüz ölçü yok.</div>';$('quotePreview').innerHTML='';
}
$('proBtn').onclick=()=>{renderPro();show('pro')};
$('saveCustomer').onclick=()=>{let p=activeProject();p.customer={name:$('custName').value.trim(),phone:$('custPhone').value.trim(),address:$('custAddress').value.trim(),desc:$('projectDesc').value.trim()};save();alert('Proje bilgileri kaydedildi.');};
function buildQuote(){let p=activeProject(),tax=parseFloat($('taxRate').value)||0,rows=p.records.map(r=>({name:r.cat+' / '+r.area,qty:r.value,unit:r.unit==='m2'?'m²':r.unit==='m3'?'m³':r.unit==='mtul'?'mt':r.unit,price:r.price||0,total:(r.price||0)*r.value})).filter(x=>x.total>0);let sub=rows.reduce((s,r)=>s+r.total,0),vat=sub*tax/100,total=sub+vat;let s=`${p.name}\nTEKLİF / HAKEDİŞ\n\nMüşteri: ${p.customer?.name||'-'}\nTelefon: ${p.customer?.phone||'-'}\nAdres: ${p.customer?.address||'-'}\n\n`;rows.forEach(r=>s+=`${r.name}: ${r.qty} ${r.unit} × ${r.price.toFixed(2)} ₺ = ${r.total.toFixed(2)} ₺\n`);s+=`\nAra toplam: ${sub.toFixed(2)} ₺\nKDV (%${tax}): ${vat.toFixed(2)} ₺\nGENEL TOPLAM: ${total.toFixed(2)} ₺`;return {s,sub,vat,total,rows};}
$('makeQuote').onclick=()=>{let q=buildQuote();$('quotePreview').innerHTML=`<b>${esc(activeProject().name)}</b><br>${q.rows.length?esc(q.rows.map(r=>`${r.name}: ${r.qty} ${r.unit} × ${r.price.toFixed(2)} ₺ = ${r.total.toFixed(2)} ₺`).join('\n')).replace(/\n/g,'<br>'):'Birim fiyat girilmiş kayıt yok.'}<hr>Ara toplam: <b>${q.sub.toFixed(2)} ₺</b><br>KDV: ${q.vat.toFixed(2)} ₺<br>Genel toplam: <b>${q.total.toFixed(2)} ₺</b>`};
$('shareQuote').onclick=()=>{let q=buildQuote();if(navigator.share)navigator.share({title:activeProject().name+' Teklif',text:q.s}).catch(()=>{});else navigator.clipboard?.writeText(q.s).then(()=>alert('Teklif kopyalandı. WhatsApp veya başka uygulamadan paylaşabilirsin.')).catch(()=>alert(q.s));};
$('exportBackup').onclick=()=>{let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='olcu-defteri-yedek-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),500);};
$('doImport').onclick=()=>{let f=$('importBackup').files?.[0];if(!f)return alert('Önce yedek dosyası seç.');let r=new FileReader();r.onload=()=>{try{let incoming=JSON.parse(r.result);if(!incoming.projects?.length)throw 0;if(!confirm('Mevcut verilerin üzerine yedek geri yüklenecek. Devam edilsin mi?'))return;data=incoming;save();renderPro();alert('Yedek geri yüklendi.');}catch(e){alert('Geçersiz yedek dosyası.')}};r.readAsText(f)};
$('welcomeStart').onclick=()=>{localStorage.setItem('od5_welcomed','1');show('home')};
if(localStorage.getItem('od5_welcomed')==='1'){renderHome();renderProjects();}else{show('welcome')}


window.closePrintView = function () {
  try {
    var overlay = document.querySelector('.print-view, #printView, .print-modal, [data-print-view]');
    if (overlay) overlay.remove();
    document.body.classList.remove('printing', 'print-view-open');
    window.scrollTo(0, 0);
  } catch (e) {}
};
