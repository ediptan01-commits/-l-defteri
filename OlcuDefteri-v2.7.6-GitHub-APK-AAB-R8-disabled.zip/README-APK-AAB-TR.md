# Ölçü Defteri Pro 2.7.6 — APK ve AAB oluşturma

Bu kaynak projesi, GitHub Actions kullanarak imzalı Android APK ve Google Play için AAB oluşturacak şekilde hazırlanmıştır. Release derlemesinde R8 kod küçültmesi ve kaynak daraltma kapatılmıştır; bu, WorkManager veritabanı başlatma çökmesinin R8 kaynaklı olabileceği ihtimalini hedefler.

## GitHub'da derleme

1. ZIP'i bilgisayarınıza çıkarın.
2. İçindeki dosya ve klasörleri bir GitHub deposunun kök dizinine yükleyin. `.github/workflows/build-apk.yml` dosyasının bu konumda kaldığını kontrol edin.
3. Depoda **Settings → Secrets and variables → Actions** bölümüne aşağıdaki dört Actions secret'ını ekleyin:
   - `ANDROID_KEYSTORE_BASE64`: Mevcut Play Console upload keystore dosyanızın Base64 metni.
   - `ANDROID_KEYSTORE_PASSWORD`: Keystore parolası.
   - `ANDROID_KEY_ALIAS`: Keystore içindeki anahtarın alias adı.
   - `ANDROID_KEY_PASSWORD`: Anahtar parolası.
4. GitHub deposunda **Actions → Ölçü Defteri Pro - APK ve AAB → Run workflow** seçin.
5. İşlem tamamlanınca workflow çalışmasının **Artifacts** bölümünden `OlcuDefteri-v2.7.6-APK-AAB` paketini indirin. ZIP'in içinde release APK ve AAB bulunur.

## Önemli

- Play Console'a yüklemek için uygulamanın daha önceki sürümlerinde kullanılan aynı upload keystore gerekir. Anahtarınız yoksa bu workflow imzalı release dosyalarını üretemez.
- Bu kaynakta `versionCode 60` ve `versionName 2.7.6` değerleri bulunuyor. Play Console'da 60 veya daha yüksek versionCode daha önce kullanıldıysa yeni sürüm göndermeden önce versionCode artırılmalıdır.
- Workflow GitHub Actions üzerinde Gradle 9.1.0, Java 17 ve Android SDK 36 kurarak derleme yapar.
- Bu arşiv hazırlanırken GitHub Actions üzerinde gerçek bir derleme veya cihaz testi çalıştırılmadı. Değişikliğin çöküşü çözdüğü doğrulanmış değildir. Uygulama yine çökerse, logcat içindeki WorkDatabase hatasının devamındaki en içteki tam `Caused by` bölümünü paylaşın.
- Projenin Supabase ayarları `app/src/main/assets/config.json` dosyasındadır. Workflow, gerekli alanların dolu olduğunu kontrol eder.

