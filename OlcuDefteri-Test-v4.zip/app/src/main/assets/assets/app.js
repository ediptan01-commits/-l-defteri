const $=id=>document.getElementById(id);
const areas={
"Dış Cephe":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],
"Alçıpan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Işık Bandı","Soffit","Kolon","Kiriş","Diğer"],
"Duvar":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],
"İç Sıva":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],
"Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Tavan","Kapılar","Diğer"],
"Tavan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Diğer"],
"Mantolama":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],
"Seramik":["Banyo Zemin","Banyo Duvar","WC Zemin","WC Duvar","Mutfak","Balkon","Teras","Diğer"],
"Şap":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","Koridor","Balkon","Teras","Diğer"],
"Işık Bandı":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Koridor","Merdiven","Diğer"],
"Fuga / Söve":["Ön Cephe","Arka Cephe","Sağ Cephe","Sol Cephe","Kör Cephe","Pencere Çevresi","Kapı Çevresi","Diğer"],
"Süpürgelik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Koridor","Antre","Diğer"],
"Kapı / Pencere":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Balkon","Diğer"],
"Elektrik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Dış Cephe","Pano","Diğer"],
"Sıhhi Tesisat":["Banyo","WC","Mutfak","Çamaşır Alanı","Bahçe","Diğer"],
"Çatı":["Ana Çatı","Teras Çatı","Saçak","Oluk","Dere","Diğer"]
};
let data=JSON.parse(localStorage.getItem("od5")||'{"project":"A İnşaat","records":[]}'),cat="",area="";
function save(){localStorage.setItem("od5",JSON.stringify(data));renderHome()}
function show(id){["home","categories","areas","entry","ai","book"].forEach(x=>$(x).classList.toggle("hide",x!==id));if(id==="book")renderBook()}
function tile(t,s,fn){let b=document.createElement("button");b.className="tile";b.innerHTML=`${t}<small>${s}</small>`;b.onclick=fn;return b}
function renderCats(){let g=$("cats");g.innerHTML="";Object.keys(areas).forEach(k=>g.append(tile(k,"Seç",()=>{cat=k;$("catName").textContent=k;let ag=$("areasGrid");ag.innerHTML="";areas[k].forEach(a=>ag.append(tile(a,"Ölçü gir",()=>{area=a;$("entryCat").textContent=cat;$("entryArea").textContent=area;clearEntry();show("entry")})));show("areas")})))}
function clearEntry(){$("a").value="";$("b").value="";$("note").value="";updateCalc()}
function updateCalc(){let a=+$("a").value||0,b=+$("b").value||0,u=$("unit").value,v=u==="m2"?a*b:u==="m"?a:a;$("calc").textContent=`${a} × ${b} = ${Number(v.toFixed(2))} ${u}`}
$("a").oninput=updateCalc;$("b").oninput=updateCalc;$("unit").onchange=updateCalc;
$("save").onclick=()=>{let a=+$("a").value||0,b=+$("b").value||0,u=$("unit").value,v=u==="m2"?a*b:u==="m"?a:a;if(!v)return alert("Ölçü gir.");data.records.push({cat,area,a,b,unit:u,value:+v.toFixed(2),note:$("note").value});save();show("areas")};
function renderHome(){$("projectName").textContent=data.project;$("recent").innerHTML=data.records.length?data.records.slice(-6).reverse().map(r=>`<div class="line"><b>${r.cat} / ${r.area}</b><span>${r.a} × ${r.b} = ${r.value} ${r.unit}</span></div>`).join(""):"Henüz kayıt yok."}
function renderBook(){$("bookProject").textContent=data.project;let g={};data.records.forEach(r=>(g[r.cat]??=[]).push(r));let h="";for(let c in g){h+=`<div class="sectionTitle">${c.toUpperCase()} ÖLÇÜLERİ</div>`;g[c].forEach(r=>h+=`<div class="line"><b>${r.area}</b><span>${r.a} × ${r.b} = ${r.value} ${r.unit}</span></div>`);let t=g[c].filter(r=>r.unit==="m2").reduce((s,r)=>s+r.value,0);if(t)h+=`<div class="total"><span>Toplam</span><span>${t.toLocaleString("tr-TR",{maximumFractionDigits:2})} m²</span></div>`}$("bookContent").innerHTML=h||"Henüz ölçü yok."}
function parseNum(s){return parseFloat(String(s).replace(",",".").replace(/metre|metreler|m2|m²/gi,"").trim())}
function findArea(text,list){let low=text.toLowerCase();return list.find(x=>low.includes(x.toLowerCase()))}
function normalizeText(t){return t.toLowerCase().replaceAll("’","'").replaceAll("×","x").replaceAll("m²","m2").replaceAll("metrekare","m2").replaceAll("metre kare","m2");}
function aiParse(){
 let t=normalizeText($("aiText").value), found=[];
 let currentCat=findArea(t,Object.keys(areas))||"Dış Cephe";
 Object.keys(areas).forEach(c=>{if(t.includes(c.toLowerCase())) currentCat=c;});
 let chunks=t.split(/[,;\n]+/);
 chunks.forEach(ch=>{
   let a=findArea(ch,areas[currentCat]);
   let nums=[...ch.matchAll(/(\d+(?:[.,]\d+)?)/g)].map(x=>parseNum(x[1]));
   if(a&&nums.length>=2){let v=nums[0]*nums[1];found.push({cat:currentCat,area:a,a:nums[0],b:nums[1],unit:"m2",value:+v.toFixed(2),note:"AI girişi"});}
 });
 if(!found.length){
   $("aiResult").innerHTML="<b>Ölçüyü anlayamadım.</b><br>Örnek: Dış cephe ön cephe 15'e 10, arka cephe 15'e 10.";return;
 }
 data.records.push(...found);save();
 $("aiResult").innerHTML=found.map(r=>`✓ ${r.cat} / ${r.area}: ${r.a} × ${r.b} = <b>${r.value} m²</b>`).join("<br>");
}
function handleNativeVoice(text){$("aiText").value=text;aiParse();}
function voiceError(msg){alert(msg);}
$("aiParse").onclick=aiParse;
$("voice").onclick=()=>{if(window.AndroidVoice){AndroidVoice.startVoice();return;}let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return alert("Sesli giriş desteklenmiyor.");let r=new SR();r.lang="tr-TR";r.onresult=e=>handleNativeVoice(e.results[0][0].transcript);r.start()};
$("new").onclick=()=>{renderCats();show("categories")};$("openAI").onclick=()=>show("ai");$("bookBtn").onclick=()=>show("book");
$("project").onclick=()=>{let p=prompt("İnşaat / proje adı:",data.project);if(p){data.project=p;save()}}
$("clear").onclick=()=>{if(confirm("Tüm ölçüler silinsin mi?")){data.records=[];save();renderBook()}}
$("copy").onclick=async()=>{let g={};data.records.forEach(r=>(g[r.cat]??=[]).push(r));let s=data.project+"\\n\\n";for(let c in g){s+=c.toUpperCase()+" ÖLÇÜLERİ\\n";g[c].forEach(r=>s+=`${r.area}: ${r.a} x ${r.b} = ${r.value} ${r.unit}\\n`);s+="\\n"}try{await navigator.clipboard.writeText(s);alert("Defter kopyalandı.")}catch(e){alert(s)}};
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{if(b.dataset.go==="categories")renderCats();show(b.dataset.go)});document.querySelectorAll("[data-back]").forEach(b=>b.onclick=()=>show(b.dataset.back));renderHome();