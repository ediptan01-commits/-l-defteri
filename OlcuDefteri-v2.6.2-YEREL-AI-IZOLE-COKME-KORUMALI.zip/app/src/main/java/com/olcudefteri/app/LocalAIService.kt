package com.olcudefteri.app

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException

/**
 * Runs the native LiteRT-LM engine in a separate Android process.
 * A native model crash therefore cannot take down the WebView/main process.
 */
class LocalAIService : Service() {
    companion object {
        const val MSG_ASK = 1
        const val MSG_DOWNLOAD = 2
        const val MSG_RESULT = 10
        const val MSG_PROGRESS = 11
        const val MSG_DOWNLOAD_DONE = 12
    }

    private var engine: LocalAIEngine? = null
    private val handler = Handler(Looper.getMainLooper()) { msg ->
        when (msg.what) {
            MSG_ASK -> {
                val reply = msg.replyTo
                val prompt = msg.data.getString("prompt", "")
                try {
                    getEngine().ask(prompt, object : LocalAIEngine.Callback {
                        override fun success(text: String) {
                            send(reply, MSG_RESULT, Bundle().apply { putBoolean("ok", true); putString("payload", text) })
                        }
                        override fun error(message: String) {
                            send(reply, MSG_RESULT, Bundle().apply { putBoolean("ok", false); putString("payload", message) })
                        }
                    })
                } catch (t: Throwable) {
                    send(reply, MSG_RESULT, Bundle().apply { putBoolean("ok", false); putString("payload", t.message ?: "Yerel AI başlatılamadı.") })
                }
                true
            }
            MSG_DOWNLOAD -> {
                val reply = msg.replyTo
                try {
                    getEngine().downloadModel(object : LocalAIEngine.StatusCallback {
                        override fun progress(percent: Int, downloaded: Long, total: Long) {
                            send(reply, MSG_PROGRESS, Bundle().apply { putInt("percent", percent); putLong("downloaded", downloaded); putLong("total", total) })
                        }
                        override fun done(ok: Boolean, message: String) {
                            send(reply, MSG_DOWNLOAD_DONE, Bundle().apply { putBoolean("ok", ok); putString("message", message) })
                        }
                    })
                } catch (t: Throwable) {
                    send(reply, MSG_DOWNLOAD_DONE, Bundle().apply { putBoolean("ok", false); putString("message", t.message ?: "Model indirilemedi.") })
                }
                true
            }
            else -> false
        }
    }
    private val messenger = Messenger(handler)

    private fun getEngine(): LocalAIEngine {
        if (engine == null) engine = LocalAIEngine(applicationContext)
        return engine!!
    }

    private fun send(target: Messenger?, what: Int, data: Bundle) {
        if (target == null) return
        try {
            val m = Message.obtain(null, what)
            m.data = data
            target.send(m)
        } catch (_: RemoteException) { }
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        try { engine?.shutdown() } catch (_: Throwable) {}
        engine = null
        super.onDestroy()
    }
}
