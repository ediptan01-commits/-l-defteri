package com.olcudefteri.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.WindowInsets;
import android.graphics.Color;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.net.Uri;
import android.content.SharedPreferences;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.WebViewClient;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 701;
    private static final int REQ_SPEECH = 702;
    private static final int REQ_FILE = 703;
    private WebView web;
    private boolean printScreenOpen = false;
    private ValueCallback<Uri[]> fileCallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(false);
        WebChromeClient chrome = new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                }
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try {
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        };
        WebSettingsCompat.configure(web);
        getWindow().setStatusBarColor(Color.rgb(17,24,39));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getDecorView().setSystemUiVisibility(0);
        }
        web.setPadding(0, getStatusBarHeight(), 0, 0);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = android.os.Build.VERSION.SDK_INT >= 30
                    ? insets.getInsets(WindowInsets.Type.statusBars()).top
                    : insets.getSystemWindowInsetTop();
            v.setPadding(0, Math.max(top, getStatusBarHeight()), 0, 0);
            return insets;
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        web.setWebChromeClient(chrome);
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.addJavascriptInterface(new NativePrintBridge(), "AndroidPrint");
        web.addJavascriptInterface(new AuthBridge(), "AndroidAuth");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        handleAuthIntent(getIntent());
    }

    public class VoiceBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                } else launchSpeech();
            });
        }
    }

    private void launchSpeech() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ölçünüzü söyleyin. Örneğin: dış cephe ön cephe on beşe on.");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { sendJs("window.voiceError && window.voiceError('Bu cihazda sesli giriş hizmeti bulunamadı')"); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchSpeech();
            else sendJs("window.voiceError && window.voiceError('Mikrofon izni verilmedi')");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String text = r.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                sendJs("window.handleNativeVoice && window.handleNativeVoice('" + text + "')");
            }
        } else if (requestCode == REQ_SPEECH) {
            sendJs("window.voiceError && window.voiceError('Ses alınamadı veya işlem iptal edildi. Tekrar deneyin.')");
        } else if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }


    public class NativePrintBridge {
        @JavascriptInterface public void printReport(String text) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(MainActivity.this);
                WebSettingsCompat.configure(printWeb);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { alertPrintError(); return; }
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("olcu_defteri", "Ölçü Defteri", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print("Ölçü Defteri - " + activePrintTitle(), view.createPrintDocumentAdapter("Ölçü Defteri"), attrs);
                    }
                });
                String safe = text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:24px;font-size:12pt;line-height:1.5}h1{font-size:18pt}pre{white-space:pre-wrap;font-family:sans-serif}</style></head><body><h1>Ölçü Defteri</h1><pre>" + safe + "</pre></body></html>";
                printWeb.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
        private String activePrintTitle() { return "Rapor"; }
        private void alertPrintError() { sendJs("alert('Yazdırma hizmeti bu cihazda kullanılamıyor.')"); }
    }

    public class AuthBridge {
        @JavascriptInterface public String getSupabaseConfig() {
            try {
                InputStream in = getAssets().open("config.json");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                in.close();
                return out.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public void openExternal(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
        }

        @JavascriptInterface public void startGoogleOAuth(String supabaseUrl, String redirectUri) {
            try {
                byte[] random = new byte[32];
                new SecureRandom().nextBytes(random);
                String verifier = Base64.encodeToString(random, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                String challenge = Base64.encodeToString(md.digest(verifier.getBytes(java.nio.charset.StandardCharsets.US_ASCII)), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
                getSharedPreferences("od_auth", MODE_PRIVATE).edit().putString("pkce_verifier", verifier).apply();
                String url = supabaseUrl + "/auth/v1/authorize?provider=google&redirect_to=" + Uri.encode(redirectUri) + "&flow_type=pkce&code_challenge=" + Uri.encode(challenge) + "&code_challenge_method=s256";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                sendJs("window.authError && window.authError('Google girişi başlatılamadı.')");
            }
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleAuthIntent(intent);
    }

    private void handleAuthIntent(Intent intent) {
        Uri u=intent==null?null:intent.getData();
        if(u!=null && "olcudefteri".equals(u.getScheme())) {
            String safe=u.toString().replace("\\","\\\\").replace("'","\\'");
            String verifier=getSharedPreferences("od_auth", MODE_PRIVATE).getString("pkce_verifier", "");
            String safeVerifier=verifier.replace("\\","\\\\").replace("'","\\'");
            getSharedPreferences("od_auth", MODE_PRIVATE).edit().remove("pkce_verifier").apply();
            sendJs("window.authHandleCallback && window.authHandleCallback('"+safe+"','"+safeVerifier+"')");
        }
    }

    private int getStatusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : (int)(24 * getResources().getDisplayMetrics().density);
    }

    private void sendJs(String js) { if (web != null) web.post(() -> web.evaluateJavascript(js, null)); }
    @Override public void onBackPressed() {
        if (printScreenOpen) {
            printScreenOpen = false;
            if (web != null) {
                web.post(() -> web.evaluateJavascript(
                    "window.closePrintView && window.closePrintView()", null));
            }
            return;
        }
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
