# R8/minification is temporarily disabled in app/build.gradle to avoid release-only startup crashes.
