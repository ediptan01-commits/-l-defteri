const AUTH_CONFIG_URL='config.json';
let authConfig={supabaseUrl:'',supabaseAnonKey:'',redirectUri:'olcudefteri://auth-callback'};
let authSession=JSON.parse(localStorage.getItem('od_auth')||'null');
async function loadAuthConfig(){try{const r=await fetch(AUTH_CONFIG_URL+'?v=3',{cache:'no-store'});if(r.ok)authConfig=await r.json()}catch(_){} }
const authConfigured=()=>authConfig.supabaseUrl && authConfig.supabaseAnonKey && !authConfig.supabaseUrl.includes('YOUR-PROJECT') && !authConfig.supabaseAnonKey.includes('YOUR_SUPABASE');
function authMsg(t,ok=false){const e=document.getElementById('authStatus');if(e){e.textContent=t;e.style.color=ok?'#166534':''}}
function authShow(){document.querySelectorAll('main').forEach(x=>x.classList.add('hide'));document.getElementById('auth').classList.remove('hide');renderAuth()}
function renderAuth(){const card=document.getElementById('accountCard'),email=document.getElementById('accountEmail');if(authSession){card.classList.remove('hide');email.textContent=authSession.email||''}else card.classList.add('hide')}
function saveAuthSession(s){authSession=s;localStorage.setItem('od_auth',JSON.stringify(s));renderAuth()}
async function supa(path,opts={}){if(!authConfigured())throw new Error('Hesap sistemi henüz sunucuya bağlanmadı. Supabase bilgileri gerekli.');const h=Object.assign({'apikey':authConfig.supabaseAnonKey,'Content-Type':'application/json'},opts.headers||{});const r=await fetch(authConfig.supabaseUrl+path,Object.assign({},opts,{headers:h}));const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.msg||j.message||j.error_description||'İşlem başarısız.');return j}
async function emailLogin(signup){const email=document.getElementById('authEmail').value.trim(),password=document.getElementById('authPassword').value;if(!email||!password)return authMsg('E-posta ve şifreyi doldur.');if(password.length<6)return authMsg('Şifre en az 6 karakter olmalı.');authMsg(signup?'Hesap oluşturuluyor...':'Giriş yapılıyor...');try{if(signup){const j=await supa('/auth/v1/signup',{method:'POST',body:JSON.stringify({email,password})});if(j.access_token)saveAuthSession({email,access_token:j.access_token,refresh_token:j.refresh_token,user:j.user});authMsg(j.access_token?'Hesap oluşturuldu ve giriş yapıldı.':'Hesap oluşturuldu. E-postanı doğrulaman gerekebilir.',true)}else{const j=await supa('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email,password})});saveAuthSession({email:j.user?.email||email,access_token:j.access_token,refresh_token:j.refresh_token,user:j.user});authMsg('Giriş başarılı.',true)}}catch(e){authMsg(e.message)}}
async function syncData(){if(!authSession?.access_token)return authMsg('Önce giriş yap.');if(!authConfigured())return authMsg('Bulut yedekleme için Supabase bağlantısı gerekli.');try{await supa('/rest/v1/user_data?on_conflict=user_id',{method:'POST',headers:{'Authorization':'Bearer '+authSession.access_token,'Prefer':'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({user_id:authSession.user?.id,data:window.data||{},updated_at:new Date().toISOString()})});authMsg('Veriler buluta kaydedildi.',true)}catch(e){authMsg(e.message)}}
function googleLogin(){
  if(!authConfigured())return authMsg('Google girişi için Supabase bağlantısı hazır değil.');
  if(window.AndroidAuth&&AndroidAuth.startGoogleOAuth){
    AndroidAuth.startGoogleOAuth(authConfig.supabaseUrl,authConfig.redirectUri);
    authMsg('Google giriş sayfası açılıyor...',true);
    return;
  }
  const u=authConfig.supabaseUrl+'/auth/v1/authorize?provider=google&redirect_to='+encodeURIComponent(authConfig.redirectUri)+'&flow_type=implicit';
  location.href=u;
}
window.authHandleCallback=async function(uri,verifier){
  try{
    const hash=uri.includes('#')?uri.split('#')[1]:'';
    const query=uri.includes('?')?uri.split('?')[1].split('#')[0]:'';
    const hp=new URLSearchParams(hash),qp=new URLSearchParams(query);
    const at=hp.get('access_token'),rt=hp.get('refresh_token'),code=qp.get('code');
    if(at){
      let user=null;
      try{user=await supa('/auth/v1/user',{headers:{'Authorization':'Bearer '+at}})}catch(_){}
      saveAuthSession({email:user?.email||'Google hesabı',access_token:at,refresh_token:rt||'',user:user||null});
      authShow();authMsg('Google ile giriş başarılı.',true);return;
    }
    if(code&&verifier){
      authMsg('Google hesabı doğrulanıyor...');
      const r=await fetch(authConfig.supabaseUrl+'/auth/v1/token?grant_type=pkce',{method:'POST',headers:{'apikey':authConfig.supabaseAnonKey,'Content-Type':'application/json'},body:JSON.stringify({auth_code:code,code_verifier:verifier})});
      const j=await r.json().catch(()=>({}));
      if(!r.ok)throw new Error(j.msg||j.message||j.error_description||'Google giriş kodu doğrulanamadı.');
      let user=j.user||null;
      if(!user&&j.access_token){try{user=await supa('/auth/v1/user',{headers:{'Authorization':'Bearer '+j.access_token}})}catch(_){} }
      saveAuthSession({email:user?.email||'Google hesabı',access_token:j.access_token,refresh_token:j.refresh_token||'',user});
      authShow();authMsg('Google ile giriş başarılı.',true);
    }
  }catch(e){authMsg(e.message||'Google girişi tamamlanamadı.')}
}

document.addEventListener('DOMContentLoaded',async()=>{await loadAuthConfig();document.getElementById('loginBtn').onclick=()=>emailLogin(false);document.getElementById('signupBtn').onclick=()=>emailLogin(true);document.getElementById('googleBtn').onclick=googleLogin;document.getElementById('guestBtn').onclick=()=>show('home');document.getElementById('syncBtn').onclick=syncData;document.getElementById('logoutBtn').onclick=()=>{saveAuthSession(null);authMsg('Çıkış yapıldı.');show('home')};document.getElementById('accountBtn').onclick=authShow;});
