package com.olcudefteri.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.view.WindowInsets;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import android.graphics.Color;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.net.Uri;
import android.content.SharedPreferences;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import org.json.JSONObject;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.WebViewClient;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 701;
    private static final int REQ_SPEECH = 702;
    private static final int REQ_FILE = 703;
    private WebView web;
    private AdView bannerAdView;
    private InterstitialAd interstitialAd;
    private boolean exitAfterInterstitial = false;
    private boolean printScreenOpen = false;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingAuthUri = null;
    private String pendingAuthVerifier = null;
    private String pendingNativeGoogleResult = null;
    private BillingManager billingManager;
    private TextToSpeech tts;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(false);
        WebChromeClient chrome = new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                }
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try {
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        };
        WebSettingsCompat.configure(web);

        // Android 15/16 (targetSdk 35+) zorunlu edge-to-edge davranışında
        // WebView sistem çubuklarının altına taşabilir. Durum çubuğunu şeffaf
        // bırakıp açık uygulama arka planında koyu sistem ikonları kullanıyoruz.
        // Böylece saat/bildirim simgeleri beyaz zeminde kaybolmaz.
        configureSystemBars(true);
        web.setBackgroundColor(Color.rgb(244,245,247));

        // Android 15/16 edge-to-edge: keep the WebView itself below the
        // transparent status/navigation bars instead of padding its content.
        // This prevents scrolled cards and sticky elements from sliding under
        // the system status bar.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244,245,247));
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(web, webLp);
        bannerAdView = new AdView(this);
        bannerAdView.setAdUnitId("ca-app-pub-5866785474078079/5929039478");
        bannerAdView.setAdSize(AdSize.BANNER);
        FrameLayout.LayoutParams adLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL);
        root.addView(bannerAdView, adLp);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = android.os.Build.VERSION.SDK_INT >= 30
                    ? insets.getInsets(WindowInsets.Type.statusBars()).top
                    : insets.getSystemWindowInsetTop();
            int bottom = android.os.Build.VERSION.SDK_INT >= 30
                    ? insets.getInsets(WindowInsets.Type.navigationBars()).bottom
                    : insets.getSystemWindowInsetBottom();
            top = Math.max(top, getStatusBarHeight());
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) web.getLayoutParams();
            lp.topMargin = top;
            lp.bottomMargin = bottom + (int) (50 * getResources().getDisplayMetrics().density);
            lp.leftMargin = 0;
            lp.rightMargin = 0;
            web.setLayoutParams(lp);
            final int b = bottom;
            web.post(() -> web.evaluateJavascript("document.documentElement.style.setProperty(\'--android-nav-bottom\',\'"+b+"px\')", null));
            return insets;
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public void onPageFinished(WebView view, String url) {
                flushPendingAuth();
                flushPendingNativeGoogleResult();
            }
        });
        web.setWebChromeClient(chrome);
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.addJavascriptInterface(new TTSBridge(), "AndroidTTS");
        web.addJavascriptInterface(new NativePrintBridge(), "AndroidPrint");
        web.addJavascriptInterface(new AuthBridge(), "AndroidAuth");
        web.addJavascriptInterface(new SystemBarsBridge(), "AndroidSystemBars");
        billingManager = new BillingManager(this, new BillingManager.Callback() {
            @Override public void onReady(String price) { sendJs("window.billingReady && window.billingReady(" + JSONObject.quote(price) + ")"); }
            @Override public void onSubscriptionReady(String monthlyPrice, String yearlyPrice) { sendJs("window.billingSubscriptionsReady && window.billingSubscriptionsReady(" + JSONObject.quote(monthlyPrice) + "," + JSONObject.quote(yearlyPrice) + ")"); }
            @Override public void onEntitlement(boolean pro) { sendJs("window.billingEntitlement && window.billingEntitlement(" + pro + ")"); }
            @Override public void onError(String message) { sendJs("window.billingError && window.billingError(" + JSONObject.quote(message) + ")"); }
        });
        web.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        setContentView(root);
        MobileAds.initialize(this, initializationStatus -> runOnUiThread(() -> {
            if (bannerAdView != null) bannerAdView.loadAd(new AdRequest.Builder().build());
            loadInterstitialAd();
        }));
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                () -> handleSystemBack()
            );
        }
        web.loadUrl("file:///android_asset/index.html");
        handleAuthIntent(getIntent());
    }


    public class BillingBridge {
        @JavascriptInterface public String status() { return billingManager == null ? "{\"pro\":false,\"ready\":false}" : billingManager.statusJson(); }
        @JavascriptInterface public void buyPro() { if (billingManager != null) billingManager.buyPro(); }
        @JavascriptInterface public void buyMonthly() { if (billingManager != null) billingManager.buyMonthly(); }
        @JavascriptInterface public void buyYearly() { if (billingManager != null) billingManager.buyYearly(); }
        @JavascriptInterface public void restore() { if (billingManager != null) billingManager.restore(); }
        @JavascriptInterface public void manageSubscriptions() { if (billingManager != null) billingManager.manageSubscriptions(); }
    }

    public class VoiceBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                } else launchSpeech();
            });
        }
    }

    private void launchSpeech() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ölçünüzü söyleyin. Örneğin: dış cephe ön cephe on beşe on.");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { sendJs("window.voiceError && window.voiceError('Bu cihazda sesli giriş hizmeti bulunamadı')"); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchSpeech();
            else sendJs("window.voiceError && window.voiceError('Mikrofon izni verilmedi')");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String text = r.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                sendJs("window.handleNativeVoice && window.handleNativeVoice('" + text + "')");
            }
        } else if (requestCode == REQ_SPEECH) {
            sendJs("window.voiceError && window.voiceError('Ses alınamadı veya işlem iptal edildi. Tekrar deneyin.')");
        } else if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }



    public class TTSBridge {
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (tts == null) {
                    tts = new TextToSpeech(MainActivity.this, status -> {
                        if (status == TextToSpeech.SUCCESS) {
                            tts.setLanguage(new Locale("tr", "TR"));
                            tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "olcu_ai");
                        }
                    });
                } else {
                    tts.setLanguage(new Locale("tr", "TR"));
                    tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "olcu_ai");
                }
            });
        }
    }

    public class NativePrintBridge {
        @JavascriptInterface public void printReport(String text) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(MainActivity.this);
                WebSettingsCompat.configure(printWeb);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { alertPrintError(); return; }
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("olcu_defteri", "Ölçü Defteri", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print("Ölçü Defteri - " + activePrintTitle(), view.createPrintDocumentAdapter("Ölçü Defteri"), attrs);
                    }
                });
                String safe = text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:24px;font-size:12pt;line-height:1.5}h1{font-size:18pt}pre{white-space:pre-wrap;font-family:sans-serif}</style></head><body><h1>Ölçü Defteri</h1><pre>" + safe + "</pre></body></html>";
                printWeb.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
        private String activePrintTitle() { return "Rapor"; }
        private void alertPrintError() { sendJs("alert('Yazdırma hizmeti bu cihazda kullanılamıyor.')"); }
    }

    public class SystemBarsBridge {
        @JavascriptInterface public void setLight(boolean lightBackground) {
            runOnUiThread(() -> configureSystemBars(lightBackground));
        }
    }

    public class AuthBridge {
        @JavascriptInterface public String getSupabaseConfig() {
            try {
                InputStream in = getAssets().open("config.json");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                in.close();
                return out.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public void openExternal(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
        }

        @JavascriptInterface public void startGoogleOAuth(String supabaseUrl, String redirectUri) {
            try {
                byte[] random = new byte[32];
                new SecureRandom().nextBytes(random);
                String verifier = Base64.encodeToString(random, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                String challenge = Base64.encodeToString(md.digest(verifier.getBytes(java.nio.charset.StandardCharsets.US_ASCII)), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
                getSharedPreferences("od_auth", MODE_PRIVATE).edit().putString("pkce_verifier", verifier).apply();
                String url = supabaseUrl + "/auth/v1/authorize?provider=google&redirect_to=" + Uri.encode(redirectUri) + "&flow_type=pkce&code_challenge=" + Uri.encode(challenge) + "&code_challenge_method=S256";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                sendJs("window.authError && window.authError('Google girişi başlatılamadı.')");
            }
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleAuthIntent(intent);
    }

    private void handleAuthIntent(Intent intent) {
        Uri u=intent==null?null:intent.getData();
        if(u!=null && "olcudefteri".equalsIgnoreCase(u.getScheme()) && "auth-callback".equalsIgnoreCase(u.getHost())) {
            String callback=u.toString();
            SharedPreferences prefs=getSharedPreferences("od_auth", MODE_PRIVATE);
            String last=prefs.getString("last_auth_callback", "");
            if(callback.equals(last)) return;
            pendingAuthUri=callback;
            pendingAuthVerifier=prefs.getString("pkce_verifier", "");
            prefs.edit().putString("last_auth_callback", callback).apply();
            // The WebView performs the same PKCE exchange as Supabase's official client.
            // Keeping the verifier in the native layer avoids losing it across the browser hop.
            flushPendingAuth();
            prefs.edit().remove("pkce_verifier").apply();
        }
    }

    private void exchangeGoogleCodeNative(String code, String verifier) {
        new Thread(() -> {
            HttpURLConnection c=null;
            try {
                String cfg=readConfig();
                JSONObject config=new JSONObject(cfg);
                String base=config.optString("supabaseUrl", "");
                String key=config.optString("supabaseAnonKey", "");
                if(base.isEmpty() || key.isEmpty()) throw new Exception("Supabase bağlantısı yapılandırılmamış.");
                URL url=new URL(base+"/auth/v1/token?grant_type=pkce");
                c=(HttpURLConnection)url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setDoOutput(true);
                c.setRequestProperty("apikey", key);
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setRequestProperty("Content-Type", "application/json");
                JSONObject body=new JSONObject();
                body.put("auth_code", code);
                body.put("code_verifier", verifier);
                byte[] bytes=body.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(bytes.length);
                try(OutputStream os=c.getOutputStream()){ os.write(bytes); }
                int status=c.getResponseCode();
                InputStream in=(status>=200 && status<300)?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                if(in!=null){ byte[] buf=new byte[4096]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n); in.close(); }
                String response=out.toString("UTF-8");
                JSONObject result;
                try { result=new JSONObject(response); } catch(Exception e){ result=new JSONObject(); }
                if(status<200 || status>=300){
                    String msg=result.optString("msg", result.optString("message", result.optString("error_description", "Google giriş kodu doğrulanamadı.")));
                    throw new Exception(msg);
                }
                JSONObject payload=new JSONObject();
                payload.put("ok", true);
                payload.put("session", result);
                queueNativeGoogleResult(payload.toString());
            } catch(Exception e){
                String msg=e.getMessage()==null?"Google girişi tamamlanamadı.":e.getMessage();
                queueNativeGoogleResult("{\"ok\":false,\"error\":"+JSONObject.quote(msg)+"}");
            } finally { if(c!=null)c.disconnect(); }
        }).start();
    }

    private String readConfig() throws Exception {
        InputStream in=getAssets().open("config.json");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[4096]; int n;
        while((n=in.read(buf))!=-1) out.write(buf,0,n);
        in.close();
        return out.toString("UTF-8");
    }

    private void queueNativeGoogleResult(String payload) {
        pendingNativeGoogleResult = payload;
        flushPendingNativeGoogleResult();
    }

    private void flushPendingNativeGoogleResult() {
        if(pendingNativeGoogleResult==null || web==null) return;
        String safe=JSONObject.quote(pendingNativeGoogleResult);
        web.post(() -> web.evaluateJavascript("window.authNativeGoogleResult && window.authNativeGoogleResult("+safe+")", null));
        pendingNativeGoogleResult=null;
    }

    private void flushPendingAuth() {
        if(pendingAuthUri==null || web==null) return;
        String safe=pendingAuthUri.replace("\\","\\\\").replace("'","\\'");
        String verifier=pendingAuthVerifier==null?"":pendingAuthVerifier;
        String safeVerifier=verifier.replace("\\","\\\\").replace("'","\\'");
        String js="window.authHandleCallback && window.authHandleCallback('"+safe+"','"+safeVerifier+"')";
        web.post(() -> web.evaluateJavascript(js, null));
        pendingAuthUri=null;
        pendingAuthVerifier=null;
    }

    /**
     * Updates system-bar icon appearance for the current app background.
     * lightBackground=true => dark status/navigation icons.
     */
    private void configureSystemBars(boolean lightBackground) {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                getWindow().setNavigationBarContrastEnforced(false);
            }
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                int appearance = lightBackground
                        ? (android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                           | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS)
                        : 0;
                int mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(appearance, mask);
            }
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            if (lightBackground) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (android.os.Build.VERSION.SDK_INT >= 26 && lightBackground) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private int getStatusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : (int)(24 * getResources().getDisplayMetrics().density);
    }

    private void sendJs(String js) { if (web != null) web.post(() -> web.evaluateJavascript(js, null)); }
    @Override public void onBackPressed() {
        if (android.os.Build.VERSION.SDK_INT < 33) {
            handleSystemBack();
        } else {
            super.onBackPressed();
        }
    }

    private void loadInterstitialAd() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-5866785474078079/5027021340", request,
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                if (exitAfterInterstitial) finish();
                                else loadInterstitialAd();
                            }
                            @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                                interstitialAd = null;
                                if (exitAfterInterstitial) finish();
                                else loadInterstitialAd();
                            }
                        });
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                    }
                });
    }

    private void finishWithOptionalInterstitial() {
        if (interstitialAd != null) {
            exitAfterInterstitial = true;
            interstitialAd.show(this);
        } else {
            finish();
        }
    }

    private void handleSystemBack() {
        if (printScreenOpen) {
            printScreenOpen = false;
            if (web != null) web.post(() -> web.evaluateJavascript("window.closePrintView && window.closePrintView()", null));
            return;
        }
        if (web == null) { finishWithOptionalInterstitial(); return; }
        web.evaluateJavascript("(window.appGoBack ? window.appGoBack() : false)", value -> {
            if ("false".equals(value) || "null".equals(value)) finishWithOptionalInterstitial();
        });
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (billingManager != null) { billingManager.destroy(); billingManager = null; }
        if (bannerAdView != null) { bannerAdView.destroy(); bannerAdView = null; }
        super.onDestroy();
    }
}
