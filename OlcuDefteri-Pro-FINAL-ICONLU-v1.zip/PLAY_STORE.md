# Ölçü Defteri — Google Play Yayın Paketi

## Uygulama adı
Ölçü Defteri

## Kısa açıklama
Ustaların şantiyedeki ölçülerini hızlıca kaydetmesi, hesaplaması ve düzenlemesi için dijital ölçü defteri.

## Kategori
İş / Verimlilik

## Sürüm
1.0.0 (versionCode 1)

## Temel özellikler
- Yeni ölçü kaydı
- İş kalemi ve bölüm seçimi
- Otomatik m² / metre hesabı
- Dijital ölçü defteri görünümü
- Türkçe sesli ölçü girişi
- İnternet olmadan temel kayıt kullanımı
- Proje adı değiştirme
- Ölçüleri kopyalama

## Yayın öncesi zorunlu kontroller
- Gerçek cihazda Android 13–16 testi
- Ses izni reddedildiğinde uygulama çökme testi
- AAB release build ve imza doğrulaması
- Play Console Data Safety formu
- Herkese açık gizlilik politikası URL'si
- Uygulama ikonu ve ekran görüntüleri
- İçerik derecelendirme anketi
- Yeni kişisel Play geliştirici hesabıysa gerekli kapalı test süreci

## Yapay zekâ backend notu
Bu sürümde sesli giriş cihazın Android Speech Recognizer'ı üzerinden çalışır. Üretim LLM entegrasyonu için API anahtarı uygulamanın içine konulmayacaktır. Güvenli backend endpoint'i üzerinden AI parsing yapılmalıdır.
