package com.olcudefteri.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 701;
    private static final int REQ_SPEECH = 702;
    private WebView web;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(false);
        WebChromeClient chrome = new WebChromeClient();
        WebSettingsCompat.configure(web);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        web.setWebChromeClient(chrome);
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class VoiceBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                } else launchSpeech();
            });
        }
    }

    private void launchSpeech() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ölçünüzü söyleyin. Örneğin: dış cephe ön cephe on beşe on.");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { sendJs("window.voiceError && window.voiceError('Bu cihazda sesli giriş hizmeti bulunamadı')"); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchSpeech();
            else sendJs("window.voiceError && window.voiceError('Mikrofon izni verilmedi')");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String text = r.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                sendJs("window.handleNativeVoice && window.handleNativeVoice('" + text + "')");
            }
        } else if (requestCode == REQ_SPEECH) {
            sendJs("window.voiceError && window.voiceError('Ses alınamadı veya işlem iptal edildi. Tekrar deneyin.')");
        }
    }

    private void sendJs(String js) { if (web != null) web.post(() -> web.evaluateJavascript(js, null)); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
