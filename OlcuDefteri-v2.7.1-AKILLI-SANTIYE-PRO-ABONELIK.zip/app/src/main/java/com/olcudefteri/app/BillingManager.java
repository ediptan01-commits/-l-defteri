package com.olcudefteri.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Google Play Pro billing: one-time purchase + monthly/yearly subscription. */
public final class BillingManager {
    public static final String ONE_TIME_PRODUCT_ID = "olcu_defteri_pro";
    public static final String SUBS_PRODUCT_ID = "olcu_defteri_pro_abonelik";
    public static final String MONTHLY_BASE_PLAN_ID = "monthly";
    public static final String YEARLY_BASE_PLAN_ID = "yearly";
    private static final String PREFS = "olcu_defteri_billing";
    private static final String KEY_PRO = "pro_unlocked";

    public interface Callback {
        void onReady(String price);
        void onSubscriptionReady(String monthlyPrice, String yearlyPrice);
        void onEntitlement(boolean pro);
        void onError(String message);
    }

    private final Activity activity;
    private final Callback callback;
    private final SharedPreferences prefs;
    private BillingClient client;
    private ProductDetails oneTimeDetails;
    private ProductDetails subscriptionDetails;
    private boolean connected;
    private final Handler main = new Handler(Looper.getMainLooper());

    public BillingManager(Activity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        buildClient();
    }

    private void buildClient() {
        client = BillingClient.newBuilder(activity)
                .setListener((billingResult, purchases) -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                        processPurchases(purchases);
                    } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                        error(billingResult.getDebugMessage());
                    }
                })
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
        connect();
    }

    private void connect() {
        client.startConnection(new BillingClient.BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    error("Google Play bağlantısı kurulamadı: " + result.getDebugMessage());
                    callback.onEntitlement(prefs.getBoolean(KEY_PRO, false));
                    return;
                }
                connected = true;
                queryProducts();
                restoreInternal();
            }
            @Override public void onBillingServiceDisconnected() { connected = false; }
        });
    }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        list.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(ONE_TIME_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.INAPP)
                .build());
        list.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(SUBS_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
        client.queryProductDetailsAsync(params, (result, detailsResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                callback.onReady(""); callback.onSubscriptionReady("", ""); return;
            }
            for (ProductDetails d : detailsResult.getProductDetailsList()) {
                if (ONE_TIME_PRODUCT_ID.equals(d.getProductId())) {
                    oneTimeDetails = d;
                    String price = "";
                    List<ProductDetails.OneTimePurchaseOfferDetails> offers = d.getOneTimePurchaseOfferDetailsList();
                    if (offers != null && !offers.isEmpty()) price = offers.get(0).getFormattedPrice();
                    callback.onReady(price);
                } else if (SUBS_PRODUCT_ID.equals(d.getProductId())) {
                    subscriptionDetails = d;
                    String monthly = priceForBasePlan(d, MONTHLY_BASE_PLAN_ID);
                    String yearly = priceForBasePlan(d, YEARLY_BASE_PLAN_ID);
                    callback.onSubscriptionReady(monthly, yearly);
                }
            }
        });
    }

    private String priceForBasePlan(ProductDetails d, String basePlanId) {
        List<ProductDetails.SubscriptionOfferDetails> offers = d.getSubscriptionOfferDetails();
        if (offers == null) return "";
        for (ProductDetails.SubscriptionOfferDetails offer : offers) {
            if (!basePlanId.equals(offer.getBasePlanId())) continue;
            List<ProductDetails.PricingPhase> phases = offer.getPricingPhases().getPricingPhaseList();
            if (phases != null && !phases.isEmpty()) return phases.get(phases.size() - 1).getFormattedPrice();
        }
        return "";
    }

    private ProductDetails.SubscriptionOfferDetails offerFor(String basePlanId) {
        if (subscriptionDetails == null || subscriptionDetails.getSubscriptionOfferDetails() == null) return null;
        for (ProductDetails.SubscriptionOfferDetails offer : subscriptionDetails.getSubscriptionOfferDetails()) {
            if (basePlanId.equals(offer.getBasePlanId())) return offer;
        }
        return null;
    }

    public void buyPro() {
        if (!connected || oneTimeDetails == null) { error("Tek seferlik Pro ürünü hazır değil."); return; }
        List<ProductDetails.OneTimePurchaseOfferDetails> offers = oneTimeDetails.getOneTimePurchaseOfferDetailsList();
        if (offers == null || offers.isEmpty()) { error("Pro satın alma teklifi bulunamadı."); return; }
        launch(oneTimeDetails, offers.get(0).getOfferToken());
    }

    public void buyMonthly() { buySubscription(MONTHLY_BASE_PLAN_ID); }
    public void buyYearly() { buySubscription(YEARLY_BASE_PLAN_ID); }

    private void buySubscription(String basePlanId) {
        if (!connected || subscriptionDetails == null) { error("Abonelik ürünü henüz hazır değil. Play Console ayarlarını kontrol et."); return; }
        ProductDetails.SubscriptionOfferDetails offer = offerFor(basePlanId);
        if (offer == null) { error("Bu abonelik planı Play Console'da bulunamadı: " + basePlanId); return; }
        launch(subscriptionDetails, offer.getOfferToken());
    }

    private void launch(ProductDetails details, String offerToken) {
        List<BillingFlowParams.ProductDetailsParams> productParams = new ArrayList<>();
        productParams.add(BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)
                .setOfferToken(offerToken)
                .build());
        client.launchBillingFlow(activity, BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productParams).build());
    }

    public void restore() {
        if (!connected) { error("Google Play bağlantısı henüz hazır değil."); return; }
        restoreInternal();
    }

    private void restoreInternal() {
        QueryPurchasesParams inapp = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build();
        client.queryPurchasesAsync(inapp, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) processPurchases(purchases);
        });
        QueryPurchasesParams subs = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build();
        client.queryPurchasesAsync(subs, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) processSubscriptionPurchases(purchases);
        });
    }

    private void processPurchases(List<Purchase> purchases) {
        boolean oneTimePro = false;
        for (Purchase purchase : purchases) {
            if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) continue;
            if (!purchase.getProducts().contains(ONE_TIME_PRODUCT_ID)) continue;
            oneTimePro = true;
            acknowledge(purchase);
        }
        if (oneTimePro) prefs.edit().putBoolean(KEY_PRO, true).apply();
        callback.onEntitlement(prefs.getBoolean(KEY_PRO, false));
    }

    private void processSubscriptionPurchases(List<Purchase> purchases) {
        boolean activeSubscription = false;
        for (Purchase purchase : purchases) {
            if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) continue;
            if (!purchase.getProducts().contains(SUBS_PRODUCT_ID)) continue;
            activeSubscription = true;
            acknowledge(purchase);
        }
        if (activeSubscription) prefs.edit().putBoolean(KEY_PRO, true).apply();
        else if (!hasOneTimePurchaseCached()) prefs.edit().putBoolean(KEY_PRO, false).apply();
        callback.onEntitlement(prefs.getBoolean(KEY_PRO, false));
    }

    private boolean hasOneTimePurchaseCached() { return prefs.getBoolean(KEY_PRO, false); }

    private void acknowledge(Purchase purchase) {
        if (!purchase.isAcknowledged()) {
            client.acknowledgePurchase(
                    com.android.billingclient.api.AcknowledgePurchaseParams.newBuilder()
                            .setPurchaseToken(purchase.getPurchaseToken()).build(),
                    result -> { if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) error(result.getDebugMessage()); }
            );
        }
    }

    public void manageSubscriptions() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions"));
            activity.startActivity(i);
        } catch (Exception e) { error("Abonelik yönetimi açılamadı."); }
    }

    public String statusJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("productId", ONE_TIME_PRODUCT_ID);
            o.put("subscriptionProductId", SUBS_PRODUCT_ID);
            o.put("pro", prefs.getBoolean(KEY_PRO, false));
            o.put("connected", connected);
            o.put("ready", oneTimeDetails != null || subscriptionDetails != null);
            return o.toString();
        } catch (Exception e) { return "{\"pro\":false,\"connected\":false,\"ready\":false}"; }
    }

    public void destroy() { try { if (client != null) client.endConnection(); } catch (Exception ignored) {} }

    private void error(String msg) {
        final String safe = (msg == null || msg.trim().isEmpty()) ? "Google Play işlemi tamamlanamadı." : msg;
        main.post(() -> callback.onError(safe));
    }
}
