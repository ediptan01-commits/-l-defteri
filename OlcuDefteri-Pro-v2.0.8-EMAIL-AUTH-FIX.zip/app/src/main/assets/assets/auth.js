const AUTH_CONFIG_URL='config.json';
let authConfig={supabaseUrl:'',supabaseAnonKey:'',redirectUri:'olcudefteri://auth-callback'};
let authSession=JSON.parse(localStorage.getItem('od_auth')||'null');

async function loadAuthConfig(){
  try{
    if(window.AndroidAuth&&AndroidAuth.getSupabaseConfig){
      const raw=AndroidAuth.getSupabaseConfig();
      if(raw){authConfig=JSON.parse(raw);return;}
    }
  }catch(_){ }
  try{
    const r=await fetch(AUTH_CONFIG_URL+'?v=5',{cache:'no-store'});
    if(r.ok) authConfig=await r.json();
  }catch(_){ }
}

const authConfigured=()=>!!(authConfig.supabaseUrl&&authConfig.supabaseAnonKey&&!authConfig.supabaseUrl.includes('YOUR-PROJECT')&&!authConfig.supabaseAnonKey.includes('YOUR_SUPABASE'));
function authMsg(t,ok=false){const e=document.getElementById('authStatus');if(e){e.textContent=t;e.style.color=ok?'#166534':'';}}
function authShow(){document.querySelectorAll('main').forEach(x=>x.classList.add('hide'));const a=document.getElementById('auth');if(a)a.classList.remove('hide');renderAuth();}
function renderAuth(){const card=document.getElementById('accountCard'),email=document.getElementById('accountEmail');if(!card)return;if(authSession){card.classList.remove('hide');if(email)email.textContent=authSession.email||'';}else card.classList.add('hide');}
function saveAuthSession(s){authSession=s||null;if(s)localStorage.setItem('od_auth',JSON.stringify(s));else localStorage.removeItem('od_auth');renderAuth();}

async function supa(path,opts={}){
  if(!authConfigured())throw new Error('Hesap sistemi henüz sunucuya bağlanmadı.');
  const h=Object.assign({'apikey':authConfig.supabaseAnonKey,'Content-Type':'application/json'},opts.headers||{});
  const r=await fetch(authConfig.supabaseUrl+path,Object.assign({},opts,{headers:h}));
  const j=await r.json().catch(()=>({}));
  if(!r.ok){
    const msg=j.msg||j.message||j.error_description||j.error||`Sunucu hatası (${r.status})`;
    throw new Error(msg);
  }
  return j;
}

function validateAuthFields(){
  const email=(document.getElementById('authEmail')?.value||'').trim();
  const password=document.getElementById('authPassword')?.value||'';
  if(!email)return {error:'E-posta adresini yaz.'};
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return {error:'Geçerli bir e-posta adresi yaz.'};
  if(!password)return {error:'Şifreni yaz.'};
  if(password.length<6)return {error:'Şifre en az 6 karakter olmalı.'};
  return {email,password};
}

async function emailLogin(signup){
  const v=validateAuthFields();
  if(v.error){authMsg(v.error);return;}
  if(!authConfigured()){authMsg('Hesap sistemi hazır değil. Supabase bağlantısını kontrol ediyoruz.');return;}
  authMsg(signup?'Hesap oluşturuluyor...':'Giriş yapılıyor...');
  try{
    if(signup){
      const j=await supa('/auth/v1/signup',{
        method:'POST',
        body:JSON.stringify({email:v.email,password:v.password,options:{emailRedirectTo:authConfig.redirectUri}})
      });
      if(j.access_token){
        saveAuthSession({email:j.user?.email||v.email,access_token:j.access_token,refresh_token:j.refresh_token||'',user:j.user||null});
        authMsg('Hesap oluşturuldu ve giriş yapıldı.',true);
      }else{
        authMsg('Hesap oluşturuldu. E-postana gelen doğrulama bağlantısına dokun. Doğrulamadan sonra uygulamaya geri döneceksin.',true);
      }
    }else{
      const j=await supa('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email:v.email,password:v.password})});
      saveAuthSession({email:j.user?.email||v.email,access_token:j.access_token,refresh_token:j.refresh_token||'',user:j.user||null});
      authMsg('Giriş başarılı.',true);
    }
  }catch(e){
    const m=e?.message||'İşlem başarısız.';
    if(/invalid login credentials/i.test(m))authMsg('E-posta veya şifre yanlış.');
    else if(/email not confirmed/i.test(m))authMsg('E-posta adresini doğrulaman gerekiyor. Gelen kutunu kontrol et.');
    else if(/already registered|already exists|user already/i.test(m))authMsg('Bu e-posta zaten kayıtlı. E-POSTA İLE GİRİŞ YAP seçeneğini kullan.');
    else authMsg(m);
  }
}

async function handleEmailCallback(uri){
  try{
    const hash=uri.includes('#')?uri.split('#')[1]:'';
    const query=uri.includes('?')?uri.split('?')[1].split('#')[0]:'';
    const hp=new URLSearchParams(hash),qp=new URLSearchParams(query);
    const error=hp.get('error_description')||qp.get('error_description');
    if(error){authShow();authMsg(decodeURIComponent(error.replace(/\+/g,' ')));return true;}
    const at=hp.get('access_token'),rt=hp.get('refresh_token'),code=qp.get('code'),tokenHash=qp.get('token_hash'),type=qp.get('type');
    if(at){
      let user=null;try{user=await supa('/auth/v1/user',{headers:{'Authorization':'Bearer '+at}});}catch(_){ }
      saveAuthSession({email:user?.email||'Hesap',access_token:at,refresh_token:rt||'',user:user||null});
      authShow();authMsg('E-posta doğrulandı. Giriş başarılı.',true);return true;
    }
    if(code){
      // Email confirmation links may return a PKCE code. Exchange it if a verifier exists.
      const verifier=localStorage.getItem('od_email_pkce_verifier');
      if(verifier){
        const r=await fetch(authConfig.supabaseUrl+'/auth/v1/token?grant_type=pkce',{method:'POST',headers:{'apikey':authConfig.supabaseAnonKey,'Content-Type':'application/json'},body:JSON.stringify({auth_code:code,code_verifier:verifier})});
        const j=await r.json().catch(()=>({}));
        localStorage.removeItem('od_email_pkce_verifier');
        if(!r.ok)throw new Error(j.msg||j.message||j.error_description||'E-posta doğrulaması tamamlanamadı.');
        saveAuthSession({email:j.user?.email||'Hesap',access_token:j.access_token,refresh_token:j.refresh_token||'',user:j.user||null});
        authShow();authMsg('E-posta doğrulandı. Giriş başarılı.',true);return true;
      }
    }
    if(tokenHash&&type){
      const r=await supa('/auth/v1/verify',{method:'POST',body:JSON.stringify({token_hash:tokenHash,type})});
      if(r.access_token){saveAuthSession({email:r.user?.email||'Hesap',access_token:r.access_token,refresh_token:r.refresh_token||'',user:r.user||null});authShow();authMsg('E-posta doğrulandı. Giriş başarılı.',true);return true;}
    }
  }catch(e){authShow();authMsg(e.message||'E-posta doğrulaması tamamlanamadı.');return true;}
  return false;
}

async function syncData(){
  if(!authSession?.access_token)return authMsg('Önce giriş yap.');
  if(!authConfigured())return authMsg('Bulut yedekleme için Supabase bağlantısı gerekli.');
  try{
    await supa('/rest/v1/user_data?on_conflict=user_id',{method:'POST',headers:{'Authorization':'Bearer '+authSession.access_token,'Prefer':'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({user_id:authSession.user?.id,data:window.data||{},updated_at:new Date().toISOString()})});
    authMsg('Veriler buluta kaydedildi.',true);
  }catch(e){authMsg(e.message);}
}

function googleLogin(){
  if(!authConfigured())return authMsg('Google girişi için Supabase bağlantısı hazır değil.');
  if(window.AndroidAuth&&AndroidAuth.startGoogleOAuth){AndroidAuth.startGoogleOAuth(authConfig.supabaseUrl,authConfig.redirectUri);authMsg('Google giriş sayfası açılıyor...',true);return;}
  const u=authConfig.supabaseUrl+'/auth/v1/authorize?provider=google&redirect_to='+encodeURIComponent(authConfig.redirectUri)+'&flow_type=implicit';
  location.href=u;
}

window.authHandleCallback=async function(uri,verifier){
  try{
    const handled=await handleEmailCallback(uri);
    if(handled)return;
    const hash=uri.includes('#')?uri.split('#')[1]:'';
    const query=uri.includes('?')?uri.split('?')[1].split('#')[0]:'';
    const hp=new URLSearchParams(hash),qp=new URLSearchParams(query);
    const at=hp.get('access_token'),rt=hp.get('refresh_token'),code=qp.get('code');
    if(at){
      let user=null;try{user=await supa('/auth/v1/user',{headers:{'Authorization':'Bearer '+at}});}catch(_){ }
      saveAuthSession({email:user?.email||'Google hesabı',access_token:at,refresh_token:rt||'',user:user||null});authShow();authMsg('Google ile giriş başarılı.',true);return;
    }
    if(code&&verifier){
      authMsg('Google hesabı doğrulanıyor...');
      const r=await fetch(authConfig.supabaseUrl+'/auth/v1/token?grant_type=pkce',{method:'POST',headers:{'apikey':authConfig.supabaseAnonKey,'Content-Type':'application/json'},body:JSON.stringify({auth_code:code,code_verifier:verifier})});
      const j=await r.json().catch(()=>({}));
      if(!r.ok)throw new Error(j.msg||j.message||j.error_description||'Google giriş kodu doğrulanamadı.');
      let user=j.user||null;if(!user&&j.access_token){try{user=await supa('/auth/v1/user',{headers:{'Authorization':'Bearer '+j.access_token}});}catch(_){ }}
      saveAuthSession({email:user?.email||'Google hesabı',access_token:j.access_token,refresh_token:j.refresh_token||'',user});authShow();authMsg('Google ile giriş başarılı.',true);
    }
  }catch(e){authMsg(e.message||'Google girişi tamamlanamadı.');}
}

document.addEventListener('DOMContentLoaded',async()=>{
  await loadAuthConfig();
  const login=document.getElementById('loginBtn'),signup=document.getElementById('signupBtn'),google=document.getElementById('googleBtn');
  if(login)login.type='button'; if(signup)signup.type='button'; if(google)google.type='button';
  if(login)login.onclick=()=>emailLogin(false);
  if(signup)signup.onclick=()=>emailLogin(true);
  if(google)google.onclick=googleLogin;
  document.getElementById('guestBtn')?.addEventListener('click',()=>show('home'));
  document.getElementById('syncBtn')?.addEventListener('click',syncData);
  document.getElementById('logoutBtn')?.addEventListener('click',()=>{saveAuthSession(null);authMsg('Çıkış yapıldı.');show('home');});
  document.getElementById('accountBtn')?.addEventListener('click',authShow);
});
