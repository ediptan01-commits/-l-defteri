// Node.js regression smoke test: access without a Google Play PRO entitlement.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const app = fs.readFileSync('app/src/main/assets/assets/app.js', 'utf8');

class El {
  constructor(){
    this.value = ''; this.innerHTML = ''; this.textContent = ''; this.dataset = {};
    this.style = {}; this.children = []; this.scrollTop = 0; this.scrollHeight = 0;
    this.classList = {toggle(){},add(){},remove(){}};
    this.listeners = {};
  }
  addEventListener(name, cb){this.listeners[name] = cb;}
  append(...nodes){this.children.push(...nodes);}
  appendChild(node){this.children.push(node);return node;}
  replaceChildren(...nodes){this.children=nodes;}
  querySelector(){return new El();}
  querySelectorAll(){return [];}
  focus(){}
  click(){if(this.onclick)this.onclick();}
}
const els = {};
const get = name => (els[name] ??= new El());
const store = new Map();
const localStorage = {
  getItem(k){return store.has(k) ? store.get(k) : null},
  setItem(k,v){store.set(k,String(v))},
  removeItem(k){store.delete(k)}
};
let voiceStarts = 0;
const document = {
  readyState:'loading', body:new El(),
  getElementById:get, querySelector:()=>null, querySelectorAll:()=>[],
  createElement:()=>new El(), addEventListener(){}
};
const window = {
  addEventListener(){}, AndroidBilling:{status:()=>'{"pro":false,"ready":true}'},
  AndroidVoice:{startVoice(){voiceStarts++}},
};
const context = vm.createContext({
  window, AndroidVoice:window.AndroidVoice, AndroidBilling:window.AndroidBilling, document, localStorage, navigator:{},
  location:{href:'https://localhost/index.html'},
  history:{state:{screen:'home'}, length:1, replaceState(){}, pushState(){}, back(){}},
  setTimeout(){return 1}, clearTimeout(){},
  alert(message){throw Error('Unexpected dialog: '+message)},
  confirm(){return true}, prompt(){return ''},
  console, Date, Math, JSON,
});
vm.runInContext(app,context,{filename:'app.js'});
// Prevent unrelated layout rendering; we test the real create/save/AI handlers.
vm.runInContext('renderHome=()=>{};renderProjects=()=>{};renderBook=()=>{};show=(id)=>{window.lastScreen=id}',context);
assert.notStrictEqual(vm.runInContext('currentScreen',context),'pro', 'Free users must not be sent to a paywall on start');
for(let i=1;i<=3;i++){
  get('newProjectName').value = `Şantiye ${i}`;
  get('addProject').onclick();
}
assert.strictEqual(vm.runInContext('data.projects.length',context),3,'free project creation must be unlimited');
// Direct measurements: create three records in the current (third) project.
vm.runInContext("cat='İç Sıva';area='Salon';workItem='Kaba Sıva';",context);
for(let i=1;i<=3;i++){
  get('a').value=String(i+1);get('b').value='2';get('unit').value='m2';
  get('save').onclick();
}
assert.strictEqual(vm.runInContext('activeProject().records.length',context),3,'free measurement creation must be unlimited');
get('openAI').onclick();
assert.strictEqual(window.lastScreen,'ai','free user should be able to open AI page');
get('voice').onclick();
assert.strictEqual(voiceStarts,1,'free user should be able to start native voice recognition');
(async()=>{
  get('aiText').value = 'merhaba';
  await vm.runInContext('aiParse(false)',context);
  assert.match(get('aiResult').innerHTML,/Merhaba/i,'free AI processing must produce a response');
  get('aiText').value = 'Doğu cephe kaba sıva 12 x 10 kaydet';
  await vm.runInContext('aiParse(false)',context);
  assert.strictEqual(vm.runInContext('activeProject().records.length',context),4, 'free AI must be able to save an additional measurement');
  console.log('PASS: 3 free projects, 3 manual records, 1 AI record, AI page, native voice, text AI, no forced paywall');
})().catch(e=>{console.error(e);process.exitCode=1});
