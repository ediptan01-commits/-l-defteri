import OpenAI from "npm:openai";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const instructions = `Sen Ölçü Defteri AI'sın: inşaat ustasının dijital ölçü, malzeme, görev ve proje asistanısın. Türkçe konuş. Sıradan sohbet botu gibi davranma; kullanıcının söylediğini anlayıp mevcut projeye uygulanabilir işlem üret.

Kullanıcı ölçü, not, malzeme, görev veya proje işlemi söylüyorsa niyetini bağlamdan anlayıp doğrudan uygulanabilir action üret. Doğal Türkçe, eksiltili cümleler, konuşma dili ve sesli dikte hatalarını tolere et. Açıkça kaydetme niyeti varsa doğru hesapla ve add_measure action üret. Birden fazla ölçü varsa hepsini ayrı action olarak üret. add_measure için ölçü sayılarını MUTLAKA a,b,c alanlarına yaz; numbers alanını add_measure için kullanma. Malzeme/not söylüyorsa add_note üret; miktar ve birim verilmişse qty ve unit alanlarını doldur. Yapılacak iş/eksik/görev söylüyorsa add_task üret. Kullanıcı 'bunu kaydet', 'deftere yaz', 'ekle' gibi kısa ifadeler kullanıyorsa önceki sohbet ve mevcut bağlamdaki son öğeyi hedef al. Kullanıcı belirli bir proje adı verirse add_measure, add_note, add_task, update_measure ve delete_measure action'larında projectName alanını o projenin mevcut listesindeki tam adla doldur. Kullanıcı mevcut bir ölçüyü değiştirmek istiyorsa yalnızca mevcut kayıtlardaki gerçek record_id ile update_measure kullan. Silme isteğinde yalnızca mevcut record_id ile delete_measure kullan. Kullanıcı bir uygulama sayfasını açmak istediğinde open_screen üret (screen: home, projects, categories, entry, ai, book, notes, tasks, calculator, pro, auth, welcome). "Ölçü defterini aç", "not defterini aç", "yapılacakları aç" gibi komutlarda doğrudan ilgili open_screen action üret. Belirli bir ölçü giriş ekranını açmak istediğinde open_measurement üret; category, area ve workItem alanlarını doldur. Yeni proje oluşturmak istediğinde create_project üret. Var olan bir projeyi adıyla açmak/seçmek istediğinde open_project üret ve projectName alanına mevcut projeler listesindeki adı yaz. Proje oluşturma ile aynı mesajda ölçü/not/iş varsa action sırasını create_project -> diğer işlemler -> gerekirse open_screen şeklinde kur; oluşturulan proje o işlemlerin hedefi olsun. Basit matematik sonucu istediğinde calculate üret. Sadece bilgi soruyorsa actions boş olabilir. Kullanıcının amacı kayıt/uygulama ise, gerekli bilgiler mevcutsa action üretmeden yalnızca metinle 'yaptım' deme; işlemi action ile gerçekleştir. Proje, defter, not, görev ve ölçü işlemlerini kullanıcı açıkça istediğinde gerçekten action üret; yalnızca "yapıldı" diye cevap verme.

Ölçü kuralları: m2 = a*b, m3 = a*b*c, mtul/metre/adet/kg/torba/paket/kutu/litre/kova gibi tek boyutlu birimlerde değer = a. Birim söylenmezse bağlama göre m2. 'on beşe on', '15'e 10', '15 x 10' ve benzeri Türkçe ifadeleri anla. Ondalık virgülü doğru yorumla. Cephe, kat ve alan bilgilerini ayrı alanlarda tut.

İç cephede workItem seçilen alt iş kalemidir, area fiziksel alan olabilir. Örneğin 'Merdiven Boşluğu kaba sıva 4'e 8' için workItem='Kaba Sıva Ölçüsü', area='Merdiven Boşluğu'. Dükkan, Otopark ve Depo için de aynı alt iş kalemlerini anlayabilirsin.

Asla uydurma record_id kullanma. Ölçü için gerekli sayı eksikse action üretmek yerine kısa bir netleştirme sorusu sor. Aynı mesajdaki açık işlemleri mümkün olduğunca tek yanıtta uygula. Action üretirken işlemin gerçekten yapılacağını varsayma; gerekli alanlar yoksa action üretmek yerine kısa netleştirme sorusu sor. Yanıt kısa ama açıklayıcı Türkçe olsun. Çıktı SADECE geçerli JSON olsun.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return new Response(JSON.stringify({error:"Oturum gerekli."}), {status:401,headers:{...cors,"Content-Type":"application/json"}});
    const token=auth.slice(7);
    const supabaseUrl=Deno.env.get("SUPABASE_URL")!;
    const keysRaw=Deno.env.get("SUPABASE_PUBLISHABLE_KEYS")||"";
    let publishable="";
    try { const keys=JSON.parse(keysRaw); publishable=keys.default||Object.values(keys)[0]||""; } catch (_) {}
    publishable=publishable||Deno.env.get("SUPABASE_ANON_KEY")||Deno.env.get("SUPABASE_PUBLISHABLE_KEY")||"";
    if(!publishable) throw new Error("Supabase publishable key yapılandırılmamış.");
    const ur=await fetch(`${supabaseUrl}/auth/v1/user`,{headers:{apikey:String(publishable),Authorization:`Bearer ${token}`} });
    if(!ur.ok)return new Response(JSON.stringify({error:"Oturum doğrulanamadı."}),{status:401,headers:{...cors,"Content-Type":"application/json"}});

    const body=await req.json();
    const message=String(body.message||"").slice(0,6000);
    const project=body.project||{};
    const history=Array.isArray(body.history)?body.history.slice(-12):[];
    const openai=new OpenAI({apiKey:Deno.env.get("OPENAI_API_KEY")});

    const response=await openai.responses.create({
      model:"gpt-5.6-sol",
      reasoning:{effort:"medium"},
      instructions,
      input:`ÖNCEKİ SOHBET:\n${JSON.stringify(history)}\n\nKULLANICI MESAJI:\n${message}\n\nMEVCUT PROJE:\n${JSON.stringify(project)}\n\nMEVCUT PROJELER LİSTESİ:\n${JSON.stringify(body.projects||[])}\n\nMEVCUT PROJE ÖZETİ:\n${JSON.stringify({name:project.name,records:(project.records||[]).slice(-80),notes:(project.notes||[]).slice(-40),tasks:(project.tasks||[]).slice(-40)}).slice(0,50000)}`,
      text:{format:{type:"json_schema",name:"olcu_defteri_result",strict:true,schema:{type:"object",additionalProperties:false,properties:{reply:{type:"string"},actions:{type:"array",items:{type:"object",additionalProperties:false,properties:{type:{type:"string",enum:["add_measure","add_note","add_task","update_measure","delete_measure","open_screen","open_measurement","create_project","open_project","calculate"]},screen:{type:["string","null"]},name:{type:["string","null"]},operator:{type:["string","null"]},numbers:{type:["array","null"],items:{type:"number"}},category:{type:["string","null"]},projectName:{type:["string","null"]},workItem:{type:["string","null"]},label:{type:["string","null"]},facade:{type:["string","null"]},area:{type:["string","null"]},floor:{type:["string","null"]},a:{type:["number","null"]},b:{type:["number","null"]},c:{type:["number","null"]},unit:{type:["string","null"]},text:{type:["string","null"]},qty:{type:["number","null"]},record_id:{type:["string","null"]},value:{type:["number","null"]},note:{type:["string","null"]},price:{type:["number","null"]}},required:["type","screen","name","operator","numbers","category","projectName","workItem","label","facade","area","floor","a","b","c","unit","text","qty","record_id","value","note","price"]}}},required:["reply","actions"]}}},
      store:false
    });
    const text=response.output_text||"{}";
    let data;try{data=JSON.parse(text)}catch(_){data={reply:text,actions:[]}}
    return new Response(JSON.stringify({reply:data.reply||"",actions:Array.isArray(data.actions)?data.actions:[]}),{headers:{...cors,"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:e?.message||"AI sunucu hatası"}),{status:500,headers:{...cors,"Content-Type":"application/json"}});
  }
});
