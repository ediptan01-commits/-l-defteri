# Ölçü Defteri Gizlilik Politikası — Taslak
Son güncelleme: 14 Eylül 2026

Ölçü Defteri, temel ölçü kayıtlarını cihaz üzerinde saklayabilir. Temel sürümde ölçü kayıtları uygulamanın yerel depolamasında tutulur.

Sesli giriş kullanıldığında Android'in konuşma tanıma özelliği devreye girebilir. Konuşma tanıma hizmetinin veri işleme koşulları ilgili hizmet sağlayıcısının politikalarına tabidir.

Sunucu tarafı yapay zekâ özelliği etkinleştirildiğinde, gerekli metin verileri seçilen AI hizmetine gönderilebilir. Bu özellik yayınlanmadan önce veri akışı, saklama süresi ve üçüncü taraf servisleri bu metinde açıkça belirtilmelidir.

Bu taslak, yayın öncesinde gerçek veri sorumlusu, şirket/unvan, iletişim ve üçüncü taraf hizmet bilgileriyle tamamlanmalıdır.
