# Ölçü Defteri – Test Sürümü

Android 16 / API 36 hedefli test projesidir.

Önemli: Bu paket kaynak projedir. Bu çalışma ortamında Android SDK bulunmadığından APK burada derlenip doğrulanamamıştır. Android Studio/AndroidIDE ile `assembleDebug` çalıştırılarak test APK'sı oluşturulabilir.

Uygulama akışı: Proje → İş kalemi → Bölüm → Ölçü → otomatik m² hesabı. Sesli giriş Android'in Türkçe konuşma tanıma servisini kullanır.


## v1.2.0
Proje bazlı not/malzeme defteri eklendi. Malzeme adı/not, isteğe bağlı miktar ve birim kaydedilebilir; ölçü defterinde ve kopyalanan raporda görünür.


V12: Dekoratif Boya içine Dış Cephe alt bölümü ve Laminat Parke iş kalemi eklendi.


## Final Pro 2.0
Kat bazlı metraj, m²/mt/m³/adet, gelişmiş defter, malzeme/not/iş takibi, fotoğraf, teklif/hakediş, paylaşım ve JSON yedekleme içerir. Gerçek bulut ve sunucu tabanlı LLM bağlantısı ayrıca kurulmalıdır; APK içine API anahtarı gömülmez.
