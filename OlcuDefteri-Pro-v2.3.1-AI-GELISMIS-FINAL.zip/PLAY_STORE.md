# Ölçü Defteri — Google Play Yayın Paketi v2.2.0

## Uygulama
- Ad: Ölçü Defteri
- Paket: com.olcudefteri.app
- Sürüm: 2.2.0 (versionCode 32)
- Hedef API: Android 16 / API 36
- Kategori: İş / Verimlilik

## Mağaza metni
Kısa açıklama: İnşaat ölçülerini, projelerini, notlarını ve işlerini tek yerde yönetin.

Uzun açıklama: Ölçü Defteri, ustaların ve şantiye ekiplerinin ölçüleri hızlıca kaydetmesi, hesaplaması, projelere ayırması ve dijital defter şeklinde takip etmesi için tasarlanmıştır. m², m³, metre, metretül ve adet ölçüleri; proje, not, malzeme ve yapılacak işler ile birlikte yönetilebilir. Google ile giriş ve bulut senkronizasyonu desteklenir. Yapay zekâ ile doğal dil üzerinden ölçü ve iş komutları kullanılabilir.

## Yayın öncesi
- Release AAB oluşturulacak: app-release.aab
- Play App Signing etkinleştirilecek.
- Veri Güvenliği formu gerçek veri akışına göre doldurulacak.
- Gizlilik politikası herkese açık URL'de yayınlanacak.
- Hesap oluşturan kullanıcı için uygulama içi ve harici hesap silme yolu hazır olacak.
- İçerik derecelendirme anketi tamamlanacak.
- Hedef kitle ve içerik beyanları tamamlanacak.
- Mağaza simgesi: 512x512 PNG.
- Özellik grafiği: 1024x500 JPEG/24-bit PNG.
- En az 2 telefon ekran görüntüsü; 8'e kadar yüklenebilir.
- Android 13–16 gerçek cihaz testi yapılacak.
- Google hesabı ile giriş, AI, sesli giriş/yanıt, proje seçimi, ölçü kaydı, yedekleme ve geri dönüş test edilecek.
- Yeni kişisel Play geliştirici hesabı 13 Kasım 2023 sonrası açıldıysa, üretim erişimi için en az 12 test kullanıcısıyla 14 gün kapalı test yapılmalı.

## Önemli
Google Play'in 31 Ağustos 2026 itibarıyla yeni uygulamalarda Android 16/API 36 veya üstü hedefleme şartı vardır; bu proje targetSdk 36 kullanır.
