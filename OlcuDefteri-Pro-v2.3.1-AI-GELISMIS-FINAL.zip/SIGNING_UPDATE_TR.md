# Uygulama güncelleme sorunu – kalıcı imza

Eski GitHub Actions derlemeleri `assembleDebug` ile oluşturulduğu için her çalıştırmada farklı CI debug imzası oluşabiliyordu. Bu nedenle yeni APK, telefondaki eski APK'nın üzerine güncellenemiyordu.

Bu sürüm `assembleRelease` kullanır ve sabit bir release keystore ile imzalanır. v2.1.0 kurulduktan sonra aynı keystore ile üretilen sonraki sürümler (v2.1.1, v2.1.2...) silmeden güncellenebilir.

GitHub Secrets:
- ANDROID_KEYSTORE_BASE64
- ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS
- ANDROID_KEY_PASSWORD

Önemli: keystore dosyasını veya şifrelerini repository'ye koymayın.
