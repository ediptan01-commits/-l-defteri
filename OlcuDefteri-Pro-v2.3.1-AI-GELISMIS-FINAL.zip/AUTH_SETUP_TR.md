# Gerçek Hesap Sistemi Kurulumu

Bu sürüm uygulama tarafındaki e-posta/şifre, Google OAuth ve bulut senkronizasyonunu hazırlar. Gerçek sunucu hesabı için bir Supabase projesi gerekir.

## 1) Supabase
- Yeni proje oluştur.
- Project URL ve anon/public key değerlerini `app/src/main/assets/config.json` içine yaz.
- Authentication > Providers bölümünde Email etkin olsun.
- Google kullanacaksan Google provider'ı etkinleştir ve Google Cloud OAuth bilgilerini bağla.
- Authentication > URL Configuration > Redirect URLs kısmına `olcudefteri://auth-callback` ekle.

## 2) Veri tablosu
SQL Editor'da çalıştır:

```sql
create table if not exists public.user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_data enable row level security;
create policy "users can read own data" on public.user_data for select using (auth.uid() = user_id);
create policy "users can insert own data" on public.user_data for insert with check (auth.uid() = user_id);
create policy "users can update own data" on public.user_data for update using (auth.uid() = user_id);
```

> Not: `config.json` içine service_role key koyma. Sadece anon/public key kullanılmalıdır.

## 3) AI ve hesap silme Edge Functions
`supabase/functions/olcu-ai` ve `supabase/functions/delete-account` kaynakları projede hazırdır. Canlı Supabase projesinde Edge Functions olarak dağıtılmalıdır.

AI fonksiyonunun Supabase Secrets bölümünde en az:
- `OPENAI_API_KEY`
- `SUPABASE_PUBLISHABLE_KEYS`

Hesap silme fonksiyonu için:
- `SUPABASE_SERVICE_ROLE_KEY`

gerekir. Service role anahtarını APK'ya veya GitHub'a koyma; yalnızca Supabase sunucu secrets alanında tut.

GitHub Actions ile otomatik dağıtım için GitHub Secrets:
- `SUPABASE_ACCESS_TOKEN`
- `SUPABASE_PROJECT_ID`

eklenebilir. `.github/workflows/deploy-supabase.yml` dosyası bu iki secret ile Edge Functions'ı `--use-api` üzerinden dağıtır.
