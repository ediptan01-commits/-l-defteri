# Ölçü Defteri uses a local WebView shell; no custom keep rules are required.
