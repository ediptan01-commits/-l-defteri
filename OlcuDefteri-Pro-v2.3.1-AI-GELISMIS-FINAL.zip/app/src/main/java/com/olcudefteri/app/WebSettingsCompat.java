package com.olcudefteri.app;
import android.webkit.WebSettings;
import android.webkit.WebView;
final class WebSettingsCompat {
  static void configure(WebView w) {
    WebSettings s=w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false);
    s.setMediaPlaybackRequiresUserGesture(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
  }
}
