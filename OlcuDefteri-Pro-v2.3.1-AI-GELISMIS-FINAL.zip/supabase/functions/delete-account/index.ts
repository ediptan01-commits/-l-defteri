const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 if(req.method!=='POST')return new Response(JSON.stringify({error:'Method not allowed'}),{status:405,headers:{...cors,'Content-Type':'application/json'}});
 const auth=req.headers.get('Authorization')||''; if(!auth.startsWith('Bearer '))return new Response(JSON.stringify({error:'Oturum gerekli.'}),{status:401,headers:{...cors,'Content-Type':'application/json'}});
 const token=auth.slice(7),url=Deno.env.get('SUPABASE_URL'),service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!service)return new Response(JSON.stringify({error:'Hesap silme sunucu ayarı eksik.'}),{status:500,headers:{...cors,'Content-Type':'application/json'}});
 const userRes=await fetch(`${url}/auth/v1/user`,{headers:{apikey:service,Authorization:`Bearer ${token}`}});
 const user=await userRes.json().catch(()=>({})); if(!userRes.ok||!user.id)return new Response(JSON.stringify({error:'Oturum doğrulanamadı.'}),{status:401,headers:{...cors,'Content-Type':'application/json'}});
 await fetch(`${url}/rest/v1/user_data?user_id=eq.${encodeURIComponent(user.id)}`,{method:'DELETE',headers:{apikey:service,Authorization:`Bearer ${service}`}});
 const del=await fetch(`${url}/auth/v1/admin/users/${user.id}`,{method:'DELETE',headers:{apikey:service,Authorization:`Bearer ${service}`}});
 if(!del.ok){const t=await del.text();return new Response(JSON.stringify({error:'Hesap silinemedi.',details:t}),{status:502,headers:{...cors,'Content-Type':'application/json'}})}
 return new Response(JSON.stringify({ok:true}),{headers:{...cors,'Content-Type':'application/json'}});
});
