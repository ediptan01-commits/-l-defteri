# WebView JavaScript bridges are discovered by the @JavascriptInterface annotation.
# Keep the annotated methods and their runtime annotations when R8 is enabled.
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}