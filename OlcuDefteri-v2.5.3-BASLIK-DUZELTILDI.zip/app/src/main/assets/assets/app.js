try{ if(window.AndroidSystemBars) AndroidSystemBars.setLight(true); }catch(e){}
const $=id=>document.getElementById(id);
const areas={"Dış Cephe":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],"Alçıpan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Işık Bandı","Soffit","Kolon","Kiriş","Diğer"],"Duvar":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],"İç Sıva":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Diğer"],"Alçı Sıva":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","Duvar","Tavan","Kolon","Kiriş","Diğer"],"Saten Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Tavan","Kapılar","Diğer"],"Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Tavan","Kapılar","Diğer"],"Dekoratif Boya":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Merdiven","TV Ünitesi","Niş","Sütun / Kolon","Tavan","Duvar","Dış Cephe","Diğer"],"Laminat Parke":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Koridor","Antre","Ofis","Mağaza","Merdiven","Diğer"],"Tavan":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Antre","Diğer"],"Mantolama":["Ön Cephe","Arka Cephe","Sağ Yan Cephe","Sol Yan Cephe","Kör Cephe","Doğu Cephe","Batı Cephe","Kuzey Cephe","Güney Cephe"],"Seramik":["Banyo Zemin","Banyo Duvar","WC Zemin","WC Duvar","Mutfak","Balkon","Teras","Diğer"],"Şap":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","Koridor","Balkon","Teras","Diğer"],"Işık Bandı":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Koridor","Merdiven","Diğer"],"Fuga / Söve":["Ön Cephe","Arka Cephe","Sağ Cephe","Sol Cephe","Kör Cephe","Pencere Çevresi","Kapı Çevresi","Diğer"],"Süpürgelik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Koridor","Antre","Diğer"],"Kapı / Pencere":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Balkon","Diğer"],"Elektrik":["Salon","Mutfak","Yatak Odası","Çocuk Odası","Misafir Odası","Banyo","WC","Koridor","Dış Cephe","Pano","Diğer"],"Sıhhi Tesisat":["Banyo","WC","Mutfak","Çamaşır Alanı","Bahçe","Diğer"],"Çatı":["Ana Çatı","Teras Çatı","Saçak","Oluk","Dere","Diğer"]};
function emptyData(){return{activeId:null,projects:[]}}
function normalizeData(raw){try{if(raw?.projects){raw.projects.forEach(p=>{p.records??=[];p.notes??=[];p.tasks??=[];p.photos??=[]});if(raw.projects.length===1&&raw.projects[0].name==='A İnşaat'&&!raw.projects[0].records.length&&!raw.projects[0].notes.length&&!raw.projects[0].tasks.length&&!raw.projects[0].photos.length)return emptyData();raw.activeId=raw.projects.some(p=>p.id===raw.activeId)?raw.activeId:(raw.projects[0]?.id||null);return raw}if(raw?.records){let p={id:'p_'+Date.now(),name:raw.project||'A İnşaat',records:raw.records,notes:[],tasks:[],photos:[]};return{activeId:p.id,projects:[p]}}}catch(e){}return emptyData()}
function currentAccountId(){try{return window.authSession?.user?.id||window.authSession?.user_id||''}catch(_){return ''}}
function dataStorageKey(uid=currentAccountId()){return uid?'od5_user_'+uid:'od5_guest'}
function loadDataFor(uid=currentAccountId()){const key=dataStorageKey(uid);try{let raw=JSON.parse(localStorage.getItem(key)||'null');if(raw)return normalizeData(raw);if(uid&&!localStorage.getItem('od5_migrated_'+uid)){const legacy=localStorage.getItem('od5');if(legacy){const migrated=normalizeData(JSON.parse(legacy));localStorage.setItem(key,JSON.stringify(migrated));localStorage.setItem('od5_migrated_'+uid,'1');localStorage.removeItem('od5');return migrated}}}catch(_){ }return emptyData()}
let data=loadDataFor(),cat='',area='',workItem='',selectedFacade='';
window.switchLocalAccount=function(uid){clearTimeout(syncTimer);data=loadDataFor(uid||'');if(!data.projects.length&&uid&&typeof window.restoreCloudDataIfNeeded==='function')setTimeout(()=>window.restoreCloudDataIfNeeded(),80);renderHome();renderProjects();};
const FACADE_OPTIONS=['Ön Cephe','Arka Cephe','Sağ Yan Cephe','Sol Yan Cephe','Kör Cephe','Doğu Cephe','Batı Cephe','Kuzey Cephe','Güney Cephe'];
const INTERIOR_AREAS=['Oturma Odası','Çocuk Odası','Misafir Odası','Yatak Odası','Mutfak','Koridor','Banyo','Tuvalet','Merdiven Boşluğu','Dükkan','Otopark','Depo'];window.getAppData=()=>data;window.setAppData=(d)=>{if(d&&Array.isArray(d.projects)){try{data=normalizeData(d);localStorage.setItem(dataStorageKey(),JSON.stringify(data));renderHome();renderProjects();}catch(e){console.warn('Veri uygulanamadı',e);}}};
const floors=['Zemin Kat',...Array.from({length:30},(_,i)=>`${i+1}. Kat`),'Çatı Katı'];
const activeProject=()=>data.projects.find(p=>p.id===data.activeId)||null;
const requireProject=()=>{let p=activeProject();if(!p){alert('Önce bir proje oluşturup aktif hale getir.');show('projects');return null}return p};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let syncTimer=null;
function save(){
  try{
    const key=dataStorageKey();
    const payload=JSON.stringify(data);
    localStorage.setItem(key,payload);
    // Android WebView'da yazma işlemini doğrula; AI kaydı sessizce kaybolmasın.
    const check=localStorage.getItem(key);
    if(check!==payload)throw new Error('yerel kayıt doğrulanamadı');
  }catch(e){alert('Ölçü cihazda kaydedilemedi: '+(e.message||'depolama hatası'));return false;}
  renderHome();renderProjects();
  if(window.authSession?.access_token&&typeof window.syncData==='function'){
    clearTimeout(syncTimer);
    syncTimer=setTimeout(()=>window.syncData(false),700);
  }
  return true;
}
function persistAIRecord(project,rec){
  if(!project||!rec)return false;
  project.records??=[];
  project.records.push(rec);
  if(!save()){project.records.pop();return false;}
  return true;
}
let currentScreen='home';
if(!history.state?.screen){try{history.replaceState({screen:'home'},'',location.href.split('#')[0]+'#home')}catch(_){}}
function show(id,push=true){
  ['home','projects','categories','areas','entry','ai','book','notes','tasks','calculator','pro','auth','welcome'].forEach(x=>{let el=$(x);if(el)el.classList.toggle('hide',x!==id)});
  document.body.classList.toggle('welcome-mode',id==='welcome');
  if(id==='book')renderBook();if(id==='notes')renderNotes();if(id==='tasks')renderTasks();if(id==='projects')renderProjects();if(id==='home')renderHome();
  if(push && id!==currentScreen){history.pushState({screen:id},'', '#'+id);} currentScreen=id;
}
window.addEventListener('popstate',e=>{const target=e.state?.screen||'home';show(target,false)});
window.appGoBack=function(){
  if(currentScreen==='home'||currentScreen==='welcome')return false;
  if(history.state?.screen===currentScreen && history.length>1){history.back();return true;}
  const backMap={projects:'home',categories:'home',areas:'categories',entry:'categories',ai:'home',book:'home',notes:'home',tasks:'home',calculator:'home',pro:'home',auth:'welcome'};
  const target=backMap[currentScreen]||'home';
  try{history.replaceState({screen:target},'', '#'+target);}catch(_){}
  show(target,false);
  return true;
};
function tile(t,s,fn){let b=document.createElement('button');b.className='tile';b.innerHTML=`${esc(t)}<small>${s}</small>`;b.onclick=fn;return b}
const measurementMenu={
  "Dış Cephe":[
    {label:"Kaba Sıva Ölçüsü",area:"Kaba Sıva"},
    {label:"İnce Sıva Ölçüsü",area:"İnce Sıva"},
    {label:"Mantolama Ölçüsü",area:"Mantolama"},
    {label:"Dekoratif Boya Ölçüsü",area:"Dekoratif Boya"},
    {label:"Bordex Ölçüsü",area:"Bordex"},
    {label:"Kompozit Kaplama Ölçüsü",area:"Kompozit Kaplama"},
    {label:"Panel Kaplama Ölçüsü",area:"Panel Kaplama"},
    {label:"Taş Kaplama Ölçüsü",area:"Taş Kaplama"}
  ],
  "İç Cephe":[
    {label:"Duvar Ölçüsü",area:"Duvar"},
    {label:"Kaba Sıva Ölçüsü",area:"Kaba Sıva"},
    {label:"İnce Sıva Ölçüsü",area:"İnce Sıva"},
    {label:"Alçı Sıva Ölçüsü",area:"Alçı Sıva"},
    {label:"Alçıpan Ölçüsü",children:[
      {label:"Işık Bandı",area:"Işık Bandı"},
      {label:"Asma Tavan",area:"Asma Tavan"},
      {label:"Göbek",area:"Göbek"},
      {label:"Boru Kaplama",area:"Boru Kaplama"}
    ]},
    {label:"Saten Boya Ölçüsü",area:"Saten Boya"},
    {label:"Seramik Ölçüsü",children:[
      {label:"Duvar Fayans",area:"Duvar Fayans"},
      {label:"Yer Döşeme",area:"Yer Döşeme"},
      {label:"Süpürgelik",area:"Süpürgelik"}
    ]},
    {label:"Şap Ölçüsü",area:"Şap"},
    {label:"Laminat Parke Ölçüsü",children:[
      {label:"Laminat Parke",area:"Laminat Parke"},
      {label:"Süpürgelik",area:"Süpürgelik"}
    ]},
    {label:"Merdiven",children:[
      {label:"Basamak",area:"Basamak"},
      {label:"Yer Döşeme",area:"Yer Döşeme"},
      {label:"Süpürgelik",area:"Süpürgelik"}
    ]},
    {label:"Merdiven Boşluğu",children:[{label:"Kaba Sıva Ölçüsü",area:"Merdiven Boşluğu"},{label:"İnce Sıva Ölçüsü",area:"Merdiven Boşluğu"},{label:"Saten Boya Ölçüsü",area:"Merdiven Boşluğu"},{label:"Dekoratif Boya Ölçüsü",area:"Merdiven Boşluğu"}]},
    {label:"Dükkan",children:[{label:"Kaba Sıva Ölçüsü",area:"Dükkan"},{label:"İnce Sıva Ölçüsü",area:"Dükkan"},{label:"Saten Boya Ölçüsü",area:"Dükkan"},{label:"Dekoratif Boya Ölçüsü",area:"Dükkan"}]},
    {label:"Otopark",children:[{label:"Kaba Sıva Ölçüsü",area:"Otopark"},{label:"İnce Sıva Ölçüsü",area:"Otopark"},{label:"Saten Boya Ölçüsü",area:"Otopark"},{label:"Dekoratif Boya Ölçüsü",area:"Otopark"}]},
    {label:"Depo",children:[{label:"Kaba Sıva Ölçüsü",area:"Depo"},{label:"İnce Sıva Ölçüsü",area:"Depo"},{label:"Saten Boya Ölçüsü",area:"Depo"},{label:"Dekoratif Boya Ölçüsü",area:"Depo"}]}
  ]
};
let openMeasureGroup='';
let openMeasureSub='';
function openMeasurement(category,itemArea,label,facade=''){
  cat=category; area=itemArea; workItem=label; selectedFacade=facade||'';
  const isInterior=category==='İç Cephe';
  $('entryCat').textContent='YENİ ÖLÇÜ';
  $('entryArea').textContent=`${category} - ${label}`;
  $('workItemWrap').textContent=category==='Dış Cephe'
    ? ('Cephe: '+(selectedFacade||'Seçilmedi'))
    : '';

  $('areaWrap').classList.toggle('hide',!isInterior);
  $('facadeWrap').classList.toggle('hide',category!=='Dış Cephe');
  // Dış cephede kat seçimi yok; iç cephede kat seçimi devam eder.
  $('floorWrap').classList.toggle('hide',category==='Dış Cephe');

  const sel=$('areaSelect');
  if(isInterior){
    sel.innerHTML='<option value="">Alan seçilmedi</option>'+INTERIOR_AREAS.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
  }

  const fs=$('facadeSelect');
  if(fs){
    fs.innerHTML='<option value="">Cephe seçilmedi</option>'+FACADE_OPTIONS.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
    fs.value=selectedFacade||'';
    fs.onchange=()=>{
      selectedFacade=fs.value||'';
      $('workItemWrap').textContent=category==='Dış Cephe'
        ? ('Cephe: '+(selectedFacade||'Seçilmedi'))
        : '';
    };
  }

  clearEntry();
  if(isInterior && itemArea && INTERIOR_AREAS.includes(itemArea)) sel.value=itemArea;
  if(fs) fs.value=selectedFacade||'';
  show('entry');
}
function renderCats(){
  const g=$('cats'); g.innerHTML='';
  Object.entries(measurementMenu).forEach(([group,items])=>{
    const wrap=document.createElement('section'); wrap.className='measureGroup '+(openMeasureGroup===group?'open':'');
    const btn=document.createElement('button');
    btn.className='measureGroupBtn';
    btn.innerHTML=`<span>${esc(group)}</span><b>${openMeasureGroup===group?'−':'+'}</b>`;
    btn.onclick=()=>{openMeasureGroup=openMeasureGroup===group?'':group;openMeasureSub='';renderCats()};
    wrap.append(btn);

    if(openMeasureGroup===group){
      const list=document.createElement('div'); list.className='measureItems';
      items.forEach(item=>{
        const row=document.createElement('div');
        if(item.children){
          row.className='measureParent '+(openMeasureSub===item.label?'open':'');
          const parentBtn=document.createElement('button');
          parentBtn.className='measureItem parentBtn';
          parentBtn.innerHTML=`<span>${esc(item.label)}</span><b>${openMeasureSub===item.label?'−':'+'}</b>`;
          parentBtn.onclick=()=>{openMeasureSub=openMeasureSub===item.label?'':item.label;renderCats()};
          row.append(parentBtn);

          if(openMeasureSub===item.label){
            const sub=document.createElement('div'); sub.className='subItems';
            item.children.forEach(child=>{
              const cb=document.createElement('button');
              cb.className='measureItem subItem';
              cb.innerHTML=`<span>${esc(child.label)}</span>`;
              cb.onclick=()=>openMeasurement(group,child.area,child.label);
              sub.append(cb);
            });
            row.append(sub);
          }
        }else{
          row.className='measureParent';
          const ib=document.createElement('button');
          ib.className='measureItem';
          ib.innerHTML=`<span>${esc(item.label)}</span>`;
          ib.onclick=()=>openMeasurement(group,item.area,item.label);
          row.append(ib);
        }
        list.append(row);
      });
      wrap.append(list);
    }
    g.append(wrap);
  });
}
function clearEntry(){$('a').value='';$('b').value='';$('c').value='';if($('floor'))$('floor').value='';if($('areaSelect'))$('areaSelect').value='';if($('facadeSelect'))$('facadeSelect').value=selectedFacade||'';$('note').value='';$('price').value='';updateCalc()}
function parseNum(v){return parseFloat(String(v??'').replace(',','.'))||0}
function updateCalc(){
  let a=parseNum($('a').value),b=parseNum($('b').value),c=parseNum($('c').value),u=$('unit').value;
  $('cWrap').classList.toggle('hide',u!=='m3');
  $('b').classList.toggle('hide',u==='mtul'||u==='metre'||u==='adet');
  const bLabel=document.querySelector('#entry .measure b'); if(bLabel) bLabel.classList.toggle('hide',u==='mtul'||u==='metre'||u==='adet');
  let v=u==='m2'?a*b:u==='m3'?a*b*c:(u==='mtul'||u==='metre'||u==='adet')?a:a;
  let label=fmtUnit(u);
  $('calc').textContent=u==='m3'?`${a} × ${b} × ${c} = ${Number(v.toFixed(2))} ${label}`:u==='m2'?`${a} × ${b} = ${Number(v.toFixed(2))} ${label}`:`${a} = ${Number(v.toFixed(2))} ${label}`;
}
['a','b','c'].forEach(id=>$(id)?.addEventListener('input',updateCalc));
$('unit').addEventListener('change',updateCalc);
function clearEntry(){$('a').value='';$('b').value='';$('c').value='';$('floor').value='';if($('areaSelect'))$('areaSelect').value='';if($('facadeSelect'))$('facadeSelect').value=selectedFacade||'';$('note').value='';$('price').value='';$('unit').value='m2';updateCalc()}
$('save').onclick=()=>{
  let p=requireProject();if(!p)return;
  let a=parseNum($('a').value),b=parseNum($('b').value),c=parseNum($('c').value),u=$('unit').value;
  if(a<=0)return alert('Ölçü gir.');
  if((u==='m2'&&b<=0)||(u==='m3'&&(b<=0||c<=0)))return alert(u==='m3'?'Metreküp için 3 ölçüyü de gir.':'İkinci ölçüyü gir.');
  let v=u==='m2'?a*b:u==='m3'?a*b*c:(u==='mtul'||u==='metre'||u==='adet')?a:a;
  let finalArea=cat==='İç Cephe'?($('areaSelect').value||''):area;
if(cat==='İç Cephe'&&!finalArea)return alert('Önce Alan seç.');
const chosenFacade=cat==='Dış Cephe'?($('facadeSelect')?.value||selectedFacade||''):'';
if(cat==='Dış Cephe'&&!chosenFacade)return alert('Önce cephe seç.');
selectedFacade=chosenFacade;
let rec={id:'r_'+Date.now()+'_'+Math.random().toString(36).slice(2),cat,area:cat==='Dış Cephe'?'Dış Cephe':(finalArea||area),workItem:workItem||'',floor:cat==='Dış Cephe'?'':($('floor').value||''),facade:chosenFacade,a,b,c,unit:u,value:+v.toFixed(2),note:$('note').value.trim(),price:parseNum($('price').value),createdAt:new Date().toISOString()};
  if(window.editingRecordId){let ix=p.records.findIndex(x=>x.id===window.editingRecordId);if(ix>=0)rec.id=p.records[ix].id,p.records[ix]=rec;window.editingRecordId=null}else p.records.push(rec);
  if(!save())return;
  // Yeni kaydı eklediğimiz sayfayı hemen göster. 3. kayıt ve sonraki kayıtlar görünür olsun.
  bookPageIndex=Math.max(0,Math.floor((p.records.length-1)/5));
  show('book')
};
function renderHome(){
 let p=activeProject();
 const rp=$('recentProject');
 if(rp) rp.innerHTML=p?`<div class="recentProjectLabel">AKTİF PROJE</div><div class="recentProjectName">${esc(p.name)}</div>`:'';
 const btn=$('projectSelectBtn'); if(btn)btn.textContent='PROJE SEÇ ▼';
 const picker=$('projectPicker');
 if(picker){
   picker.innerHTML=data.projects.length?data.projects.map(x=>`<button data-pick-project="${esc(x.id)}">${esc(x.name)}${x.id===data.activeId?' ✓':''}</button>`).join(''):'<div class="muted">Henüz proje yok.</div>';
   picker.querySelectorAll('[data-pick-project]').forEach(b=>b.onclick=()=>{data.activeId=b.dataset.pickProject;save();picker.classList.add('hide');renderHome()});
 }
 if(!p){
   $('recent').innerHTML='<div class="emptyBook"><b>Henüz aktif proje yok.</b><small>Ölçü eklemek için önce bir proje oluştur.</small></div>';
   $('homeSummary').innerHTML='<div class="muted">Proje oluşturduğunda ölçü, not ve işlerin burada özetlenecek.</div>';
   return;
 }
 const recent=p.records.slice().reverse().slice(0,24);
 const groups=[];
 const groupMap=new Map();
 recent.forEach(r=>{
   const key=`${r.cat}||${r.workItem||r.cat}`;
   if(!groupMap.has(key)){const g={cat:r.cat,workItem:r.workItem||r.cat,records:[]};groupMap.set(key,g);groups.push(g);}
   groupMap.get(key).records.push(r);
 });
 $('recent').innerHTML=groups.length?`<div class="homeNotebook">
   <div class="homeNotebookHeader"><span>SON ÖLÇÜLER</span><b>${esc(p.name)}</b></div>
   <div class="homeNotebookBody">
   ${groups.map(g=>{
     const total=sumUnits(g.records).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`).join(' • ');
     return `<section class="homeMeasureGroup">
       <div class="homeGroupHeader"><div><b>${esc(g.workItem)}</b><small>${esc(g.cat)}${total?` • Toplam: ${esc(total)}`:''}</small></div></div>
       <div class="homeGroupRows">
       ${g.records.map(r=>{
         const unit=fmtUnit(r.unit);
         const dims=r.unit==='m3'?`${r.a} × ${r.b} × ${r.c||0}`:(r.unit==='m2'?`${r.a} × ${r.b||0}`:`${r.a}`);
         const amount=r.price?`${(Number(r.value)*Number(r.price)).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})} ₺`:'';
         const context=r.cat==='Dış Cephe'
           ? `${r.facade||'Cephe belirtilmedi'}${r.floor?' • '+r.floor:''}`
           : `${r.area||'Alan belirtilmedi'}${r.floor?' • '+r.floor:''}`;
         return `<div class="homeGroupRow">
           <div class="homeGroupRowMain"><b>${esc(context)}</b><small>${esc(dims)} ${unit}${r.note?' • '+esc(r.note):''}</small></div>
           <div class="homeGroupRowValue"><strong>${Number(r.value).toLocaleString('tr-TR',{maximumFractionDigits:2})} ${unit}</strong>${amount?`<small>${amount}</small>`:''}</div>
         </div>`;
       }).join('')}
       </div>
     </section>`;
   }).join('')}
   </div>
   <button class="homeOpenBook" id="homeOpenBook">Defteri Aç →</button>
 </div>`:'<div class="emptyBook"><b>Henüz kayıt yok.</b><small>Yeni Ölçü ile ilk kaydını ekle.</small></div>';
 $('homeOpenBook')?.addEventListener('click',()=>show('book'));

 const summaryMap=new Map();
 p.records.forEach(r=>{
   const key=r.workItem||r.cat||'Diğer';
   if(!summaryMap.has(key)) summaryMap.set(key,{name:key,records:[]});
   summaryMap.get(key).records.push(r);
 });
 const summaryGroups=[...summaryMap.values()];
 $('homeSummary').innerHTML=summaryGroups.length?`<div class="summaryGrid">${
   summaryGroups.map(g=>{
     const totals=sumUnits(g.records).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`).join(' • ');
     const totalCost=g.records.reduce((s,r)=>s+(r.price||0)*r.value,0);
     return `<div class="summaryMeasureBox">
       <b>${esc(g.name)}</b>
       <strong>${esc(totals||'0')}</strong>
       <small>Toplam ölçü${totalCost>0?` • ${totalCost.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})} ₺`:''}</small>
     </div>`;
   }).join('')
 }</div>`:'<div class="muted">Henüz ölçü kaydı yok.</div>';
}
function renderProjects(){let g=$('projectList');if(!g)return;let q=($('projectSearch')?.value||'').toLowerCase();g.innerHTML='';data.projects.filter(p=>p.name.toLowerCase().includes(q)).forEach(p=>{let row=document.createElement('div');row.className='projectRow';row.innerHTML=`<div class="projectInfo"><b>${esc(p.name)}</b><small>${p.records.length} ölçü • ${(p.tasks||[]).filter(t=>!t.done).length} açık iş${p.id===data.activeId?' • AKTİF':''}</small></div><div class="projectActions"><button class="openProject">Aç</button><button class="renameProject">Düzenle</button>${data.projects.length>1?'<button class="deleteProject">Sil</button>':''}</div>`;row.querySelector('.openProject').onclick=()=>{data.activeId=p.id;save();show('home')};row.querySelector('.renameProject').onclick=()=>{let n=prompt('Proje adı:',p.name);if(n?.trim()){p.name=n.trim();save();renderProjects()}};let d=row.querySelector('.deleteProject');if(d)d.onclick=()=>{if(confirm(`“${p.name}” silinsin mi?`)){data.projects=data.projects.filter(x=>x.id!==p.id);data.activeId=data.projects[0].id;save();renderProjects()}};g.append(row)})}
$('projectSearch').oninput=renderProjects;
$('addProject').onclick=()=>{let n=$('newProjectName').value.trim();if(!n)return alert('Proje adı yaz.');let p={id:'p_'+Date.now()+'_'+Math.random().toString(36).slice(2),name:n,records:[],notes:[],tasks:[],photos:[]};data.projects.push(p);data.activeId=p.id;$('newProjectName').value='';save();show('home')};
function fmtUnit(u){return u==='m2'?'m²':u==='m3'?'m³':u==='mtul'?'mt':u==='metre'?'m':'adet'}
function sumUnits(rs){return ['m2','mtul','metre','m3','adet'].map(u=>({u,v:rs.filter(r=>r.unit===u).reduce((s,r)=>s+(Number(r.value)||0),0)})).filter(x=>x.v)}
function totalsHtml(rs,label='Toplam'){let parts=sumUnits(rs).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`);return parts.length?`<div class="total"><span>${esc(label)}</span><span>${parts.join(' • ')}</span></div>`:''}
let bookPageIndex=0;
let bookTouchX=0;
let bookTurnDirection='next';
let bookTurnBusy=false;
let lastTouchTurnAt=0;

function playPageFlipSound(){
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return;
    const ctx=new AC();
    if(ctx.state==='suspended')ctx.resume();
    const now=ctx.currentTime;
    const makeRustle=(delay,duration,volume,frequency)=>{
      const buffer=ctx.createBuffer(1,Math.floor(ctx.sampleRate*duration),ctx.sampleRate);
      const data=buffer.getChannelData(0);
      for(let i=0;i<data.length;i++){
        const t=i/data.length;
        const env=Math.pow(1-t,1.7);
        data[i]=(Math.random()*2-1)*env;
      }
      const src=ctx.createBufferSource();src.buffer=buffer;
      const filter=ctx.createBiquadFilter();filter.type='bandpass';filter.frequency.value=frequency;filter.Q.value=.55;
      const gain=ctx.createGain();
      gain.gain.setValueAtTime(.0001,now+delay);
      gain.gain.exponentialRampToValueAtTime(volume,now+delay+.012);
      gain.gain.exponentialRampToValueAtTime(.0001,now+delay+duration);
      src.connect(filter).connect(gain).connect(ctx.destination);
      src.start(now+delay);src.stop(now+delay+duration+.01);
    };
    makeRustle(0,.22,.20,1700);
    makeRustle(.045,.18,.12,2900);
    makeRustle(.09,.13,.07,4200);
    setTimeout(()=>ctx.close().catch(()=>{}),420);
  }catch(_){}
}

function turnBookPage(nextIndex,direction){
  const max=Math.max(0,Math.ceil((activeProject()?.records?.length||0)/6)-1);
  if(bookTurnBusy||nextIndex<0||nextIndex>max||nextIndex===bookPageIndex)return;
  bookTurnBusy=true;
  bookTurnDirection=direction|| (nextIndex>bookPageIndex?'next':'prev');
  playPageFlipSound();
  const page=$('paperBookPages')?.querySelector('.notebookPage');
  if(page){page.classList.add(bookTurnDirection==='next'?'pageFlipOutNext':'pageFlipOutPrev');}
  setTimeout(()=>{bookPageIndex=nextIndex;bookTurnBusy=false;renderBook()},260);
}

function renderBook(){
  let p=activeProject();
  if(!p){const bp=$('bookProject');if(bp)bp.textContent='';const bc=$('bookContent');if(bc)bc.replaceChildren();return;}
  let q=($('bookSearch')?.value||'').trim().toLowerCase();
  let floorFilter=$('bookFloor')?.value||'';
  let catFilter=$('bookCat')?.value||'';

  let rs=p.records.filter(r=>{
    let text=`${r.cat} ${r.workItem||''} ${r.area} ${r.floor||''} ${r.facade||''} ${r.note||''}`.toLowerCase();
    return (!q||text.includes(q))&&(!floorFilter||r.floor===floorFilter)&&(!catFilter||r.cat===catFilter);
  });

  // Aynı iş kalemlerini tek başlık altında birleştir.
  const grouped=[];
  const groupMap=new Map();
  rs.forEach(r=>{
    const key=`${r.cat}||${r.workItem||r.cat}`;
    if(!groupMap.has(key)){
      const g={key,cat:r.cat,label:r.workItem||r.cat,records:[]};
      groupMap.set(key,g);
      grouped.push(g);
    }
    groupMap.get(key).records.push(r);
  });

  // Sayfaları mümkün olduğunca grup bütünlüğünü koruyarak oluştur.
  const pageLimit=6;
  const pages=[];
  let current=[];
  let count=0;
  grouped.forEach(g=>{
    if(current.length && count+g.records.length>pageLimit){
      pages.push(current);
      current=[];
      count=0;
    }
    // Çok büyük bir grup varsa aynı başlık altında sayfalara böl.
    for(let i=0;i<g.records.length;i+=pageLimit){
      const chunk=g.records.slice(i,i+pageLimit);
      if(chunk.length===g.records.length){
        current.push({...g,records:chunk});
        count+=chunk.length;
      }else{
        if(current.length){pages.push(current);current=[];count=0;}
        pages.push([{...g,records:chunk}]);
      }
    }
  });
  if(current.length) pages.push(current);
  if(!pages.length) pages.push([]);

  bookPageIndex=Math.max(0,Math.min(bookPageIndex,pages.length-1));

  let h=`<div class="bookToolbar">
    <div class="bookSearch"><span>⌕</span><input id="bookSearch" value="${esc(q)}" placeholder="Defterde ara..." autocomplete="off"></div>
    <div class="bookFilters">
      <select id="bookFloor"><option value="">Tüm katlar</option>${floors.map(f=>`<option ${floorFilter===f?'selected':''}>${esc(f)}</option>`).join('')}</select>
      <select id="bookCat"><option value="">Tüm kalemler</option>${Object.keys(areas).map(c=>`<option ${catFilter===c?'selected':''}>${esc(c)}</option>`).join('')}</select>
    </div>
  </div>`;

  h+=`<div class="bookQuick"><button id="bookQuickMeasure">＋ Ölçü</button><button id="bookQuickNote">＋ Not</button><button id="bookQuickTask">＋ İş</button></div>`;
  h+=`<div class="bookStats">${totalsHtml(p.records,'Proje toplamı')}</div>`;

  h+=`<div class="paperBook" id="paperBook">
    <div class="paperBookHeader">
      <span>ÖLÇÜ DEFTERİ AI</span>
      <b>${esc(p.name)}</b>
    </div>
    <div class="paperBookPages" id="paperBookPages">`;

  const page=pages[bookPageIndex];
  if(!page.length){
    h+=`<div class="notebookPage emptyBook ${bookTurnDirection==='next'?'pageFlipInNext':'pageFlipInPrev'}"><div class="paperMargin"></div><div class="emptyBookInner"><b>${p.records.length?'Aradığın kayıt bulunamadı':'Defter boş'}</b><small>${p.records.length?'Filtreyi değiştir veya aramayı temizle.':'İlk ölçünü ekleyerek defteri oluşturmaya başla.'}</small></div></div>`;
  }else{
    h+=`<div class="notebookPage ${bookTurnDirection==='next'?'pageFlipInNext':'pageFlipInPrev'}"><div class="paperMargin"></div>
      <div class="paperPageTitle"><span>${esc(p.name)}</span><strong>${new Date().toLocaleDateString('tr-TR')}</strong></div>`;

    page.forEach(group=>{
      const groupTotals=sumUnits(group.records).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`).join(' • ');
      h+=`<section class="notebookGroup">
        <div class="notebookSection">
          <b>${esc(group.label).toUpperCase()}</b>
          <span>${esc(groupTotals||'0')}</span>
        </div>`;

      group.records.forEach(r=>{
        const realIndex=p.records.indexOf(r);
        const unit=fmtUnit(r.unit);
        const dims=r.unit==='m3'?`${r.a} × ${r.b} × ${r.c}`:r.unit==='m2'?`${r.a} × ${r.b}`:`${r.a}`;
        const amount=r.price?`${(Number(r.value)*Number(r.price)).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})} ₺`:'';
        const facadeName=r.cat==='Dış Cephe'?(r.facade || (FACADE_OPTIONS.includes(r.area)?r.area:'')):'';
        const displayArea=r.cat==='Dış Cephe'?'Dış Cephe':(r.area||'');
        h+=`<article class="notebookLine">
          <div class="notebookLineMain">
            <div>
              ${facadeName?`<span class="facadeBadge">▥ ${esc(facadeName)}</span>`:''}
              <small>${esc(displayArea)}${r.floor?' · '+esc(r.floor):''}</small>
            </div>
            <strong>${Number(r.value).toLocaleString('tr-TR',{maximumFractionDigits:2})} ${unit}</strong>
          </div>
          <div class="notebookLineDetail">
            <span>${esc(dims)} ${unit}</span>${amount?`<span>${amount}</span>`:''}
          </div>
          ${r.note?`<div class="recordNote">${esc(r.note)}</div>`:''}
          <div class="recordActions"><button data-editrec="${realIndex}">Düzenle</button><button data-delrec="${realIndex}">Sil</button></div>
        </article>`;
      });
      h+=`</section>`;
    });

    h+=`<div class="paperFooter"><span>Ölçü Defteri</span><b>Sayfa ${bookPageIndex+1} / ${pages.length}</b></div></div>`;
  }

  h+=`</div>
    <div class="bookNav">
      <button id="bookPrev" ${bookPageIndex===0?'disabled':''}>‹ Önceki</button>
      <span>Sayfa ${bookPageIndex+1} / ${pages.length}</span>
      <button id="bookNext" ${bookPageIndex===pages.length-1?'disabled':''}>Sonraki ›</button>
    </div>
    <div class="swipeHint">Sayfayı değiştirmek için sağa veya sola kaydır</div>
  </div>`;

  $('bookProject').textContent=p.name;
  $('bookContent').innerHTML=h;

  const bs=$('bookSearch'); if(bs) bs.oninput=()=>{bookPageIndex=0;renderBook()};
  const bf=$('bookFloor'); if(bf) bf.onchange=()=>{bookPageIndex=0;renderBook()};
  const bc=$('bookCat'); if(bc) bc.onchange=()=>{bookPageIndex=0;renderBook()};

  $('bookPrev')?.addEventListener('click',()=>turnBookPage(bookPageIndex-1,'prev'));
  $('bookNext')?.addEventListener('click',()=>turnBookPage(bookPageIndex+1,'next'));

  const pb=$('paperBookPages');
  if(pb){
    let sx=0,sy=0,drag=false;
    pb.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY;drag=true},{passive:true});
    pb.addEventListener('touchend',e=>{
      if(!drag)return; drag=false;
      const dx=e.changedTouches[0].clientX-sx, dy=e.changedTouches[0].clientY-sy;
      if(Math.abs(dx)<55 || Math.abs(dx)<Math.abs(dy))return;
      if(dx<0 && bookPageIndex<pages.length-1){lastTouchTurnAt=Date.now();turnBookPage(bookPageIndex+1,'next');}
      else if(dx>0 && bookPageIndex>0){lastTouchTurnAt=Date.now();turnBookPage(bookPageIndex-1,'prev');}
    },{passive:true});
    pb.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;drag=true;});
    pb.addEventListener('pointerup',e=>{
      if(!drag)return; drag=false;
      if(Date.now()-lastTouchTurnAt<500)return;
      const dx=e.clientX-sx, dy=e.clientY-sy;
      if(Math.abs(dx)<55 || Math.abs(dx)<Math.abs(dy))return;
      if(dx<0 && bookPageIndex<pages.length-1) turnBookPage(bookPageIndex+1,'next');
      else if(dx>0 && bookPageIndex>0) turnBookPage(bookPageIndex-1,'prev');
    });
  }

  document.querySelectorAll('[data-delrec]').forEach(b=>b.onclick=()=>{
    let i=+b.dataset.delrec;
    if(confirm('Bu ölçü silinsin mi?')){p.records.splice(i,1);save();renderBook()}
  });

  document.querySelectorAll('[data-editrec]').forEach(b=>b.onclick=()=>{
    let r=p.records[+b.dataset.editrec];
    cat=r.cat; area=r.area; workItem=r.workItem||r.area;
    selectedFacade=cat==='Dış Cephe'?(r.facade || (FACADE_OPTIONS.includes(r.area)?r.area:'')):'';
    $('entryCat').textContent='YENİ ÖLÇÜ';
    $('entryArea').textContent=`${cat} - ${workItem}`;
    $('workItemWrap').textContent=cat==='Dış Cephe'?('Cephe: '+(selectedFacade||'Seçilmedi')):'';
    $('facadeWrap')?.classList.toggle('hide',cat!=='Dış Cephe');
    $('floorWrap')?.classList.toggle('hide',cat==='Dış Cephe');
    if($('facadeSelect'))$('facadeSelect').value=selectedFacade||'';
    $('a').value=r.a||''; $('b').value=r.b||''; $('c').value=r.c||'';
    $('floor').value=r.floor||'';
    if($('areaSelect')){
      $('areaSelect').innerHTML='<option value="">Alan seçilmedi</option>'+INTERIOR_AREAS.map(x=>`<option>${esc(x)}</option>`).join('');
      $('areaSelect').value=INTERIOR_AREAS.includes(r.area)?r.area:'';
      $('areaWrap').classList.toggle('hide',cat!=='İç Cephe');
    }
    $('unit').value=r.unit||'m2'; $('note').value=r.note||''; $('price').value=r.price||'';
    window.editingRecordId=r.id; updateCalc(); show('entry');
  });
  $('bookQuickMeasure')?.addEventListener('click',()=>{$('new').click()});
  $('bookQuickNote')?.addEventListener('click',()=>show('notes'));
  $('bookQuickTask')?.addEventListener('click',()=>show('tasks'));
}
function renderNotes(){let p=activeProject();if(!p){const np=$('notesProject');if(np)np.textContent='';const nl=$('notesList');if(nl)nl.replaceChildren();return;}$('notesProject').textContent=p.name;$('notesList').innerHTML=p.notes.length?p.notes.map((n,i)=>`<div class="noteItem"><b>${esc(n.text).replace(/\n/g,'<br>')}</b>${n.qty?`<div class="noteMeta">${esc(n.qty)} ${esc(n.unit||'')}</div>`:''}<div class="noteMeta">${esc(n.date||'')}</div><button data-dn="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz not veya malzeme yok.</div>';document.querySelectorAll('[data-dn]').forEach(b=>b.onclick=()=>{p.notes.splice(+b.dataset.dn,1);save();renderNotes();renderBook()});renderPhotos()}
function addNote(text,qty,unit){let p=activeProject(),clean=String(text||'').trim();if(!clean)return false;p.notes.push({text:clean,qty:qty?+qty:null,unit:unit||'',date:new Date().toLocaleString('tr-TR')});save();return true}
$('addNote').onclick=()=>{if(!addNote($('noteText').value,$('noteQty').value,$('noteUnit').value))return alert('Not veya malzeme yaz.');$('noteText').value='';$('noteQty').value='';$('noteUnit').value='';renderNotes();renderBook()};$('addBookNote').onclick=()=>{if(!addNote($('bookNote').value,'',''))return alert('Yazı gir.');$('bookNote').value='';renderBook()};
function renderTasks(){let p=activeProject();if(!p){const tp=$('tasksProject');if(tp)tp.textContent='';const tl=$('taskList');if(tl)tl.replaceChildren();return;}$('tasksProject').textContent=p.name;$('taskList').innerHTML=p.tasks.length?p.tasks.map((t,i)=>`<div class="taskItem ${t.done?'done':''}"><label><input type="checkbox" data-task="${i}" ${t.done?'checked':''}> ${esc(t.text)}</label><button data-deltask="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz yapılacak iş yok.</div>';document.querySelectorAll('[data-task]').forEach(x=>x.onchange=()=>{p.tasks[+x.dataset.task].done=x.checked;save();renderTasks()});document.querySelectorAll('[data-deltask]').forEach(x=>x.onclick=()=>{p.tasks.splice(+x.dataset.deltask,1);save();renderTasks()})}
$('addTask').onclick=()=>{let t=$('taskText').value.trim();if(!t)return alert('İş yaz.');activeProject().tasks.push({text:t,done:false,date:new Date().toLocaleString('tr-TR')});$('taskText').value='';save();renderTasks()};
function compressImage(file){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=()=>{let im=new Image();im.onload=()=>{let max=900,sc=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.62))};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
$('photoInput').onchange=async e=>{let f=e.target.files?.[0];if(!f)return;try{let src=await compressImage(f);let p=activeProject();if(!p){alert('Önce bir proje seç.');return;}p.photos??=[];const photo={src,date:new Date().toLocaleString('tr-TR')};p.photos.push(photo);if(save()){renderPhotos();e.target.value='';}else{p.photos.pop();alert('Fotoğraf kaydedilemedi. Depolama alanı dolmuş olabilir.');}}catch(_){alert('Fotoğraf işlenemedi. Lütfen JPG/PNG bir fotoğraf seç.')}};
function renderPhotos(){let p=activeProject(),g=$('photoList');if(!g)return;g.innerHTML=p.photos.length?p.photos.map((x,i)=>`<div class="photo"><img src="${x.src}"><small>${esc(x.date)}</small><button data-dp="${i}">Sil</button></div>`).join(''):'<div class="muted">Henüz fotoğraf yok.</div>';g.querySelectorAll('[data-dp]').forEach(b=>b.onclick=()=>{p.photos.splice(+b.dataset.dp,1);save();renderPhotos()})}
const TR_NUMBERS={"sıfır":0,"bir":1,"iki":2,"üç":3,"dört":4,"beş":5,"altı":6,"yedi":7,"sekiz":8,"dokuz":9,"on":10,"yirmi":20,"otuz":30,"kırk":40,"elli":50,"altmış":60,"yetmiş":70,"seksen":80,"doksan":90,"yüz":100,"bin":1000};
function turkishNumberValue(s){
 s=String(s).toLowerCase().trim().replace(/\s+/g,' ');
 if(/^\d+(?:[.,]\d+)?$/.test(s))return parseFloat(s.replace(',','.'));
 let parts=s.split(' '),total=0,current=0,decimal=null;
 for(let x of parts){
   if(x==='buçuk'){decimal=.5;continue}
   let n=TR_NUMBERS[x]; if(n==null)return NaN;
   if(n===100||n===1000){current=(current||1)*n;total+=current;current=0}else current+=n;
 }
 return total+current+(decimal??0);
}
function numberTokens(text){
 let cleaned=normalizeText(text).replace(/['’]/g,' ').replace(/-/g,' ');
 let pattern=/\b\d+(?:[.,]\d+)?\b|\b(?:sıfır|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|otuz|kırk|elli|altmış|yetmiş|seksen|doksan|yüz|bin)(?:\s+(?:buçuk|sıfır|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|otuz|kırk|elli|altmış|yetmiş|seksen|doksan|yüz|bin))*\b/g;
 return [...cleaned.matchAll(pattern)].map(m=>turkishNumberValue(m[0])).filter(Number.isFinite);
}
function normalizeText(t){
 return String(t||'').toLowerCase().replace(/’/g,"'").replace(/×/g,' x ').replace(/m²/g,'m2').replace(/metrekare/g,'m2').replace(/metre kare/g,'m2').replace(/metreküp/g,'m3').replace(/metre küp/g,'m3').replace(/metretül/g,'mt').replace(/metre tül/g,'mt');
}
function findOne(t,list){let l=t.toLowerCase();return list.find(x=>l.includes(x.toLowerCase()))}
function floorFromText(t){
 const s=normalizeText(t);
 if(/\b(zemin|giriş)\s+kat\b/.test(s))return'Zemin Kat';
 if(/\bçatı\s+kat(?:ı)?\b/.test(s))return'Çatı Katı';
 let m=s.match(/(?:kat\s*)?(\d{1,2})\s*\.?\s*kat\b/i);
 if(m){let n=+m[1];if(n>=1&&n<=30)return `${n}. Kat`}
 const words={"birinci":1,"ikinci":2,"üçüncü":3,"dördüncü":4,"beşinci":5,"altıncı":6,"yedinci":7,"sekizinci":8,"dokuzuncu":9,"onuncu":10,"onbirinci":11,"onikinci":12,"onüçüncü":13,"ondördüncü":14,"onbeşinci":15,"onaltıncı":16,"onyedinci":17,"onsekizinci":18,"ondokuzuncu":19,"yirminci":20,"yirmibirinci":21,"yirmiikinci":22,"yirmiüçüncü":23,"yirmidördüncü":24,"yirmibeşinci":25,"yirmialtıncı":26,"yirmiyedinci":27,"yirmisekizinci":28,"yirmidokuzuncu":29,"otuzuncu":30};
 for(let [w,n] of Object.entries(words))if(s.includes(w))return `${n}. Kat`;
 return ''
}
function unitFromText(t){if(/\bm3\b|metreküp|metre küp/.test(t))return'm3';if(/\bmt\b|metretül|metre tül/.test(t))return'mtul';if(/\bmetre\b|\bm\b/.test(t))return'metre';if(/\badet\b/.test(t))return'adet';return'm2'}
function fallbackMeasureFromText(text){
 const t=normalizeText(text);
 if(!/(ölç|\bmetrekare\b|\bm2\b|\buzunlu|\bgenişlik|\byükseklik|\bx\b|['’]e\b)/i.test(t))return null;
 const nums=numberTokens(t); if(nums.length<2)return null;
 let category='';
 if(/dış cephe|ön cephe|arka cephe|sağ yan|sol yan|kör cephe|kuzey cephe|güney cephe|doğu cephe|batı cephe/.test(t))category='Dış Cephe';
 else if(/alçıpan/.test(t))category='Alçıpan';
 else if(/kaba sıva/.test(t))category='İç Sıva';
 else if(/ince sıva/.test(t))category='İç Sıva';
 else if(/alçı sıva|alçı/.test(t))category='Alçı Sıva';
 else if(/saten boya/.test(t))category='Saten Boya';
 else if(/dekoratif boya/.test(t))category='Dekoratif Boya';
 else if(/laminat parke|parke/.test(t))category='Laminat Parke';
 else if(/seramik/.test(t))category='Seramik';
 else if(/şap/.test(t))category='Şap';
 else if(/tavan/.test(t))category='Tavan';
 else if(/mantolama/.test(t))category='Mantolama';
 else category='İç Cephe';
 let work='';
 const workMap=[['kaba sıva','Kaba Sıva Ölçüsü'],['ince sıva','İnce Sıva Ölçüsü'],['alçı sıva','Alçı Sıva Ölçüsü'],['alçıpan','Alçıpan Ölçüsü'],['saten boya','Saten Boya Ölçüsü'],['dekoratif boya','Dekoratif Boya Ölçüsü'],['laminat parke','Laminat Parke Ölçüsü'],['parke','Laminat Parke Ölçüsü'],['seramik','Seramik Ölçüsü'],['şap','Şap Ölçüsü'],['mantolama','Mantolama Ölçüsü'],['tavan','Tavan Ölçüsü'],['duvar','Duvar Ölçüsü']];
 const wm=workMap.find(([k])=>t.includes(k)); work=wm?wm[1]:(category==='Dış Cephe'?'Kaba Sıva Ölçüsü':'Duvar Ölçüsü');
 let itemArea='';
 const allAreas=[...new Set(Object.values(areas).flat().concat(INTERIOR_AREAS,FACADE_OPTIONS))];
 const found=allAreas.find(x=>t.includes(x.toLowerCase())); if(found)itemArea=found;
 if(category==='Dış Cephe'&&!itemArea){const f=FACADE_OPTIONS.find(x=>t.includes(x.toLowerCase()));if(f)itemArea=f;}
 if(!itemArea&&category==='İç Cephe'){const i=INTERIOR_AREAS.find(x=>t.includes(x.toLowerCase()));if(i)itemArea=i;}
 if(!itemArea)return null;
 const unit=unitFromText(t),a=nums[0],b=nums[1],c=nums[2]||0;
 return {type:'add_measure',category,workItem:work,area:itemArea,floor:floorFromText(t),facade:category==='Dış Cephe'?itemArea:'',a,b,c,unit,note:'Yapay zekâ girişi'};
}
function voiceError(msg){$('aiResult').innerHTML='<b>Sesli giriş:</b> '+esc(msg||'Ses anlaşılamadı.');}
let aiConversation=[];
function addAIChat(role,text){
  aiConversation.push({role,text:String(text||'')});
  if(aiConversation.length>12)aiConversation=aiConversation.slice(-12);
  const box=$('aiChat'); if(box){
    box.innerHTML=aiConversation.map(m=>`<div class="aiBubble ${m.role==='user'?'user':'assistant'}"><b>${m.role==='user'?'Sen':'Ölçü Defteri AI'}</b><div>${esc(m.text)}</div></div>`).join('');
    box.scrollTop=box.scrollHeight;
  }
}
window.handleNativeVoice=function(text){
  const t=String(text||'').trim();
  if(!t)return voiceError('Ses anlaşılamadı.');
  $('aiText').value=t;
  aiParse(true);
};
window.voiceError=voiceError;
function aiFallbackActionsFromText(text){
  const t=String(text||'').trim();
  const low=t.toLocaleLowerCase('tr-TR');
  const out=[];
  const projectNames=data.projects.map(p=>p.name).sort((a,b)=>b.length-a.length);
  const projectName=projectNames.find(n=>low.includes(n.toLocaleLowerCase('tr-TR')))||'';
  const add=(x)=>{if(projectName)x.projectName=projectName;out.push(x)};
  const screenRules=[
    [/(ölçü defteri|ölçüleri|defteri).*(aç|göster)|ölçü defterini aç/,'book'],
    [/(not defteri|not \/ malzeme|malzeme defteri).*(aç|göster)|not defterini aç/,'notes'],
    [/(yapılacaklar|eksikler|görevler).*(aç|göster)/,'tasks'],
    [/(proje(ler)?).*(aç|göster|seç)/,'projects'],
    [/(hesap makinesi|hesaplama).*(aç|göster)/,'calculator']
  ];
  screenRules.forEach(([rx,screen])=>{if(rx.test(low))out.push({type:'open_screen',screen});});

  // Project commands: create or select/open. Be liberal with natural Turkish/voice phrasing.
  const createProjectPatterns=[
    /(?:yeni\s+)?(?:bir\s+)?proje(?:yi|yı)?\s+(?:oluştur|kur)(?:\s+ad[ıi]\s*)?[:\-]?\s*(.+)$/i,
    /(?:yeni\s+)?(?:bir\s+)?proje(?:\s+oluştur)?[^\n]*?ad[ıi]\s*[:\-]?\s*(.+?)(?:\s+olsun)?$/i
  ];
  let pm=null;
  for(const rx of createProjectPatterns){ const hit=low.match(rx); if(hit){pm=hit;break;} }
  if(pm){
    let name=pm[1].trim();
    name=name.replace(/^(?:olsun\s*)/i,'').replace(/\s+olsun[.!?]*$/i,'').trim();
    name=name.replace(/^[:\-]+/,'').trim();
    if(name){
      const existing=projectNames.find(n=>n.toLocaleLowerCase('tr-TR')===name.toLocaleLowerCase('tr-TR'));
      if(existing)add({type:'open_project',projectName:existing}); else out.push({type:'create_project',name:name.slice(0,120)});
    }
  }

  // Notes / materials. Keep quantities in the note payload when the user gives one.
  if(/\b(not|malzeme)\b/.test(low)){
    let txt=t.replace(/\b(?:not|malzeme)\b\s*(?:ekle|al|yaz|kaydet)?\s*[:\-]?\s*/i,'').trim();
    if(!txt || /^al$|^ekle$|^yaz$|^kaydet$/i.test(txt)){txt=t.replace(/\b(?:not|malzeme)\b/i,'').replace(/^(?:ekle|al|yaz|kaydet)\s*/i,'').trim();}
    if(txt){
      const q=txt.match(/^(\d+(?:[.,]\d+)?)\s*(adet|torba|paket|kutu|kg|ton|litre|lt|kova|metre|mt)\b\s*(.*)$/i);
      if(q)add({type:'add_note',text:q[3]||txt,qty:Number(q[1].replace(',','.')),unit:q[2].toLowerCase()});
      else add({type:'add_note',text:txt});
    }
  }
  if(/\b(yapılacak|görev|iş|eksik)\b/.test(low)&&/(ekle|yaz|oluştur|yapılacak)/.test(low)){
    let txt=t.replace(/.*?\b(?:yapılacak|görev|iş|eksik)\b\s*(?:ekle|yaz|oluştur|:|-)?\s*/i,'').trim();
    if(txt)add({type:'add_task',text:txt});
  }

  // Measurements are only inferred when the command contains an explicit save/measurement intent.
  if(/\b(ölç|ölçü|ölçüsünü|kaydet|ekle)\b/.test(low) && numberTokens(low).length>=2){
    const f=fallbackMeasureFromText(t);
    if(f){add(f);}
  }
  return out;
}
function localAIPlan(text){
  const raw=String(text||'').trim();
  const low=raw.toLocaleLowerCase('tr-TR');
  const actions=aiFallbackActionsFromText(raw);
  let reply='';

  // Short conversational replies are handled locally.
  if(/^(merhaba|selam|sa|günaydın|iyi akşamlar|iyi geceler)\b/i.test(low)){
    reply='Merhaba! Ölçü, proje, not, malzeme ve yapılacak işlerini söyle; cihaz üzerinde ücretsiz olarak kaydedebilirim.';
  } else if(/^(teşekkür|sağ ol|eyvallah)\b/i.test(low)){
    reply='Rica ederim. Hazırım.';
  }

  // Simple arithmetic without any network/API.
  const calcMatch=low.match(/(?:hesapla|kaç eder|sonuç)\s*[:：]?\s*([0-9.,]+)\s*(topla|\+|çıkar|-|çarp|\*|x|böl|\/)?\s*([0-9.,]+)(?:\s*(?:ve|ile)\s*([0-9.,]+))?/i);
  if(calcMatch){
    const nums=[calcMatch[1],calcMatch[3],calcMatch[4]].filter(Boolean).map(x=>Number(String(x).replace(',','.')));
    const op=(calcMatch[2]||'+').toLocaleLowerCase('tr-TR');
    let result=null;
    if(nums.length>=2){
      if(['topla','+'].includes(op))result=nums.reduce((a,b)=>a+b,0);
      else if(['çıkar','-'].includes(op))result=nums.slice(1).reduce((a,b)=>a-b,nums[0]);
      else if(['çarp','*','x'].includes(op))result=nums.reduce((a,b)=>a*b,1);
      else if(['böl','/'].includes(op))result=nums.slice(1).reduce((a,b)=>a/b,nums[0]);
    }
    if(result!=null&&Number.isFinite(result)){
      actions.push({type:'calculate',numbers:nums,operator:op});
      reply='';
    }
  }

  // "bunu kaydet/ekle" uses the previous user message as context.
  if(actions.length===0 && /^(bunu|şunu)\s+(kaydet|ekle|yaz|deftere yaz)\b/i.test(low)){
    const prev=[...aiConversation].reverse().find(m=>m.role==='user'&&m.text!==raw)?.text||'';
    if(prev) actions.push(...aiFallbackActionsFromText(prev));
  }

  // Open a measurement entry directly from a natural command.
  if(actions.length===0 && /(ölçü|ölçüsünü|ölçüm|ölç)/i.test(low)){
    const f=fallbackMeasureFromText(raw);
    if(f && activeProject()) actions.push({type:'open_measurement',category:f.category,area:f.area,workItem:f.workItem,facade:f.facade});
  }

  if(!reply && !actions.length){
    reply='Bunu cihaz üzerinde anlayamadım. Örneğin “yeni proje oluştur, adı Şantiye 1 olsun”, “ölçü defterini aç”, “10 torba çimento not al” veya “merdiven boşluğu kaba sıva 4 x 8 kaydet” diyebilirsin.';
  }
  return {reply,actions};
}

function runAIHomeCommand(text){
  const ai=$('aiText'); if(!ai)return; ai.value=text; show('ai'); setTimeout(()=>aiParse(false),60);
}
async function aiParse(fromVoice=false){
  const p=activeProject();
  const text=($('aiText').value||'').trim();
  if(!text)return voiceError('Önce ne yapmak istediğini yaz veya sesli anlat.');
  addAIChat('user',text);
  $('aiText').value='';
  $('aiParse').disabled=true;
  $('aiResult').innerHTML='<b>Yapay zekâ düşünüyor...</b>';
  try{
    // Ücretsiz/offline AI: artık OpenAI/Supabase AI çağrısı yapılmaz.
    // Komutlar cihaz üzerinde çözümlenir; giriş yapmadan da çalışır.
    const j=localAIPlan(text);
    const actions=Array.isArray(j.actions)?j.actions:[];
    let added=[];
    let changed=false;
    let navigated=false;
    const resolveActionProject=(action,createIfMissing=false)=>{
      const requested=String(action?.projectName||action?.project||'').trim().toLowerCase();
      if(requested){
        const found=data.projects.find(x=>x.name.trim().toLowerCase()===requested) || data.projects.find(x=>x.name.toLowerCase().includes(requested));
        if(!found)return null;
        if(data.activeId!==found.id){data.activeId=found.id;changed=true;renderHome();}
        return found;
      }
      return activeProject();
    };
    actions.forEach(raw=>{
      const a=raw?.data&&typeof raw.data==='object'?Object.assign({},raw.data,{type:raw.type}):raw||{};
      if(a.type==='open_measurement'){
        if(!activeProject()){added.push('Ölçü girişi açmak için önce bir proje oluştur veya seç.');return;}
        const category=String(a.category||'İç Cephe');
        const itemArea=String(a.area||'').trim();
        const label=String(a.workItem||a.label||itemArea||'Ölçü').trim();
        if(category==='İç Cephe'&&!itemArea){added.push('Alanı da söylemelisin. Örneğin: Merdiven Boşluğu kaba sıva.');return;}
        openMeasurement(category,itemArea,label,String(a.facade||''));
        navigated=true;
        added.push('✓ Ölçü girişi açıldı: '+label+(itemArea?' / '+itemArea:''));
      } else if(a.type==='open_project'){
        const wanted=String(a.projectName||a.name||'').trim().toLowerCase();
        if(!wanted){added.push('Açılacak projenin adını belirtmelisin.');return;}
        const found=data.projects.find(x=>x.name.trim().toLowerCase()===wanted) || data.projects.find(x=>x.name.toLowerCase().includes(wanted));
        if(!found){added.push('“'+String(a.projectName||a.name||'')+'” adlı proje bulunamadı.');return;}
        data.activeId=found.id;changed=true;renderHome();
        added.push('✓ Proje açıldı: '+found.name);
      } else if(a.type==='open_screen'){
        const allowed=['home','projects','categories','areas','entry','ai','book','notes','tasks','calculator','pro','auth','welcome'];
        const target=allowed.includes(String(a.screen||''))?String(a.screen):'home';
        if(['categories','book','notes','tasks','pro'].includes(target)&&!activeProject()){
          added.push('Önce bir proje oluşturmalısın.');
        }else{
          if(target==='categories')renderCats();
          if(target==='pro')renderPro();
          show(target);
          navigated=true;
          added.push('✓ '+({home:'Ana sayfa',projects:'Projeler',categories:'Yeni ölçü',areas:'Alanlar',entry:'Ölçü girişi',ai:'Yapay zekâ',book:'Ölçü Defteri',notes:'Not / Malzeme Defteri',tasks:'Yapılacaklar',calculator:'Hesap Makinesi',pro:'Pro Merkez',auth:'Hesabım',welcome:'Hoş geldin'}[target]||'Sayfa')+' açıldı.');
        }
      } else if(a.type==='create_project'&&String(a.name||'').trim()){
        const name=String(a.name).trim().slice(0,120);
        const np={id:'p_'+Date.now()+'_'+Math.random().toString(36).slice(2),name,records:[],notes:[],tasks:[],photos:[]};
        data.projects.push(np);data.activeId=np.id;changed=true;
        added.push('✓ Proje oluşturuldu: '+name);
      } else if(a.type==='calculate'){
        const nums=Array.isArray(a.numbers)?a.numbers.map(Number).filter(Number.isFinite):[];
        const op=String(a.operator||'').toLowerCase();
        let result=null;
        if(nums.length>=2){
          if(op==='topla'||op==='+'||op==='add')result=nums.reduce((x,y)=>x+y,0);
          else if(op==='çıkar'||op==='-'||op==='subtract')result=nums.slice(1).reduce((x,y)=>x-y,nums[0]);
          else if(op==='çarp'||op==='*'||op==='multiply')result=nums.reduce((x,y)=>x*y,1);
          else if(op==='böl'||op==='/'||op==='divide')result=nums.slice(1).reduce((x,y)=>x/y,nums[0]);
        }
        if(result!=null&&Number.isFinite(result))added.push('✓ Hesap sonucu: '+Number(result.toFixed(4)).toLocaleString('tr-TR'));
      } else if(a.type==='add_measure'){
        // AI bazen ölçüleri a/b/c yerine numbers dizisiyle döndürebilir.
        const aiNums=Array.isArray(a.numbers)?a.numbers.map(Number).filter(Number.isFinite):[];
        const aa=(a.a!=null&&a.a!=='')?Number(a.a):aiNums[0];
        const bb=(a.b!=null&&a.b!=='')?Number(a.b):aiNums[1];
        const cc=(a.c!=null&&a.c!=='')?Number(a.c):aiNums[2];
        if(!Number.isFinite(aa)){added.push('Ölçü için sayısal değer alınamadı.');return;}
        const targetProject=resolveActionProject(a);
        if(!targetProject){added.push('Ölçü kaydetmek için hedef projeyi belirt veya önce bir proje oluştur.');return;}
        const resolvedArea=String(a.area||a.workItem||'').trim();
        if(!resolvedArea){added.push('Ölçünün alanını da belirtmelisin.');return;}
        const isExterior=String(a.category||'')==='Dış Cephe';
        const aiFacade=isExterior?String(a.facade||resolvedArea).trim():'';
        const recordArea=isExterior?'Dış Cephe':resolvedArea;
        const unit=['m2','mtul','metre','m3','adet','kg','ton','torba','paket','kutu','litre','kova'].includes(String(a.unit||''))?String(a.unit):'m2';
        const nums=[aa,Number.isFinite(bb)?bb:1,Number.isFinite(cc)?cc:0];
        let value=unit==='m3'?nums[0]*nums[1]*nums[2]:(unit==='m2'?nums[0]*nums[1]:nums[0]);
        const rec={id:'r_'+Date.now()+'_'+Math.random().toString(36).slice(2),cat:a.category||'İç Cephe',area:recordArea,workItem:a.workItem||'',floor:a.floor||'',facade:aiFacade,a:nums[0],b:nums[1],c:nums[2],unit,value:+value.toFixed(2),note:a.note||'Yapay zekâ girişi',price:Number(a.price||0),createdAt:new Date().toISOString()};
        if(persistAIRecord(targetProject,rec)){
          changed=true;
          added.push('✓ '+(a.floor?a.floor+' · ':'')+(a.category||'İç Cephe')+' / '+(a.workItem?a.workItem+' / ':'')+resolvedArea+' = '+value.toLocaleString('tr-TR',{maximumFractionDigits:2})+' '+fmtUnit(unit));
        }else added.push('Ölçü kaydedilemedi.');
      } else if(a.type==='add_note'&&a.text){
        const targetProject=resolveActionProject(a); if(!targetProject){added.push('Not kaydetmek için hedef projeyi belirt veya önce bir proje oluştur.');return;}
        targetProject.notes??=[];
        targetProject.notes.push({id:'n_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:String(a.text).trim(),qty:Number(a.qty||0),unit:a.unit||'',date:new Date().toLocaleString('tr-TR')});
        changed=true;added.push('✓ Not kaydedildi: '+a.text);
      } else if(a.type==='add_task'&&a.text){
        const targetProject=resolveActionProject(a); if(!targetProject){added.push('İş eklemek için hedef projeyi belirt veya önce bir proje oluştur.');return;}
        targetProject.tasks??=[];
        targetProject.tasks.push({id:'t_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:String(a.text).trim(),done:false,date:new Date().toLocaleString('tr-TR')});
        changed=true;added.push('✓ İş kaydedildi: '+a.text);
      } else if(a.type==='update_measure'&&a.record_id){
        const targetProject=resolveActionProject(a); if(!targetProject){added.push('Ölçü güncellemek için hedef projeyi belirt.');return;}
        const rec=targetProject.records.find(x=>x.id===a.record_id);
        if(rec&&a.value!=null){rec.value=Number(a.value);changed=true;added.push('✓ Ölçü güncellendi.');}
        else added.push('Güncellenecek gerçek ölçü bulunamadı.');
      } else if(a.type==='delete_measure'&&a.record_id){
        const targetProject=resolveActionProject(a); if(!targetProject){added.push('Ölçü silmek için hedef projeyi belirt.');return;}
        const idx=targetProject.records.findIndex(x=>x.id===a.record_id);
        if(idx>=0){const removed=targetProject.records.splice(idx,1)[0];changed=true;added.push('✓ Ölçü silindi: '+(removed.workItem||removed.cat||'kayıt'));}
        else added.push('Silinecek gerçek ölçü bulunamadı.');
      }
    });
    // Sunucu action üretmezse, açık komutlar için yerel güvenlik ağı çalışır.
    if(!changed){
      const fallbackActions=aiFallbackActionsFromText(text);
      fallbackActions.forEach(a=>{
        if(a.type==='create_project'&&String(a.name||'').trim()){
          const wanted=String(a.name).trim();
          const existing=data.projects.find(x=>x.name.trim().toLocaleLowerCase('tr-TR')===wanted.toLocaleLowerCase('tr-TR'));
          if(existing){data.activeId=existing.id;changed=true;added.push('✓ Proje açıldı: '+existing.name);}
          else {const np={id:'p_'+Date.now()+'_'+Math.random().toString(36).slice(2),name:wanted.slice(0,120),records:[],notes:[],tasks:[],photos:[]};data.projects.push(np);data.activeId=np.id;changed=true;added.push('✓ Proje oluşturuldu: '+np.name);}
        }
        else if(a.type==='add_note'){const tp=resolveActionProject(a);if(tp){tp.notes??=[];tp.notes.push({id:'n_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:a.text,qty:Number(a.qty||0),unit:a.unit||'',date:new Date().toLocaleString('tr-TR')});changed=true;added.push('✓ Not kaydedildi: '+a.text);}}
        else if(a.type==='add_task'){const tp=resolveActionProject(a);if(tp){tp.tasks??=[];tp.tasks.push({id:'t_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:a.text,done:false,date:new Date().toLocaleString('tr-TR')});changed=true;added.push('✓ İş kaydedildi: '+a.text);}}
        else if(a.type==='open_screen'){const target=a.screen;show(target);navigated=true;added.push('✓ İlgili defter açıldı.');}
      });
    }
    if(!changed){
      const fallbackActions=aiFallbackActionsFromText(text);
      const explicit=fallbackActions.filter(a=>['add_measure','add_note','add_task','create_project','open_project'].includes(a.type));
      if(explicit.length){
        explicit.forEach(a=>{
          if(a.type==='create_project'&&String(a.name||'').trim()){
            const np={id:'p_'+Date.now()+'_'+Math.random().toString(36).slice(2),name:String(a.name).trim().slice(0,120),records:[],notes:[],tasks:[],photos:[]};
            data.projects.push(np);data.activeId=np.id;changed=true;added.push('✓ Proje oluşturuldu: '+np.name);
          }else if(a.type==='open_project'){
            const found=data.projects.find(x=>x.name.toLowerCase()===String(a.projectName||'').toLowerCase())||data.projects.find(x=>x.name.toLowerCase().includes(String(a.projectName||'').toLowerCase()));
            if(found){data.activeId=found.id;changed=true;added.push('✓ Proje açıldı: '+found.name);}
          }else if(a.type==='add_note'){
            const tp=resolveActionProject(a);if(tp){tp.notes??=[];tp.notes.push({id:'n_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:String(a.text).trim(),qty:Number(a.qty||0),unit:a.unit||'',date:new Date().toLocaleString('tr-TR')});changed=true;added.push('✓ Not/malzeme kaydedildi: '+a.text);}
          }else if(a.type==='add_task'){
            const tp=resolveActionProject(a);if(tp){tp.tasks??=[];tp.tasks.push({id:'t_'+Date.now()+'_'+Math.random().toString(36).slice(2),text:String(a.text).trim(),done:false,date:new Date().toLocaleString('tr-TR')});changed=true;added.push('✓ İş kaydedildi: '+a.text);}
          }else if(a.type==='add_measure'){
            const tp=resolveActionProject(a);if(tp&&Number.isFinite(Number(a.a))){
              const aa=Number(a.a),bb=Number(a.b||1),cc=Number(a.c||0),unit=a.unit||'m2';
              const value=unit==='m3'?aa*bb*cc:(unit==='m2'?aa*bb:aa);
              const ext=a.category==='Dış Cephe';
              tp.records.push({id:'r_'+Date.now()+'_'+Math.random().toString(36).slice(2),cat:a.category||'İç Cephe',area:ext?'Dış Cephe':a.area,workItem:a.workItem||'',floor:a.floor||'',facade:ext?(a.facade||a.area):'',a:aa,b:bb,c:cc,unit,value:+value.toFixed(2),note:'Yapay zekâ girişi',price:0,createdAt:new Date().toISOString()});
              changed=true;added.push('✓ Ölçü kaydedildi: '+value.toLocaleString('tr-TR',{maximumFractionDigits:2})+' '+fmtUnit(unit));
            }
          }
        });
      }
    }
    if(!changed){
      const fallback=fallbackMeasureFromText(text);
      if(fallback){
        const targetProject=activeProject();
        if(targetProject){
          const nums=[Number(fallback.a),Number(fallback.b||1),Number(fallback.c||0)];
          const unit=fallback.unit, value=unit==='m3'?nums[0]*nums[1]*nums[2]:(unit==='m2'?nums[0]*nums[1]:nums[0]);
          const fallbackExterior=fallback.category==='Dış Cephe';
          const rec={id:'r_'+Date.now()+'_'+Math.random().toString(36).slice(2),cat:fallback.category,area:fallbackExterior?'Dış Cephe':fallback.area,workItem:fallback.workItem,floor:fallback.floor,facade:fallbackExterior?(fallback.facade||fallback.area):'',a:nums[0],b:nums[1],c:nums[2],unit,value:+value.toFixed(2),note:fallback.note,price:0,createdAt:new Date().toISOString()};
          if(persistAIRecord(targetProject,rec)){
            changed=true;
            added.push('✓ Güvenli kayıt: '+fallback.category+' / '+fallback.workItem+' / '+fallback.area+' = '+value.toLocaleString('tr-TR',{maximumFractionDigits:2})+' '+fmtUnit(unit));
          }
        }
      }
    }
    if(changed && !save())throw new Error('Ölçü cihaz hafızasına yazılamadı.');
    if(changed && window.authSession?.access_token && typeof window.syncData==='function'){ try{ await window.syncData(false); }catch(_){} }
    const reply=j.reply||'';
    if(reply)addAIChat('assistant',reply);
    if(added.length)addAIChat('assistant',added.join('\n'));
    $('aiResult').innerHTML=(reply?'<div>'+esc(reply)+'</div>':'')+(added.length?'<hr>'+added.map(esc).join('<br>'):'');
    if(reply&&window.AndroidTTS?.speak)AndroidTTS.speak(reply);
    if(!reply&&!added.length)$('aiResult').innerHTML='Yapay zekâ bir işlem çıkaramadı. Komutu biraz daha açık yaz.';
    if(changed){renderHome();renderProjects();if(activeProject()){renderBook();renderNotes();renderTasks();}}
  }catch(e){
    $('aiResult').innerHTML='<b>AI hatası:</b> '+esc(e.message||'Bilinmeyen hata');
    if(fromVoice&&window.AndroidTTS?.speak)AndroidTTS.speak('İşlem sırasında bir hata oluştu.');
  }finally{$('aiParse').disabled=false;}
}
$('aiParse').onclick=()=>aiParse(false);$('voice').onclick=()=>{ $('aiResult').innerHTML='<b>Dinliyorum...</b> Ölçü, malzeme veya yapılacak işi söyle.';if(window.AndroidVoice){AndroidVoice.startVoice();return}let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return voiceError('Bu cihazda ses tanıma desteklenmiyor.');let r=new SR();r.lang='tr-TR';r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>handleNativeVoice(e.results[0][0].transcript);r.onerror=e=>voiceError(e.error||'Ses tanınamadı.');try{r.start()}catch(e){voiceError('Sesli giriş başlatılamadı.')}};
$('aiClear')?.addEventListener('click',()=>{aiConversation=[];if($('aiChat'))$('aiChat').innerHTML='';if($('aiResult'))$('aiResult').textContent='Sohbet temizlendi.';});
$('aiStop')?.addEventListener('click',()=>{try{speechSynthesis?.cancel()}catch(_){} if(window.AndroidTTS?.stop)AndroidTTS.stop();});
const calcField=$('calcInput'); const calcNormalize=()=>calcField.value.replace(/,/g,'.').replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-'); const runCalc=()=>{let x=calcNormalize().replace(/[^0-9+\-*/().\s]/g,'');if(!x.trim())return;try{let v=Function('\"use strict\";return ('+x+')')();if(!Number.isFinite(v))throw 0;$('calcResult').textContent=Number(v.toFixed(4));}catch(_){$('calcResult').textContent='Hatalı işlem';}}; $('doCalc').onclick=runCalc; document.querySelectorAll('#calcKeys [data-key]').forEach(btn=>btn.onclick=()=>{let k=btn.dataset.key;if(k==='=')return runCalc();if(k==='clear'){calcField.value='';$('calcResult').textContent='0';return;}if(k==='back'){calcField.value=calcField.value.slice(0,-1);return;}calcField.value+=k==='.'?',':k;}); calcField.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runCalc();}});
function reportText(){let p=activeProject(),s=`${p.name}\n\nÖLÇÜLER\n`;p.records.forEach(r=>s+=`${r.cat} / ${r.workItem||r.area}${r.workItem&&r.area&&r.workItem!==r.area?' / '+r.area:''}${r.floor?' / '+r.floor:''}: ${r.unit==='m3'?r.a+' x '+r.b+' x '+r.c:r.unit==='m2'?r.a+' x '+r.b:r.a} = ${r.value} ${fmtUnit(r.unit)}${r.price?' • '+r.price+' ₺/birim':''}\n`);s+='\nNOT / MALZEMELER\n';p.notes.forEach(n=>s+=`${n.qty?n.qty+' '+n.unit+' ':''}${n.text}\n`);s+='\nYAPILACAKLAR / EKSİKLER\n';p.tasks.forEach(t=>s+=`${t.done?'[x]':'[ ]'} ${t.text}\n`);return s}
$('copy').onclick=()=>{let s=reportText();if(navigator.share)navigator.share({title:activeProject().name,text:s}).catch(()=>{});else navigator.clipboard?.writeText(s).then(()=>alert('Defter kopyalandı.')).catch(()=>alert(s))};$('pdf').onclick=()=>{let s=reportText();if(window.AndroidPrint&&AndroidPrint.printReport){AndroidPrint.printReport(s);return;}let w=window.open('','_blank');if(!w)return alert('Yazdırma penceresi açılamadı.');w.document.write('<pre style="font:14px Arial;white-space:pre-wrap">'+esc(s)+'</pre>');w.document.close();w.focus();setTimeout(()=>w.print(),300)};
$('new').onclick=()=>{if(!requireProject())return;renderCats();show('categories')};$('openAI').onclick=()=>show('ai');$('bookBtn').onclick=()=>{if(requireProject())show('book')};$('noteBtn').onclick=()=>{if(requireProject())show('notes')};$('taskBtn').onclick=()=>{if(requireProject())show('tasks')};$('calcBtn').onclick=()=>show('calculator');$('project').onclick=()=>show('projects');$('projectSelectBtn').onclick=()=>$('projectPicker').classList.toggle('hide');$('clear').onclick=()=>{let p=requireProject();if(!p)return;if(confirm('Bu projenin tüm ölçüleri silinsin mi?')){p.records=[];save();renderBook()}};
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{const id=b.dataset.go;if(['categories','book','notes','tasks','pro'].includes(id)&&!requireProject())return;if(id==='categories')renderCats();if(id==='pro')renderPro();show(id)});document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>window.appGoBack());
// PRO
function renderPro(){let p=activeProject();
 $('custName').value=p.customer?.name||'';$('custPhone').value=p.customer?.phone||'';$('custAddress').value=p.customer?.address||'';$('projectDesc').value=p.customer?.desc||'';
 let groups={};p.records.forEach(r=>{let k=`${r.cat}||${r.floor||'Kat belirtilmedi'}`;(groups[k]??=[]).push(r)});
 let rows='';Object.entries(groups).forEach(([k,rs])=>{let [cat,floor]=k.split('||'),parts=sumUnits(rs).map(x=>`${x.v.toLocaleString('tr-TR',{maximumFractionDigits:2})} ${fmtUnit(x.u)}`).join(' • '),amount=rs.reduce((s,r)=>s+(r.price||0)*r.value,0);rows+=`<div class="line"><b>${esc(cat)} · ${esc(floor)}</b><span>${parts||'-'}${amount?` • ${amount.toLocaleString('tr-TR',{minimumFractionDigits:2})} ₺`:''}</span></div>`});
 $('proTotals').innerHTML=rows||'<div class="muted">Henüz ölçü yok.</div>';$('quotePreview').innerHTML='';
}
$('proBtn').onclick=()=>{renderPro();show('pro')};
$('saveCustomer').onclick=()=>{let p=activeProject();p.customer={name:$('custName').value.trim(),phone:$('custPhone').value.trim(),address:$('custAddress').value.trim(),desc:$('projectDesc').value.trim()};save();alert('Proje bilgileri kaydedildi.');};
function buildQuote(){let p=activeProject(),tax=parseFloat($('taxRate').value)||0,rows=p.records.map(r=>({name:r.cat+' / '+r.area,qty:r.value,unit:r.unit==='m2'?'m²':r.unit==='m3'?'m³':r.unit==='mtul'?'mt':r.unit,price:r.price||0,total:(r.price||0)*r.value})).filter(x=>x.total>0);let sub=rows.reduce((s,r)=>s+r.total,0),vat=sub*tax/100,total=sub+vat;let s=`${p.name}\nTEKLİF / HAKEDİŞ\n\nMüşteri: ${p.customer?.name||'-'}\nTelefon: ${p.customer?.phone||'-'}\nAdres: ${p.customer?.address||'-'}\n\n`;rows.forEach(r=>s+=`${r.name}: ${r.qty} ${r.unit} × ${r.price.toFixed(2)} ₺ = ${r.total.toFixed(2)} ₺\n`);s+=`\nAra toplam: ${sub.toFixed(2)} ₺\nKDV (%${tax}): ${vat.toFixed(2)} ₺\nGENEL TOPLAM: ${total.toFixed(2)} ₺`;return {s,sub,vat,total,rows};}
$('makeQuote').onclick=()=>{let q=buildQuote();$('quotePreview').innerHTML=`<b>${esc(activeProject().name)}</b><br>${q.rows.length?esc(q.rows.map(r=>`${r.name}: ${r.qty} ${r.unit} × ${r.price.toFixed(2)} ₺ = ${r.total.toFixed(2)} ₺`).join('\n')).replace(/\n/g,'<br>'):'Birim fiyat girilmiş kayıt yok.'}<hr>Ara toplam: <b>${q.sub.toFixed(2)} ₺</b><br>KDV: ${q.vat.toFixed(2)} ₺<br>Genel toplam: <b>${q.total.toFixed(2)} ₺</b>`};
$('shareQuote').onclick=()=>{let q=buildQuote();if(navigator.share)navigator.share({title:activeProject().name+' Teklif',text:q.s}).catch(()=>{});else navigator.clipboard?.writeText(q.s).then(()=>alert('Teklif kopyalandı. WhatsApp veya başka uygulamadan paylaşabilirsin.')).catch(()=>alert(q.s));};
$('exportBackup').onclick=()=>{let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='olcu-defteri-yedek-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),500);};
$('doImport').onclick=()=>{let f=$('importBackup').files?.[0];if(!f)return alert('Önce yedek dosyası seç.');let r=new FileReader();r.onload=()=>{try{let incoming=JSON.parse(r.result);let safe=normalizeData(incoming);if(!safe.projects?.length)throw 0;if(!confirm('Mevcut verilerin üzerine yedek geri yüklenecek. Devam edilsin mi?'))return;data=safe;if(!save())throw new Error('Yedek cihaz hafızasına yazılamadı.');renderPro();renderBook();alert('Yedek geri yüklendi.');}catch(e){alert('Geçersiz veya kaydedilemeyen yedek dosyası.')}};r.onerror=()=>alert('Yedek dosyası okunamadı.');r.readAsText(f)};
$('homeAiSend')?.addEventListener('click',()=>{const v=$('homeAiText')?.value?.trim();if(v)runAIHomeCommand(v);});
document.querySelectorAll('[data-ai-quick]').forEach(b=>b.addEventListener('click',()=>{const q=b.dataset.aiQuick||'';$('homeAiText').value=q;$('homeAiText').focus();}));
$('homeAiText')?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();const v=e.target.value.trim();if(v)runAIHomeCommand(v);}});
$('welcomeStart').onclick=()=>{localStorage.setItem('od5_welcomed','1');show('home')};
if(localStorage.getItem('od5_welcomed')==='1'){renderHome();renderProjects();}else{show('welcome')}


window.closePrintView = function () {
  try {
    var overlay = document.querySelector('.print-view, #printView, .print-modal, [data-print-view]');
    if (overlay) overlay.remove();
    document.body.classList.remove('printing', 'print-view-open');
    window.scrollTo(0, 0);
  } catch (e) {}
};
