import OpenAI from "npm:openai";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const instructions = `Sen Ölçü Defteri AI'sın. Türkçe konuş. İnşaat ustasının ölçü defterini yönetmesine yardım et.
Kullanıcı mesajını ve mevcut projeyi analiz et. Yanıtı SADECE geçerli JSON olarak üret.
Şema: {"reply":"kısa Türkçe cevap","actions":[...]}
Actions yalnızca şunlar olabilir:
- {"type":"add_measure","category":"...","workItem":"...","area":"...","floor":"...","facade":"...","a":number,"b":number,"c":number,"unit":"m2|mtul|m3|adet|m|kg|ton|torba|paket|kutu|litre|kova"}
- {"type":"add_note","text":"...","qty":number,"unit":"..."}
- {"type":"add_task","text":"..."}
- {"type":"update_measure","record_id":"...","value":number}
Bir ölçünün birimi belirtilmezse bağlama göre m2 seç. m2 için a*b, m3 için a*b*c hesaplanır. Kullanıcı sadece bilgi soruyorsa actions boş olsun ve reply ile cevap ver. Mevcut kayıtlarda olmayan record_id uydurma. Emin olmadığın ölçüyü ekleme; reply içinde netleştirme iste.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return new Response(JSON.stringify({error:"Oturum gerekli."}), {status:401,headers:{...cors,"Content-Type":"application/json"}});
    const token=auth.slice(7);
    const supabaseUrl=Deno.env.get("SUPABASE_URL")!;
    const keys=JSON.parse(Deno.env.get("SUPABASE_PUBLISHABLE_KEYS")||"{}");
    const publishable=keys.default||Object.values(keys)[0];
    const ur=await fetch(`${supabaseUrl}/auth/v1/user`,{headers:{apikey:String(publishable),Authorization:`Bearer ${token}`}});
    if(!ur.ok)return new Response(JSON.stringify({error:"Oturum doğrulanamadı."}),{status:401,headers:{...cors,"Content-Type":"application/json"}});
    const body=await req.json();
    const message=String(body.message||"").slice(0,6000);
    const project=body.project||{};
    const history=Array.isArray(body.history)?body.history.slice(-10):[];
    const openai=new OpenAI({apiKey:Deno.env.get("OPENAI_API_KEY")});
    const response=await openai.responses.create({
      model:"gpt-5.6-luna",
      instructions,
      input:`ÖNCEKİ SOHBET:\n${JSON.stringify(history)}\n\nKULLANICI MESAJI:\n${message}\n\nMEVCUT PROJE:\n${JSON.stringify({name:project.name,records:project.records||[],notes:project.notes||[],tasks:project.tasks||[]}).slice(0,30000)}`,
      text:{format:{type:"json_schema",name:"olcu_defteri_result",strict:true,schema:{type:"object",additionalProperties:false,properties:{reply:{type:"string"},actions:{type:"array",items:{type:"object",additionalProperties:false,properties:{type:{type:"string",enum:["add_measure","add_note","add_task","update_measure"]},category:{type:["string","null"]},workItem:{type:["string","null"]},facade:{type:["string","null"]},area:{type:["string","null"]},floor:{type:["string","null"]},a:{type:["number","null"]},b:{type:["number","null"]},c:{type:["number","null"]},unit:{type:["string","null"]},text:{type:["string","null"]},qty:{type:["number","null"]},record_id:{type:["string","null"]},value:{type:["number","null"]}},required:["type","category","workItem","facade","area","floor","a","b","c","unit","text","qty","record_id","value"]}}},required:["reply","actions"]}}},
      store:false
    });
    const text=response.output_text||"{}";
    let data;try{data=JSON.parse(text)}catch(_){data={reply:text,actions:[]}}
    return new Response(JSON.stringify({reply:data.reply||"",actions:Array.isArray(data.actions)?data.actions:[]}),{headers:{...cors,"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:e?.message||"AI sunucu hatası"}),{status:500,headers:{...cors,"Content-Type":"application/json"}});
  }
});
